(function(window){
    var m = {};

    //去掉字符串首尾空格
    m.trim = function(str){
        if(String.prototype.trim){
            return str == null ? "" : String.prototype.trim.call(str);
        }else{
            return str.replace(/(^\s*)|(\s*$)/g, "");
        }
    };

    //去掉字符串所有空格
    m.trimAll = function(str){
        return str.replace(/\s*/g,'');
    };

    //是否为DOM元素
    m.isElement = function(obj){
        return !!(obj && obj.nodeType == 1);
    };

    //是否为数组
    m.isArray = function(obj){
        if(Array.isArray){
            return Array.isArray(obj);
        }else{
            return obj instanceof Array;
        }
    };

    //是否为空对象
    m.isEmptyObject = function(obj){
        if(JSON.stringify(obj) === '{}'){
            return true;
        }
        return false;
    };

    //为DOM元素绑定事件
    m.addEvt = function(el, name, fn, useCapture){
        if(!m.isElement(el)){
            console.log('$$.addEvt Function need el param, el param must be DOM Element');
            return;
        }
        useCapture = useCapture || false;
        if(el.addEventListener) {
            el.addEventListener(name, fn, useCapture);
        }
    };

    //移除DOM元素绑定的事件
    m.rmEvt = function(el, name, fn, useCapture){
        if(!m.isElement(el)){
            console.log('$$.rmEvt Function need el param, el param must be DOM Element');
            return;
        }
        useCapture = useCapture || false;
        if (el.removeEventListener) {
            el.removeEventListener(name, fn, useCapture);
        }
    };

    //为DOM元素绑定事件，事件只执行一次
    m.one = function(el, name, fn, useCapture){
        if(!m.isElement(el)){
            console.log('$$.one Function need el param, el param must be DOM Element');
            return;
        }
        useCapture = useCapture || false;
        var that = this;
        var cb = function(){
            fn && fn();
            that.rmEvt(el, name, cb, useCapture);
        };
        that.addEvt(el, name, cb, useCapture);
    };

    //选择首个匹配的DOM元素
    m.dom = function(el, selector){
        if(arguments.length === 1 && typeof arguments[0] == 'string'){
            if(document.querySelector){
                return document.querySelector(arguments[0]);
            }
        }else if(arguments.length === 2){
            if(el.querySelector){
                return el.querySelector(selector);
            }
        }
    };

    //选择所有匹配的DOM元素
    m.domAll = function(el, selector){
        if(arguments.length === 1 && typeof arguments[0] == 'string'){
            if(document.querySelectorAll){
                return document.querySelectorAll(arguments[0]);
            }
        }else if(arguments.length === 2){
            if(el.querySelectorAll){
                return el.querySelectorAll(selector);
            }
        }
    };

    //通过Id选择DOM元素
    m.byId = function(id){
        return document.getElementById(id);
    };

    //选择DOM元素的第一个子元素
    m.first = function(el, selector){
        if(arguments.length === 1){
            if(!m.isElement(el)){
                console.log('$$.first Function need el param, el param must be DOM Element');
                return;
            }
            return el.children[0];
        }
        if(arguments.length === 2){
            return this.dom(el, selector+':first-child');
        }
    };

    //选择DOM元素的最后一个子元素
    m.last = function(el, selector){
        if(arguments.length === 1){
            if(!m.isElement(el)){
                console.log('$$.last Function need el param, el param must be DOM Element');
                return;
            }
            var children = el.children;
            return children[children.length - 1];
        }
        if(arguments.length === 2){
            return this.dom(el, selector+':last-child');
        }
    };

    //选择第几个子元素
    m.eq = function(el, index){
        return this.dom(el, ':nth-child('+ index +')');
    };

    //根据排除选择器选择子元素
    m.not = function(el, selector){
        return this.domAll(el, ':not('+ selector +')');
    };

    //选择相邻的前一个元素
    m.prev = function(el){
        if(!m.isElement(el)){
            console.log('$$.prev Function need el param, el param must be DOM Element');
            return;
        }
        var node = el.previousSibling;
        if(node.nodeType && node.nodeType === 3){
            node = node.previousSibling;
            return node;
        }
    };

    //选择相邻的下一个元素
    m.next = function(el){
        if(!m.isElement(el)){
            console.log('$$.next Function need el param, el param must be DOM Element');
            return;
        }
        var node = el.nextSibling;
        if(node.nodeType && node.nodeType === 3){
            node = node.nextSibling;
            return node;
        }
    };

    //根据选择器匹配最近的父元素
    m.closest = function(el, selector){
        if(!m.isElement(el)){
            console.log('$$.closest Function need el param, el param must be DOM Element');
            return;
        }
        var doms, targetDom;
        var isSame = function(doms, el){
            var i = 0, len = doms.length;
            for(i; i<len; i++){
                if(doms[i].isEqualNode(el)){
                    return doms[i];
                }
            }
            return false;
        };
        var traversal = function(el, selector){
            doms = m.domAll(el.parentNode, selector);
            targetDom = isSame(doms, el);
            while(!targetDom){
                el = el.parentNode;
                if(el != null && el.nodeType == el.DOCUMENT_NODE){
                    return false;
                }
                traversal(el, selector);
            }

            return targetDom;
        };

        return traversal(el, selector);
    };

    //判断某一个元素是否包含目标元素
    m.contains = function(parent,el){
        var mark = false;
        if(el === parent){
            mark = true;
            return mark;
        }else{
            do{
                el = el.parentNode;
                if(el === parent){
                    mark = true;
                    return mark;
                }
            }while(el === document.body || el === document.documentElement);

            return mark;
        }

    };

    //移除DOM元素
    m.remove = function(el){
        if(el && el.parentNode){
            el.parentNode.removeChild(el);
        }
    };

    //获取或设置DOM元素的属性
    m.attr = function(el, name, value){
        if(!m.isElement(el)){
            console.log('$$.attr Function need el param, el param must be DOM Element');
            return;
        }
        if(arguments.length == 2){
            return el.getAttribute(name);
        }else if(arguments.length == 3){
            el.setAttribute(name, value);
            return el;
        }
    };

    //移除DOM元素的属性
    m.removeAttr = function(el, name){
        if(!m.isElement(el)){
            console.log('$$.removeAttr Function need el param, el param must be DOM Element');
            return;
        }
        if(arguments.length === 2){
            el.removeAttribute(name);
        }
    };

    //DOM元素是否含有某个className
    m.hasCls = function(el, cls){
        if(!m.isElement(el)){
            console.log('$$.hasCls Function need el param, el param must be DOM Element');
            return;
        }
        if(el.className.indexOf(cls) > -1){
            return true;
        }else{
            return false;
        }
    };

    //为DOM元素增加className
    m.addCls = function(el, cls){
        if(!m.isElement(el)){
            console.log('$$.addCls Function need el param, el param must be DOM Element');
            return;
        }
        if('classList' in el){
            el.classList.add(cls);
        }else{
            var preCls = el.className;
            var newCls = preCls +' '+ cls;
            el.className = newCls;
        }
        return el;
    };

    //移除指定的className
    m.removeCls = function(el, cls){
        if(!m.isElement(el)){
            console.log('$$.removeCls Function need el param, el param must be DOM Element');
            return;
        }
        if('classList' in el){
            el.classList.remove(cls);
        }else{
            var preCls = el.className;
            var newCls = preCls.replace(cls, '');
            el.className = newCls;
        }
        return el;
    };

    //切换指定的className
    m.toggleCls = function(el, cls){
        if(!m.isElement(el)){
            console.log('$$.toggleCls Function need el param, el param must be DOM Element');
            return;
        }
       if('classList' in el){
            el.classList.toggle(cls);
        }else{
            if(m.hasCls(el, cls)){
                m.removeCls(el, cls);
            }else{
                m.addCls(el, cls);
            }
        }
        return el;
    };

    //获取或设置常用 Form 表单元素的 value 值
    m.val = function(el, val){
        if(!m.isElement(el)){
            console.log('$$.val Function need el param, el param must be DOM Element');
            return;
        }
        if(arguments.length === 1){
            switch(el.tagName){
                case 'SELECT':
                    var value = el.options[el.selectedIndex].value;
                    return value;
                    break;
                case 'INPUT':
                    return el.value;
                    break;
                case 'TEXTAREA':
                    return el.value;
                    break;
            }
        }
        if(arguments.length === 2){
            switch(el.tagName){
                case 'SELECT':
                    el.options[el.selectedIndex].value = val;
                    return el;
                    break;
                case 'INPUT':
                    el.value = val;
                    return el;
                    break;
                case 'TEXTAREA':
                    el.value = val;
                    return el;
                    break;
            }
        }

    };

    //在DOM元素内部，首个子元素前插入HTML字符串
    m.prepend = function(el, html){
        if(!m.isElement(el)){
            console.log('$mdt.prepend Function need el param, el param must be DOM Element');
            return;
        }
        el.insertAdjacentHTML('afterbegin', html);
        return el;
    };

    //在DOM元素内部，最后一个子元素后面插入HTML字符串
    m.append = function(el, html){
        if(!m.isElement(el)){
            console.log('$mdt.append Function need el param, el param must be DOM Element');
            return;
        }
        el.insertAdjacentHTML('beforeend', html);
        return el;
    };

    //在DOM元素前面插入HTML字符串
    m.before = function(el, html){
        if(!m.isElement(el)){
            console.log('$mdt.before Function need el param, el param must be DOM Element');
            return;
        }
        el.insertAdjacentHTML('beforebegin', html);
        return el;
    };

    //在DOM元素后面插入HTML字符串
    m.after = function(el, html){
        if(!m.isElement(el)){
            console.log('$$.after Function need el param, el param must be DOM Element');
            return;
        }
        el.insertAdjacentHTML('afterend', html);
        return el;
    };

    //获取或设置DOM元素的innerHTML
    m.html = function(el, html){
        if(!m.isElement(el)){
            console.log('$$.html Function need el param, el param must be DOM Element');
            return;
        }
        if(arguments.length === 1){
            return el.innerHTML;
        }else if(arguments.length === 2){
            el.innerHTML = html;
            return el;
        }
    };

    //设置或者获取元素的文本内容
    m.text = function(el, txt){
        if(!m.isElement(el)){
            console.log('$$.text Function need el param, el param must be DOM Element');
            return;
        }
        if(arguments.length === 1){
            return el.textContent;
        }else if(arguments.length === 2){
            el.textContent = txt;
            return el;
        }
    };

    //获取元素在页面中的位置与宽高
    m.offset = function(el){
        if(!m.isElement(el)){
            console.log('$$.offset Function need el param, el param must be DOM Element');
            return;
        }
        var sl = Math.max(document.documentElement.scrollLeft, document.body.scrollLeft);
        var st = Math.max(document.documentElement.scrollTop, document.body.scrollTop);

        var rect = el.getBoundingClientRect();
        return {
            l: rect.left + sl,
            t: rect.top + st,
            w: el.offsetWidth,
            h: el.offsetHeight
        };
    };

    //设置所传入的DOM元素的样式，可传入多条样式
    m.css = function(el, css){
        if(!m.isElement(el)){
            console.log('$$.css Function need el param, el param must be DOM Element');
            return;
        }
        if(typeof css == 'string' && css.indexOf(':') > 0){
            el.style && (el.style.cssText += ';' + css);
        }
    };

    //获取指定DOM元素的指定属性的完整的值，如600px
    m.cssVal = function(el, prop){
        if(!m.isElement(el)){
            console.log('$$.cssVal Function need el param, el param must be DOM Element');
            return;
        }
        if(arguments.length === 2){
            var computedStyle = window.getComputedStyle(el, null);
            return computedStyle.getPropertyValue(prop);
        }
    };

    //将标准的JSON 对象转换成字符串格式
    m.jsonToStr = function(json){
        if(typeof json === 'object'){
            return JSON && JSON.stringify(json);
        }
    };

    //将JSON字符串转换成JSON对象
    m.strToJson = function(str){
        if(typeof str === 'string'){
            return JSON && JSON.parse(str);
        }
    };

    //更加配置和系统来设置状态栏
    m.fixStatusBar = function(el){
        if(!m.isElement(el)){
            console.log('$$.fixStatusBar Function need el param, el param must be DOM Element');
            return;
        }
        var sysType = md.systemType;
        var ver = parseFloat(md.systemVersion);

        if (md.statusBarAppearance) {
            if (sysType == 'ios' && ver >= 7.0) {
                el.style.paddingTop = '20px';
            }
            else if(sysType == 'android' && ver >= 4.4){
                el.style.paddingTop = '25px';
            }
        }
    };

    //获取当前时间
    m.getCurTime=function(){
        var curDateTime = new Date();
        return curDateTime.getFullYear()+"/"+(curDateTime.getMonth()+1)+"/"+curDateTime.getDate()+" "+curDateTime.getHours()+":"+curDateTime.getMinutes()+":"+curDateTime.getSeconds();
    }

    //时间转换
    m.changeTime = function(startTime){
        var time = new Date(startTime);
        var hour = time.getHours();
        var timeBar=(time.getMonth()+1)+"月"+time.getDate()+"日"+" "+
                ((5> hour && hour>=0)?"凌晨":((10> hour && hour>=5) ?"早上":((12> hour && hour>=10)?"上午":
                ((14>hour&&hour>=12)?"中午":((18>hour&&hour>=14)?"下午":"晚上")))))+hour+":"+(time.getMinutes()<10?("0"+time.getMinutes()):time.getMinutes());
        return timeBar;
    }


    window.$$ = m;

})(window);


