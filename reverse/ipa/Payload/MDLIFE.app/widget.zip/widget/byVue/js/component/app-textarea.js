/*
 * 文本框：
 * @param {String} app_id id标识
 * @param {String} app_key 文本框名称
 * @param {String} app_value 值
 * @param {String} show 是否显示：true显示，none隐藏
 * @param {String} disabled 
 * @param {String} border_bottom 是否显示下划线，默认显示
 * @param {String} maxlength 最大字符数
 */
Vue.component('app-textarea', {
    // props : [ 'app_id', 'app_key', 'app_value', 'show', 'disabled', 'border_bottom', 'maxlength' ],
    props : { app_id : String, 
              app_key : String, 
              app_value : String, 
              show : String, 
              disabled : String, 
              border_bottom : String, 
              maxlength : String
            },
    template : `<div v-bind:app_id="app_id" class="_app_textarea_" v-show="show != 'none'" _app_tag_="app-textarea" v-bind:disabled="disabled" >
                  
                    <div class="_app_textarea_div_" v-bind:class="{ jyb_text_border_bottom : _border_bottom_( border_bottom ) }" >
                        <div class="jyb_text_key jyb_detail text_key_color">{{ app_key }}</div>
                        <textarea v-bind:id="app_id" @input="_validate_( $event )" style="height:1.2rem;" class="_app_textarea_input_ jyb_detail text_value_color" v-bind:value="app_value" :maxlength="maxlength" />
                    </div>

                    <div style="clear:both;"></div>
                </div>`,
    methods : {
        _border_bottom_ : function ( border_bottom ) {
            if ( border_bottom && ( border_bottom == "false" || border_bottom == "none" ) ) {
                return false;
            } else {
                return true;
            }
        },
        _validate_ : function ( e ) {
            var flag = true;

        }
    }
});