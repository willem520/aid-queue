/*
 * 提示：
 * @param {String} app_id id标识
 * @param {String} app_key 标题名称
 * @param {String} show 是否显示
 * @param {String} prompt_style 提示信息样式
 */
Vue.component('app-prompts', {
    // props : [ 'app_id', 'app_key', 'show', 'prompt_style' ],
    props : { app_id : String,
              app_key : String,
              show : String,
              prompt_style : String
            },
    template : `<div v-bind:app_id="app_id" class="app_prompts_"  _app_tag_="app-prompts" v-show="show != 'none'" >
                    <div class="app_prompts_head_">
                        <p class="app_prompts_title_ jyb_title css_ellipsis ">{{ app_key }}</p>
                    </div>
                    <div v-if=" this.$slots.default && this.$slots.default.length > 0 " :style="prompt_style" class="app_prompts_body_" >
                        <slot></slot>
                    </div>
                </div>`
});