/*
 * 托盘：
 * @param {String} app_id id标识
 * @param {String} app_key 标题名称
 * @param {String} show 是否显示
 * @param {String} show_must 是否必填
 * @param {String} height_diff 底部留空高度
 * @param {String} title_icon 标题图标
 * 
 * <div v-else class="app_panel_blue_line_" ></div>
 */
Vue.component('app-panel', {
    // props : [ 'app_id', 'app_key', 'show', 'height_diff', 'title_icon' ],
    props : { app_id : String,
              app_key : String,
              show : String,
              show_must : String,
              height_diff : String,
              title_icon : String
            },
    template : `<div v-bind:app_id="app_id" class="app_panel_" _app_tag_="app-panel" v-show="show != 'none'" >
                    <div class="app_panel_head_">

                        <div style="float:left;margin-left:0.15rem;width:0.2rem;height:0.8rem;" >
                          <img v-if="title_icon != null" class="jyb_text_title_icon" v-bind:src="title_icon" ></img>
                          <img v-else class="jyb_text_title_icon" src="../../static/jybimage/icon_title.png" ></img>
                        </div>

                        <div class="app_panel_title_ jyb_title "><span v-show="show_must  == 'true'" style="color: red;">* </span>{{ app_key }}</div>
                    </div>
                    <div v-if=" this.$slots.default && this.$slots.default.length > 0 " class="app_panel_body_" >
                        <slot></slot>
                    </div>
                    <div style="clear:both;"></div>
                </div>`,
    mounted : function () {
        if ( this.height_diff && JSUtil.isNotEmpty( this.height_diff ) ) {
            var obj = this.$el;
            var h = document.body.clientHeight;  // 屏幕高度
            var t = obj.offsetTop;  // 当前元素top
            var title = document.querySelector( "div[_app_tag_='app-title']" );
            var title_height = title.offsetHeight;  // 标题高度
            var body_height = h - title_height;  // app-body高度
            var app_panel_height = body_height - t - this.height_diff;  // panel高度
            obj.style.height = app_panel_height + "px";
            var app_panel_head_ = obj.querySelector( ".app_panel_head_" );
            var app_panel_body_ = obj.querySelector( ".app_panel_body_" );
            if ( app_panel_body_ ) {
                app_panel_body_.style.height = ( app_panel_height - app_panel_head_.offsetHeight ) + "px";
            }
        }
    }
});