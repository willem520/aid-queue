/*
 * app-list：列表
 * @param {String} app_id id标识
 * @param {String} app_key 预留属性，暂时没有用
 * @param {String} app_list_data json数据
 * @method {String} app_click 单击事件
 * @param {String} show 是否显示
 * @param {String} show_head 显示列表头
 * @param {String} data_config 用于解决vue的自定义标签问题
 * @param {String} show_arrow_icon 显示右侧箭头标签
 * @param {String} _original_html_ html代码
 */
Vue.component('app-list', {
    // props : [ 'app_id', 'app_key', 'app_list_data', 'app_click', 'show', 'show_head', 'data_config', 'show_arrow_icon', '_original_html_' ],
    props : { app_id : String,
              app_key : String,
              app_list_data : String,
              app_click : String,
              show : String,
              show_head : String,
              data_config : String,
              show_arrow_icon : String,
              _original_html_ : String
            },
    template : `<div class="_app_list_" _app_tag_="app-list" v-bind:app_id="app_id" v-show="show != 'none'" :_original_html_="_original_html_" :data_config="JSON.stringify( data_config )" :app_click="app_click" :show_arrow_icon="show_arrow_icon" >
                    <div class="_app_list_title_" >
                        <div class="jyb_text_div jyb_text_border_bottom" >
                            <img class="jyb_text_title_icon" src="../../static/jybimage/icon_title.png"></img>
                            <span class="jyb_text_key jyb_detail text_key_color" >{{app_key}}</span>
                        </div>
                        <div style="clear:both;"></div>
                    </div>
                    <div class="_app_list_head_" v-show="show_head != 'none' && show_head != 'false'" >
                        <template v-for="( item, index ) in _toArray_( data_config )" >
                            <div class="_app_list_head_cell_ jyb_detail" :style="{ width:_get_width_( item['app_width'] ) }" >{{item["app_key"]}}</div>
                        </template>
                        <div style="clear:both;"></div>
                    </div>
                    <div class="_app_list_body_" >
                        <div v-for="( row_data, _row_ ) in _toArray_(app_list_data)" :key="_row_" class="_app_list_row_" :_row_="_row_" :_row_data_="encodeURIComponent( JSON.stringify( row_data ) )" @click="_app_click_($event)" >
                            <template v-for="( item, _col_ ) in _toArray_(data_config)" >
                                <div class="_app_list_row_cell_ text_key_color" style="font-size:0.25rem;overflow:hidden;" :style="{ width:_get_width_( item['app_width'] ), textAlign:item['align'] }" >{{ _getValue_( _row_, _col_, row_data[item["app_id"]], row_data ) }}</div>
                            </template>
                            <img v-show="show_arrow_icon != 'none'" class="jyb_text_arrow" src="../../static/jybimage/arrow_right.png"></img>
                            <div style="clear:both;"></div>
                        </div>
                    </div>
                </div>`,
    created: function () {
        var obj = BaseEx.getObj( this.app_id );
        // console.log( obj );
        // obj.setAttribute( "_original_html_", encodeURIComponent( JSUtil.domToString( obj ) ) );
        this._original_html_ = encodeURIComponent( JSUtil.domToString( obj ) );
        var _data_config_ = new Array();
        var list = obj.children;
        var i,el,row_config,attributes,j,attribute;
        for ( i = 0; i < list.length; i++) {
            el = list[i];
            // console.log( el );
            if ( el.nodeName = "app-list-item" ) {
                row_config = {};
                attributes = el.attributes;
                for ( j = 0; j < attributes.length; j++) {
                    attribute = attributes[ j ];
                    row_config[ attribute.nodeName ] = attribute.nodeValue;
                }
                _data_config_.push( row_config );
            }
        }
        // console.log( data_config );
        this.data_config = _data_config_;
    },
    mounted: function () {
        var obj = BaseEx.getObj( this.app_id ).querySelector( "._app_list_body_" );
        if ( obj && obj.children && obj.children.length > 0 ) {
            var list = obj.children;
            var row,row_height,clist,cell,cell_height,cell_top,i,j;
            for (i = 0; i < list.length; i++) {
                row = list[i];
                row_height = row.offsetHeight;
                clist = row.children;
                for (j = 0; j < clist.length; j++) {
                    cell = clist[ j ];
                    cell_height = cell.offsetHeight;
                    // console.log( row_height + "::" + cell_height );
                    cell_top = ( row_height - cell_height ) / 2;
                    cell.style.top = cell_top + "px";
                }
            }
        }
    },
    methods : {
        _toArray_ : function ( str ) {
          // console.log( str );
          var _str;
          if ( typeof str == "string" ) {
              _str = eval(str);
          } else {
              _str = str;
          }
          // console.log( _str );
          return _str;
        },
        _getValue_ : function ( _row_, _col_, str, row_data ) {
            if ( str ) {
                var config = this._toArray_( this.data_config )[_col_];
                if ( config[ "formatter" ] ) {
                    var fun = eval( config[ "formatter" ] );
                    return fun( _row_, _col_, str, row_data );
                } else {
                    return str;
                }
            } else {
                return "";
            }
        },
        _get_width_ : function ( width ) {
            // console.log( width );
            if ( width ) {
                return width;
            } else {
                return "2rem";
            }
        },
        _app_click_: function ( e ) {
            if ( this.app_click ) {
                var fun = eval( this.app_click.split( "(" )[0] );
                if ( typeof fun == "function" ) {
                    var obj = e.currentTarget;
                    var _row_data_ = obj.getAttribute( "_row_data_" );
                    var params = JSON.parse( decodeURIComponent( _row_data_ ) );
                    fun( params );
                }
            }
        }
    }
});