/*
 * app-list-ca：列表：尝试解决大数据量列表的应对方案
 * @param {String} app_id id标识
 * @param {String} app_key 预留属性，暂时没有用
 * @param {String} app_list_data json数据
 * @method {String} app_click 单击事件
 * @param {String} show 是否显示
 * @param {String} show_head 显示列表头
 * @param {String} data_config 用于解决vue的自定义标签问题
 * @param {String} show_arrow_icon 显示右侧箭头标签
 */
Vue.component('app-list-ca', {
    // props : [ 'app_id', 'app_key', 'app_list_data', 'app_click', 'show', 'show_head', 'data_config', 'show_arrow_icon' ],
    props : { app_id : String, 
              app_key : String, 
              app_list_data : String, 
              app_click : String, 
              show : String, 
              show_head : String, 
              data_config : String, 
              show_arrow_icon : String
            },
    template : `<div class="_app_list_" _app_tag_="app-list-ca" v-bind:app_id="app_id" v-show="show != 'none'" :data_config="JSON.stringify( data_config )" :app_click="app_click" >
                    <div class="_app_list_title_" >
                        <div class="jyb_text_div jyb_text_border_bottom" >
                            <img class="jyb_text_title_icon" src="../../static/jybimage/icon_title.png"></img>
                            <span class="jyb_text_key jyb_detail text_key_color" >{{app_key}}</span>
                        </div>
                        <div style="clear:both;"></div>
                    </div>
                    <div class="_app_list_head_" v-show="show_head != 'none' && show_head != 'false'" >
                        <template v-for="( item, index ) in _toArray_( data_config )" >
                            <div class="_app_list_head_cell_ jyb_detail" :style="{ width:_get_width_( item['app_width'] ) }" >{{item["app_key"]}}</div>
                        </template>
                        <div style="clear:both;"></div>
                    </div>
                    <div class="_app_list_body_" >
                        <div class="_app_list_content_" ></div>
                    </div>
                </div>`,
    created: function () {
        var obj = BaseEx.getObj( this.app_id );
        // console.log( obj );
        // obj.setAttribute( "_original_html_", encodeURIComponent( JSUtil.domToString( obj ) ) );
        // this._original_html_ = encodeURIComponent( JSUtil.domToString( obj ) );
        var _data_config_;
        var list = obj.children;
        _data_config_ = BaseEx.vueCommon.appList._getDataConfig_( list );
        this.data_config = _data_config_;
        // BaseEx.vueCommon.appList2.cacheConfig( this.app_id, "_data_config_", _data_config_ );

    },
    mounted: function () {
        var target = BaseEx.getObj( this.app_id );
        var _app_list_body_ = target.querySelector( "._app_list_body_" );
        // var win_length = 0;

        // 调整列表体高度和滚动样式
        var top = JSUtil.top( _app_list_body_ );
        var win_height = _app_list_body_.ownerDocument.documentElement.clientHeight || _app_list_body_.ownerDocument.body.clientHeight;
        _app_list_body_.style.height = ( win_height - top ) + "px";
        _app_list_body_.style.overflowY = "auto";
        // var row_height = JSUtil.remToPx( 0.8 );
        // win_length = ( win_height - top ) * 2 / row_height;

        // 添加数据行

        var app_list_data = this.app_list_data;
        BaseEx.setListData( target, app_list_data );

        // var _data_config_ = this.data_config;
        // var _app_list_content_ = target.querySelector( "._app_list_content_" );
        // var list = this.app_list_data, row_data, item, html=[], _width_, _align_, i, j;
        // _app_list_content_.style.height = row_height * list.length;

        // list = list ? eval( list ) : [];

        // var length = list.length > win_length ? win_length : list.length;
        // for (i = 0; i < length; i++) {
        //     row_data = list[i];

        //     BaseEx.vueCommon.appList._addListRow_( this.app_id, row_data, i );

        // }
        // BaseEx.vueCommon.appList2.initList( this.app_id );

        // 添加滚动事件
        JSUtil.addHandle( _app_list_body_, "scroll", this._roll_ );

        // 监听页面大小变化


    },
    methods : {
        _toArray_ : function ( str ) {
          // console.log( str );
          var _str;
          if ( typeof str == "string" ) {
              _str = eval(str);
          } else {
              _str = str;
          }
          // console.log( _str );
          return _str;
        },
        _get_width_ : function ( width ) {
            // console.log( width );
            return BaseEx.vueCommon.appList._get_width_ ( width );
        },
        _roll_: function ( e ) {

            // var target = e.currentTarget;
            // var outter_height = target.offsetHeight;
            // var _app_list_content_ = target.querySelector( "._app_list_content_" );
            // var list = _app_list_content_.children;
            // var inner_height = 0, el;
            // for (var i = 0; i < list.length; i++) {
            //     el = list[i];
            //     inner_height += el.offsetHeight;
            // }
            // var scroll_top = target.scrollTop;
            // var win_length = ( outter_height - scroll_top ) * 2 / JSUtil.remToPx( 0.8 );

            // console.log( outter_height + "::" + scroll_top + "::" + inner_height );

            // if ( outter_height + scroll_top == inner_height ) {

            //     var app_id = this.app_id;

            //     setTimeout( function ( e ) {
            //         var target = BaseEx.getObj( app_id );
            //         var list = eval( target.getAttribute( "app_list_data" ) );
            //         var _app_list_body_ = target.querySelector( "._app_list_body_" );
            //         var inner_list = _app_list_body_.children;
            //         var inner_length = inner_list.length,
            //             list_length = list.length,
            //             length = list_length - inner_length;
            //         length = length > 10 ? 10 : length;
            //         length += inner_length;
            //         if ( inner_length < list_length ) {
            //             for (var i = inner_length; i <length; i++) {
            //                 var row = list[i];

            //                 BaseEx.vueCommon.appList._addListRow_( app_id, row, i );

            //             }
            //         }
            //     }, 300 );
            // }

            var app_id = this.app_id;
            // var st = setTimeout( function ( e ) {
                BaseEx.vueCommon.appList2.scrollList( app_id );
            // }, 300 );

        }
    }
});