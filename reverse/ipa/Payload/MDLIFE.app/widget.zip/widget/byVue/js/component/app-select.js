/*
 * 弹出选项卡：app-select：
 * @param {String} app_id id标识
 * @param {String} app_key 选项卡名称
 * @param {String} app_select_title 选项卡标题
 * @param {String} app_laber_name 作为选项显示的字段
 * @param {String} app_key_name 作为值的字段
 * @param {String} title_icon 选项卡左侧图标地址
 * @param {String} app_collection_data 选项卡数据（json格式）
 * @method {String} on_select 选择回调函数
 * @param {String} show 是否显示
 * @param {String} show_must 是否必填
 * @param {String} order 排序方式：asc升序，desc降序
 * @param {String} show_arrow_icon 显示箭头图标：
 * @param {String} border_bottom 是否显示下划线，默认显示
 * @param {String} _original_html_ 标签html代码：用于刷新数据。不可以在页面标签中出现。
 */
Vue.component('app-select', {
    // props: [ 'app_id', 'app_key', 'app_value', 'app_select_title', 'app_laber_name', 'app_key_name', 'title_icon', 'icon_click', 'app_collection_data', 'on_select', 'show', 'order', 'show_arrow_icon', 'span', 'need_clear', 'formatter', '_original_html_' ],
    props: {
              app_id : {
                  type : String,
                  // default : function () {
                  //     var factory = function () {
                  //         this.def = "app" + ( Math.random() + "" ).replace( /\D/g, "" );
                  //     }
                  //     var factory_ = new factory();
                  //     return factory_.def;
                  // }
              },
              app_key : String,
              app_value : String,
              app_select_title : String,
              app_laber_name : String,
              app_key_name : String,
              title_icon : String,
              icon_click : String,
              app_collection_data : String,
              on_select : String,
              show : String,
              show_must : String,
              order : String,
              show_arrow_icon : String,
              span : String,
              need_clear : String,
              formatter : String,
              border_bottom : String,
              _original_html_ : {
                  type : String
              }
          },
    template:`<div class="jyb_text" v-bind:app_id="app_id" v-bind:span="span" _app_tag_="app-select" @click="_fn_( $event )" v-show="show != 'none'" v-bind:app_select_title="app_select_title" v-bind:app_laber_name="app_laber_name" v-bind:app_key_name="app_key_name" v-bind:app_collection_data="app_collection_data" v-bind:_original_html_="_original_html_" v-bind:formatter="formatter" >
                  
                  <div v-if="title_icon != null" class="jyb_text_div" v-bind:class="{ jyb_text_border_bottom : _border_bottom_( border_bottom ) }" >
                      <img class="jyb_text_title_icon" v-bind:src="title_icon" @click="_icon_click_( $event )" ></img>
                      <span class="jyb_text_key jyb_detail text_key_color" ><span v-show="show_must  == 'true'" style="color: red;">* </span>{{ app_key }}</span>
                      <span v-bind:id="app_id" class="jyb_text_value jyb_detail text_value_color css_ellipsis"></span>
                      <img v-show="show_arrow_icon == 'true'" class="jyb_text_arrow" src="../../static/jybimage/arrow_right.png"></img>
                  </div>

                  <div v-else class="jyb_text_div" v-bind:class="{ jyb_text_border_bottom : _border_bottom_( border_bottom ) }" >
                      <span class="jyb_text_key jyb_detail text_key_color"><span v-show="show_must  == 'true'" style="color: red;">* </span>{{ app_key }}</span>
                      <span v-bind:id="app_id" class="jyb_text_value jyb_detail text_value_color css_ellipsis"></span>
                      <img v-show="show_arrow_icon == 'true'" class="jyb_text_arrow" src="../../static/jybimage/arrow_right.png"></img>
                  </div>



              </div>`,
    created : function () {
        var obj = BaseEx.getObj( this.app_id );
        if ( !obj ) {
            var elArray = document.querySelectorAll( "app-select" ), el, _app_id_;
            for (var i = 0; i < elArray.length; i++) {
                el = elArray[i];
                _app_id_ = el.getAttribute( "app_id" );
                if ( !_app_id_ || JSUtil.isEmpty( _app_id_ ) ) {
                    obj = el;
                    break;
                }
            }
        }
        if ( !this.app_id || JSUtil.isEmpty( this.app_id ) ) {
            this.app_id = "app" + ( Math.random() + "" ).replace( /\D/g, "" );
            obj.setAttribute( "app_id", this.app_id );
        }
        this._original_html_ = encodeURIComponent( JSUtil.domToString( obj ) );
    },
    mounted : function () {
        if ( this.app_value ) {
            BaseEx.setSelectValue( this.app_id, this.app_value );
        }
    },
    methods : {
        _border_bottom_ : function ( border_bottom ) {
            if ( border_bottom && ( border_bottom == "false" || border_bottom == "none" ) ) {
                return false;
            } else {
                return true;
            }
        },
        _fn_ : function ( e ) {
            var el = e.currentTarget;
            var app_select_title = el.getAttribute( "app_select_title" );
            var app_collection_data = el.getAttribute( "app_collection_data" );
            var app_laber_name = el.getAttribute( "app_laber_name" );
            var app_key_name = el.getAttribute( "app_key_name" );
            var app_id = el.getAttribute( "app_id" );
            var order = this.order;
            var formatter = this.formatter;

            var _clearFun_;
            if ( this.need_clear && this.need_clear == "true" ) {
                _clearFun_ = function ( e ) {
                    BaseEx.setSelectValue( app_id, "" );
                };
            }

            var select_fun = function( e ){
                if ( app_collection_data ) {
                    BaseEx.openPicker( app_select_title, app_collection_data, app_laber_name, function( params ){
                        BaseEx.setSelectValue( app_id, params[ app_key_name ] );
                    }, null, order, _clearFun_, formatter );
                }
            };

            if ( this.on_select) {
                var fun = eval( this.on_select.split("(")[0] );
                if ( typeof fun == "function" ) {
                    var select_fun = function( e ){
                        if ( app_collection_data ) {
                            BaseEx.openPicker( app_select_title, app_collection_data, app_laber_name, function( params ){
                                BaseEx.setSelectValue( app_id, params[ app_key_name ] );
                                fun( params );
                            }, null, order, _clearFun_, formatter );
                        }
                    };
                }
            }
            select_fun.bind( el );
            select_fun( e );
        },
        _icon_click_ : function ( e ) {
            if ( this.title_icon && this.icon_click ) {
                var fun = eval( this.icon_click.split("(")[0] );
                if ( JSUtil.isFunction( fun ) ) {
                    
                    var _params_ = JSUtil._getFunctionParams_( this.icon_click );
                    fun.apply( el.querySelector( ".jyb_text_title_icon" ), _params_ );

                }
            }
        }
    }
});