/*
 * app-list-c：列表c，服务包信息列表。有单选和滑动功能
 * @param {String} app_id id标识
 * @param {String} show 是否显示
 * @param {String} doctorname 医师名称字段
 * @param {String} districtname 行政区名称字段
 * @param {String} hospname 医院名称字段
 * @param {String} list_data 列表json数据
 * @param {String} on_select 单选事件
 * @param {String} on_click_info 显示服务包信息事件
 * @param {String} on_click_confuse 拒绝邀请事件
 */
Vue.component('app-list-c', {
    props : { app_id : String, 
              show : String, 
              doctorname : String, 
              districtname : String, 
              hospname : String, 
              list_data : String, 
              on_select : String, 
              on_click_info : String, 
              on_click_confuse : String 
            },
    template : `<div class="_list_c_" v-bind:app_id="app_id" v-bind:id="app_id" v-show="show != 'none'" _app_tag_="app-list-c" v-bind:doctorname="doctorname" v-bind:districtname="districtname" v-bind:hospname="hospname" v-bind:list_data="list_data" v-bind:on_select="on_select" v-bind:on_click_info="on_click_info" v-bind:on_click_confuse="on_click_confuse" >
                    <div v-for="(item, index) in _toArray_(list_data)" class="_list_row_c_" :_row_data_="JSON.stringify( item )" >
                        <div class="_list_left_c_" >
                            <div class="_list_font_c_" style="width:40%;" >{{ item[ doctorname ] }}</div>
                            <div class="_list_font_c_ _service_info_" style="width:40%;text-align: right;float: right;text-decoration:underline;color:#3d97ea;" @click="_fn_show_info_( $event )" >服务包信息></div>
                            <div class="_list_font_c_" style="height:1rem;line-height:0.5rem;overflow:hidden;text-overflow: ellipsis;text-overflow: -o-ellipsis-lastline;" >{{ item[ districtname ] }}-{{ item[ hospname ] }}</div>
                        </div>
                        <div class="_list_center_c_ _select_fun_" @click="_select_fun_( $event )" >
                            <div class="_list_icon_c_ _app_radio_uncheck_" ></div>
                        </div>
                        <div class="_list_right_c_ _fn_confuse_" @click="_fn_confuse_( $event )" >
                            <div style="height:25%;color:white;" >拒 绝</div>
                            <div style="height:25%;color:white;" >邀 请</div>
                        </div>
                    </div>
                    <div style="clear:both;"></div>
                </div>`,
    mounted : function () {
        // this._fn_();
        this._fn2_();
    },
    methods : {
        _toArray_ : function ( str ) {
          // console.log( str );
          var _str;
          if ( typeof str == "string" ) {
              _str = eval(str);
          } else {
              _str = str;
          }
          // console.log( _str );
          return _str;
        },
        _fn_ : function () {
            $("._list_row_c_").on("touchstart", function(e) {
        　　　　 // e.preventDefault();
                // console.log( "start---------------------------------------" );

                var startX = e.originalEvent.changedTouches[0].pageX;
                var startFlag = $(this).css( "left" ).replace( "px", "" );

                // console.log( "startX:" + startX );

                $(this).unbind( "touchmove" );
                $(this).unbind( "touchend" );

                $(this).on("touchmove", function(e) {
            　　　　 e.preventDefault();

                    var left = $(this).css( "left" ).replace( "px", "" );
                    var width = $(this.parentNode).width();
                    
            　　　　 moveEndX = e.originalEvent.changedTouches[0].pageX,
            　　　　 X = moveEndX - startX;

                    // console.log( "moveEndX:" + moveEndX );
                    // console.log("startFlag：" + startFlag);
                    // console.log("X：" + X);
                    // console.log("left：" + left);
                    // console.log("width：" + width);
                    // console.log("left/width：" + left/width);

                    if ( startFlag < 0 && X > 0 ) {  // 右滑
                        if ( X/width >= -0.25 && X <= width*0.25 ) {
                            $(this).css( "left", X + "px" );
                        } else {
                            $(this).css( "left", "" );
                        }
                    }

                    if( startFlag == 0 && X < 0 ){  // 左滑
                        if ( X/width <= -0.25 ) {
                            $(this).css( "left", ( width * -0.25 ) + "px");
                        } else {
                            $(this).css( "left", X + "px"  );
                        }
                    }

            　　});

                $(this).on("touchend", function(e) {
            　　　　 // e.preventDefault();
                    var left = $(this).css( "left" ).replace( "px", "" );
                    var width = $(this.parentNode).width();

                    // console.log( "end---------------------------------------" );
                    // console.log( "left_end:" + left );
                    // console.log( "width_end:" + width );

            　　　　 if ( startFlag == 0 && left/width <= -0.07 ) {
                        $(this).css( "left", width * -0.25 );
                        return;
            　　　　 }
                    if ( startFlag < 0 && left/width >= -0.15 ) {
                        $(this).css( "left", "" );
                        return;
                    }
                    if( left/width != -0.25 ){
                        $(this).css( "left", "" );
                    }
                    
                    $(this).unbind( "touchmove" );
                    $(this).unbind( "touchend" );
            　　});
        　　});
        },
        _fn2_ : function () {

            var __fn_touchmove__ = function ( e ) {
        　　　　 e.preventDefault();

                var startX = this.getAttribute( "startX" );
                var startFlag = this.getAttribute( "startFlag" );

                // var left = $(this).css( "left" ).replace( "px", "" );
                var left = JSUtil.css( this, "left" ).replace( "px", "" );
                // var width = $(this.parentNode).width();
                var width = this.parentNode.offsetWidth;
                
        　　　　 var moveEndX = e.changedTouches[0].pageX,
        　　　　 X = moveEndX - startX;

                // console.log( "moveEndX:" + moveEndX );
                // console.log("startFlag：" + startFlag);
                // console.log("X：" + X);
                // console.log("left：" + left);
                // console.log("width：" + width);
                // console.log("left/width：" + left/width);

                if ( startFlag < 0 && X > 0 ) {  // 右滑
                    if ( X/width >= -0.25 && X <= width*0.25 ) {
                        // $(this).css( "left", X + "px" );
                        JSUtil.css( this, "left", X + "px" );
                    } else {
                        // $(this).css( "left", "" );
                        JSUtil.css( this, "left", "" );
                    }
                }

                if( startFlag == 0 && X < 0 ){  // 左滑
                    if ( X/width <= -0.25 ) {
                        // $(this).css( "left", ( width * -0.25 ) + "px");
                        JSUtil.css( this, "left", ( width * -0.25 ) + "px");
                    } else {
                        // $(this).css( "left", X + "px" );
                        JSUtil.css( this, "left", X + "px" );
                    }
                }
            };

            var __fn_touchend__ = function ( e ) {
        　　　　 // e.preventDefault();
                var startX = this.getAttribute( "startX" );
                var startFlag = this.getAttribute( "startFlag" );
                // var left = $(this).css( "left" ).replace( "px", "" );
                var left = JSUtil.css( this, "left" ).replace( "px", "" );
                // var width = $(this.parentNode).width();
                var width = this.parentNode.offsetWidth;

                // console.log( "end---------------------------------------" );
                // console.log( "startX_end:" + startX );
                // console.log( "startFlag_end:" + startFlag );
                // console.log( "left_end:" + left );
                // console.log( "width_end:" + width );

        　　　　 if ( startFlag == 0 && left/width <= -0.07 ) {
                    // $(this).css( "left", width * -0.25 );
                    JSUtil.css( this, "left", width * -0.25 + "px" );
                    return;
        　　　　 }
                if ( startFlag < 0 && left/width >= -0.15 ) {
                    // $(this).css( "left", "" );
                    JSUtil.css( this, "left", "" );
                    return;
                }
                if( left/width != -0.25 ){
                    // $(this).css( "left", "" );
                    JSUtil.css( this, "left", "" );
                }
                
                // $(this).unbind( "touchmove" );
                // $(this).unbind( "touchend" );
                JSUtil.removeHandle( this, "touchmove", __fn_touchmove__ );
                JSUtil.removeHandle( this, "touchend", __fn_touchend__ );
            }

            var list = document.querySelectorAll("._list_row_c_");

            var el;
            for (var i = 0; i < list.length; i++) {
                el = list[i];

                JSUtil.addHandle( el, "touchstart", function(e) {
            　　　　 // e.preventDefault();
                    // console.log( "start---------------------------------------" );

                    var startX = e.changedTouches[0].pageX;
                    // var startFlag = $(this).css( "left" ).replace( "px", "" );
                    var startFlag = JSUtil.css( this, "left" ).replace( "px", "" );

                    el.setAttribute( "startX", startX );
                    el.setAttribute( "startFlag", startFlag );

                    // console.log( "startX:" + startX );

                    // $(this).unbind( "touchmove" );
                    // $(this).unbind( "touchend" );
                    JSUtil.removeHandle( this, "touchmove", __fn_touchmove__ );
                    JSUtil.removeHandle( this, "touchend", __fn_touchend__ );

                    JSUtil.addHandle( this, "touchmove", __fn_touchmove__ );
                    JSUtil.addHandle( this, "touchend", __fn_touchend__ );

            　　});

            }
        },

        _select_fun_ : function ( e ) {
            e.stopPropagation();

            var obj = e.currentTarget;
            var radio_base = obj.parentNode.parentNode;
            var array = radio_base.querySelectorAll( "._list_icon_c_" );
            for (var i = 0; i < array.length; i++) {
                array[i].className = "_list_icon_c_ _app_radio_uncheck_";
            }
            obj.querySelector( "._list_icon_c_" ).className = "_list_icon_c_ _app_radio_checked_";

            if ( this.on_select ) {
              var fun = eval( this.on_select.split("(")[0] );
              if ( typeof fun == "function" ) {
                  fun( JSON.parse( obj.parentNode.getAttribute( "_row_data_" ) ) );
              }
            }
        },
        _fn_confuse_ : function ( e ) {
            e.stopPropagation();
            
            var obj = e.currentTarget;
            if ( this.on_click_confuse ) {
              var fun = eval( this.on_click_confuse.split("(")[0] );
              if ( typeof fun == "function" ) {
                  fun( JSON.parse( obj.parentNode.getAttribute( "_row_data_" ) ) );
              }
            }
        },
        _fn_show_info_ : function ( e ) {
            e.stopPropagation();
            
            var obj = e.currentTarget;
            if ( this.on_click_info ) {
              var fun = eval( this.on_click_info.split("(")[0] );
              if ( typeof fun == "function" ) {
                  fun( JSON.parse( obj.parentNode.parentNode.getAttribute( "_row_data_" ) ) );
              }
            }
        }
    }

});