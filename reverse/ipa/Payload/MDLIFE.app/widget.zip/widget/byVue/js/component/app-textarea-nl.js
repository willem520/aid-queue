/*
 * 文本框：
 * @param {String} app_id id标识
 * @param {String} app_key 文本框名称
 * @param {String} app_value 值
 * @param {String} show 是否显示：true显示，none隐藏
 * @param {String} disabled 是否可触发点击事件，包括title_icon_click和onclick
 * @param {String} border_bottom 是否显示下划线，默认显示
 * @param {String} app_type 文本type
 * @param {String} validate 验证方法
 * @param {String} span ta-box中的布局参数
 * @param {String} maxlength 最大输入字符数
 * @param {String} _is_key_flag_ 用于判断显示样式
 */
Vue.component('app-textarea-nl', {
    props : { app_id : String, 
              app_key : String, 
              app_value : String, 
              show : String, 
              value_ellipsis : String, 
              border_bottom : String, 
              app_type : String, 
              validate : String, 
              span : String, 
              maxlength : String, 
              _is_key_flag_ : {
                  type: Boolean, 
                  default : true 
              } 
            },
    template : `<div v-bind:app_id="app_id" class="jyb_text" v-show="show != 'none'" _app_tag_="app-textarea-nl" v-bind:span="span" v-bind:app_key="app_key" v-bind:_is_key_flag_="_is_key_flag_" @propertychange="_propertychange_( $event )" >

                    <div class="jyb_text_div" v-bind:class="{ jyb_text_border_bottom : _border_bottom_( border_bottom ) }" >
                        <textarea v-bind:id="app_id" v-bind:type="app_type == null ? 'text' : app_type" v-bind:maxlength="maxlength" @input="_input_( $event )" @focus="_focus_( $event )" @blur="_blur_( $event )" class="_app_input_input_ jyb_detail" v-bind:class="{ text_key_color : _is_key_flag_, text_value_color : !_is_key_flag_ }" style="text-align:left;border:0px;margin-bottom:0.2rem;height:0.4rem;" v-bind:value="app_value" ></textarea>
                    </div>

                    <div style="clear:both;"></div>
                </div>`,
    created : function () {
        if ( this.app_value && JSUtil.isNotEmpty( this.app_value ) ) {
            this._is_key_flag_ = false;
        } else {
            this.app_value = this.app_key;
        }
        
    },
    mounted : function () {
        var el = this.$el;
        var textarea = el.querySelector( "textarea" );
        textarea.setAttribute( "_original_height_", textarea.offsetHeight );
    },
    methods : {
        _focus_ : function ( e ) {
            var el = e.currentTarget;
            var value = el.value;
            if ( value && value == this.app_key ) {
                el.value = "";
                this.app_value = "";
            } else {
                this.app_value = value;
            }
            // this._is_key_flag_ = false;
            el.className = el.className.replace( "text_key_color", "text_value_color" );
            this._changeHeight_( e );
            this._validate_( e );
        },
        _blur_ : function ( e ) {
            var el = e.currentTarget;
            var value = el.value;
            if ( !value || JSUtil.isEmpty( value ) ) {
                el.value = this.app_key;
                this.app_value = this.app_key;
                // this._is_key_flag_ = true;
                el.className = el.className.replace( "text_value_color", "text_key_color" );
            } else {
                this.app_value = el.value;
            }
            this._changeHeight_( e );
        },
        _border_bottom_ : function ( border_bottom ) {
            if ( border_bottom && ( border_bottom == "false" || border_bottom == "none" ) ) {
                return false;
            } else {
                return true;
            }
        },
        _validate_ : function ( e ) {
            // var flag_type = true, flag = true, tip = null;
            // // console.log( this );
            var input_el = e.currentTarget;

            // if ( this.app_type ) {
            //     // flag_type = BaseEx.validateInput( input_el.value, this.app_type );
            //     var re = BaseEx._validate_[ this.app_type ]( input_el.value );
            //     flag_type = re[ 0 ];
            //     tip = re[ 1 ];
            // }

            // if ( this.validate && JSUtil.isFunction( this.validate ) ) {
            //     var fun = eval( this.validate.split("(")[0] );
            //     var ret = fun( input_el.value );
            //     flag = ret[0];
            //     tip = ret[1];
            // }

            // // 验证结果：
            // if ( !flag_type || !flag ) { // 未通过
            //     if ( input_el.className.indexOf( "jyb_validate_input" ) < 0 ) {
            //         input_el.className += " jyb_validate_input";

            //         var tip_div = document.createElement( "div" );
            //         var bind_target = document.querySelector("div[_app_tag_='app-body']") || document.body;
            //         tip_div.id = this.app_id + "_validate_";
            //         tip_div.className = "_validate_tip_";
            //         tip_div.innerHTML = tip ;
            //         tip_div.style.top = ( JSUtil.top( input_el ) - JSUtil.remToPx( 0.4 ) - JSUtil.top( bind_target ) ) + "px";
            //         tip_div.style.right = ( bind_target.offsetWidth - JSUtil.left( input_el ) - input_el.offsetWidth - JSUtil.left( bind_target ) ) + "px";

            //         bind_target.appendChild( tip_div );

            //     }
            // } else { // 通过
            //     // debugger;
            //     if ( input_el.className.indexOf( "jyb_validate_input" ) >= 0 ) {
            //         input_el.className = input_el.className.replace( " jyb_validate_input", "" );
            //         var tip_div = document.querySelector( "#" + this.app_id + "_validate_" );
            //         if ( tip_div ) {
            //             JSUtil.remove( tip_div );
            //         }
            //     }
            // }
            BaseEx._app_validate_( input_el, this.app_type, this.validate );
        },
        _input_ : function ( e ) {
            var input_el = e.currentTarget;
            if ( this.app_type ) {
                var value = BaseEx._type_[ this.app_type ]( input_el.value );
                input_el.value = value;
                this.app_value = value;
            }
            this._changeHeight_( e );
            this._validate_( e );
        },
        _propertychange_ : function ( e ) {
            this._changeHeight_( e );
        },
        _changeHeight_ : function ( e ) {
            var elm = e.currentTarget;
            BaseEx.vueCommon.appTextareaNl._changeHeight_( elm );
        }
    }
});