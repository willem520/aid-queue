/*
 * app-list-item：配合列表标签app-list使用
 * @param {String} app_id id标识
 * @param {String} app_key 列字段
 * @param {String} app_width 列宽度
 * @param {String} formatter 格式化值方法
 */
Vue.component('app-list-item', {
    // props : [ 'app_id', 'app_key', 'app_width', 'formatter' ],
    props : { app_id : String,
              app_key : String,
              app_width : String,
              formatter : String
            },
    template : ``
});