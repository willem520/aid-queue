/*
 * app-box：布局模块
 * @param {String} app_id id标识
 * @param {String} app_key 预留属性，暂时没有用
 * @param {String} cols 一行显示列数
 * @param {String} cols_config 每列显示比例（例如：3:3:4）
 * @param {String} show 是否显示
 */
Vue.component('app-box', {
    props : { app_id : String, 
              app_key : String, 
              cols : String, 
              cols_config : String, 
              show : String 
            },
    template : `<div v-bind:app_id="app_id" :id="app_id" class="_app_box_" _app_tag_="app-box" v-show="show != 'none'" >
                    <slot></slot>
                    <div style="clear:both;"></div>
                </div>`,
    created : function () { // 添加id
        if ( !this.app_id || JSUtil.isEmpty( this.app_id ) ) {
            var obj = document.querySelector( "app-box" );
            this.app_id = ( Math.random() + "" ).replace( ".", "" );
            obj.setAttribute( "app_id", this.app_id );
        }
    },
    mounted : function () {

        // console.log( this );

        // debugger;

        // 实现布局
        var cols = parseInt( this.cols );
        var cols_config = this.cols_config;
        if ( cols && cols > 1 ) {
            var per_width = new Array( cols );
            if ( cols_config && JSUtil.isNotEmpty( cols_config ) && cols_config.split( ":" ).length == cols ) {
                var config = cols_config.split( ":" );
                config.forEach( function( value, index, array ){
                    array[index] = parseFloat( array[index] );
                } );;
                var sum = JSUtil.array_sum( config );
                for (var i = 0; i < per_width.length; i++) {
                    per_width[i] = 100 * config[i] / sum ;
                }
            } else {
                per_width.forEach( function( value, index, array ){
                    array[index] = 100 / cols;
                } );
            }

            // console.log( per_width );
            var obj = BaseEx.getObj( this.app_id );

            var el_list = obj.children;
            var el,new_el,span,count = 0;
            for (var i = 0; i < el_list.length - 1; i++) {
                el = el_list[i];
                if ( el.style.display == "none" || el.getAttribute( "show" ) == "none" ) {
                    continue;
                }
                // new_el = document.createElement( "div" );
                // new_el.style.width = per_width[ count % cols ] + "%";
                // new_el.style.float = "left";
                // new_el.appendChild( el.cloneNode( true ) );
                // el.parentNode.replaceChild( new_el, el );

                span = el.getAttribute( "span" );
                if ( span && JSUtil.isNumber( span ) ) {
                    if ( span <= cols ) {

                        count += Math.ceil( span );

                        el.style.width = ( 100 / cols * span ) + "%";
                        el.style.float = "left";
                        continue;
                    }
                }
                el.style.width = per_width[ count % cols ] + "%";
                el.style.float = "left";

                count ++;
            }

        }

    }

});