/*
 * app-body：配合BaseEx.layout方法，解决留海屏幕兼容问题
 * @param {String} app_id id标识
 * @param {String} app_key 预留属性，暂时没有用
 * @param {String} show 是否显示
 */
Vue.component('app-body', {
    // props : [ 'app_id', 'app_key', 'show' ],
    props : { app_id : String,
              app_key : String,
              show : String
            },
    template : `<div v-bind:app_id="app_id" class="_app_body_"  _app_tag_="app-body" v-show="show != 'none'" >
                    <slot></slot>
                </div>`,
    mounted : function () {
        var obj = this.$el;
        var title = document.querySelector( "div[_app_tag_='app-title']" );
        var title_height = title.offsetHeight;
        var window_height = document.body.clientHeight;

        obj.style.height = ( window_height - title_height ) + "px";
    }
});