/*
 * 单选项：
 * @param {String} app_id id标识
 * @param {String} app_key 选项名称
 * @param {String} app_value 默认值
 * @param {String} app_laber_name 标签字段
 * @param {String} app_value_name 值字段
 * @param {String} app_collection_data json数据
 * @method {String} on_select 选择回调
 * @param {String} show 是否显示
 * @param {String} _original_html_ html代码
 */
Vue.component('app-radio', {
    // props : [ 'app_id', 'app_key', 'app_value', 'app_laber_name', 'app_value_name','app_collection_data', 'on_select', 'show', '_original_html_' ],
    props : { app_id : String,
              app_key : String,
              app_value : String,
              app_laber_name : String,
              app_value_name : String,
              app_collection_data : String,
              on_select : String,
              show : String,
              _original_html_ : String
            },
    template : `<div v-bind:app_id="app_id" class="_app_radio_"  _app_tag_="app-radio" v-show="show != 'none'" v-bind:app_key="app_key" v-bind:app_value="app_value" v-bind:app_laber_name="app_laber_name" v-bind:app_value_name="app_value_name" v-bind:app_collection_data="app_collection_data" v-bind:on_select="on_select" v-bind:_original_html_="_original_html_">
                    <div v-for="(_radio_, index) in _toArray_(app_collection_data)" :key="_radio_[ app_value_name ]" class="_app_radio_option_" @click="_select_fun_( $event )" v-bind:_app_laber_="_radio_[ app_laber_name ]" v-bind:_app_value_="_radio_[ app_value_name ]" v-bind:_radio_option_="JSON.stringify( _radio_ )" >
                        <div class="_app_radio_laber_" >{{_radio_[ app_laber_name ]}}</div>
                        <div class="_app_radio_value_" >
                            <div v-if="_radio_[ app_value_name ] == app_value" class="_app_radio_icon_ _app_radio_checked_" ></div>
                            <div v-else class="_app_radio_icon_ _app_radio_uncheck_" ></div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>
                </div>`,
    created : function () {
        var obj = BaseEx.getObj( this.app_id );
        this._original_html_ = encodeURIComponent( JSUtil.domToString( obj ) );
    },
    methods : {
        _toArray_ : function ( str ) {
          var _str = eval(str);
          // console.log(_str);
          // alert( this.hospital_name );
          return _str;
        },
        _select_fun_ : function ( e ) {
            var obj = e.currentTarget;
            var radio_base = obj.parentNode;
            var array = radio_base.querySelectorAll( "._app_radio_icon_" );
            for (var i = 0; i < array.length; i++) {
                array[i].className = "_app_radio_icon_ _app_radio_uncheck_";
            }
            obj.querySelector( "._app_radio_icon_" ).className = "_app_radio_icon_ _app_radio_checked_";
            if ( this.on_select ) {
                var fun = eval( this.on_select.split("(")[0] );
                if ( typeof fun == "function" ) {
                    fun( obj.getAttribute( "_app_laber_" ), obj.getAttribute( "_app_value_" ), JSON.parse( obj.getAttribute( "_radio_option_" ) ) );
                }
            }
        }
    }
});