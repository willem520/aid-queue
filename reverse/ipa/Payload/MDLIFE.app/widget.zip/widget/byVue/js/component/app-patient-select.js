/*
 * 医保账户选项：
 * @param {String} app_id id标识
 * @param {String} app_data 传入json数据
 * @param {String} on_select 选择回调
 */
Vue.component('app-patient-select', {
    // props : [ 'app_id', 'app_data', 'on_select' ],
    props : { app_id : String, 
              app_data : String, 
              on_select : String
            },
    template : `<div v-bind:app_id="app_id" v-bind:id="app_id" _app_tag_="app-patient-select" class="_patient_select_" v-bind:app_data="app_data" >
                  <input id="buid" class="buid" style="display:none;" :value="JSON.parse( app_data )[ 'buid' ]" />
                  <img src="../../static/jybimage/bindPeopleImg.png" class="_patient_select_head_" />
                  <div class="bindInfo">
                      <p id="buname" class="buname text_value_color" style="margin-top:0.2rem;" _app_attribute_="buname" >{{ JSON.parse( app_data )[ "buname" ] }}</p>
                      <p class="text_key_color _patient_select_ssc_" >社保账户：<span id="bussc"  _app_attribute_="bussc">{{ JSON.parse( app_data )[ "bussc" ] }}</span></p>
                  </div>
                  <div style="float:right;margin-right: 0.5rem;height: 100%;">
                      <div class="change_button _patient_select_button_" align="center" @click="_select_fun_( $event )" >更换</div>
                  </div>
              </div>`,
    methods : {
        _select_fun_ : function ( e ) {
            if ( this.on_select ) {
              // 绑定点击事件
              var fun = eval( this.on_select.split("(")[0] );
              if ( typeof fun == "function" ) {
                  var obj = e.currentTarget;
                  var buname = obj.parentNode.parentNode.querySelector( "#buname" ).innerText;
                  var buid = obj.parentNode.parentNode.querySelector( "#buid" ).value;
                  var bussc = obj.parentNode.parentNode.querySelector( "#bussc" ).value;
                  var data = JSON.stringify( obj.parentNode.parentNode.getAttribute( "app_data" ) );
                  fun( buname, buid, data );
              }

            }
        }
    }
});