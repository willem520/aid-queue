/*
 * 按钮：
 * @param {String} app_id id标识
 * @param {String} app_key 按钮名称
 * @param {String} show 是否显示
 */
Vue.component('app-button', {
    // props: [ 'app_id', 'app_key', 'show' ],
    props: { app_id : String,
             app_key : String,
             show : String
           },
    template:`<div class="app_button" v-bind:app_id="app_id" v-bind:id="app_id" v-show="show != 'none'" _app_tag_="app-button" >
        				{{ app_key }}<slot v-if=" typeof app_key == 'undefined' || app_key == '' " ></slot>
        			</div>`
});