/* 列表b */
/*Vue.component('app-list-b', {
  props : { app_id : String, show : String, hospital_name : String, hospital_address : String, hospital_level : String, hospital_level_name : String, hospital_tel : String, hospital_coordinate : String, hospital_data : String },
  template : `<div v-bind:app_id="app_id" _app_tag_="app-list-b" >
                  <div v-for="(item, index) in _toArray_(app_list_data)" :key="index" class="jiayi_list" @click="_fn_()">
                      <div class="jiayi_name">{{ item.buname }}</div>

                      <template v-if="item.status == 0" >
                          <div class="jiayi_status jy_unapply">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area" style="color:#fa9442;"></div>
                          </div>
                      </template>

                      <template v-if="item.status == 1" >
                          <div class="jiayi_status jy_receive">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area">{{ item.districtname }}<br/><span>{{ item.hospname }}</span></div>
                              <template v-if="item.teamname != ''" >
                                  <div class="jiayi_area"><span>邀请医师：{{ item.doctorname }}</span></div>
                                  <div class="jiayi_area">{{ item.teamname }}&nbsp;&nbsp;<span>受邀时间：'+applytime+'</span></div>
                              </template>
                          </div>
                      </template>

                      <template v-if="item.status == 0" >
                          <div class="jiayi_status jy_unapply">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area" style="color:#fa9442;"></div>
                          </div>
                      </template>

                      <template v-if="item.status == 0" >
                          <div class="jiayi_status jy_unapply">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area" style="color:#fa9442;"></div>
                          </div>
                      </template>

                      <template v-if="item.status == 0" >
                          <div class="jiayi_status jy_unapply">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area" style="color:#fa9442;"></div>
                          </div>
                      </template>

                      <template v-if="item.status == 0" >
                          <div class="jiayi_status jy_unapply">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area" style="color:#fa9442;"></div>
                          </div>
                      </template>

                      <template v-if="item.status == 0" >
                          <div class="jiayi_status jy_unapply">{{ item.statusname }}</div>
                          <div style="padding-left:3%;">
                              <div class="jiayi_area" style="color:#fa9442;"></div>
                          </div>
                      </template>

                      <div style="clear:both;"></div>
                  </div>
              </div>`,
  methods : {
    _toArray_ : function ( str ) {
      var _str = eval(str);
      console.log(_str);
      // alert( this.hospital_name );
      return _str;
    },
    _fn_ : function () {

    }

  }
});*/