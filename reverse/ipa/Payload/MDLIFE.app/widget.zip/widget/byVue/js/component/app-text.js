/*
 * 文本框：
 * @param {String} app_id id标识
 * @param {String} app_key 文本框名称
 * @param {String} app_value 值
 * @param {String} arrow_icon 右侧箭头图标，指定图标文件路径
 * @param {String} show_arrow_icon 是否显示右侧箭头图标
 * @param {String} editable 是否可编辑
 * @param {String} show 是否显示：true显示，none隐藏
 * @param {String} show_must 是否必填
 * @param {String} title_icon 左侧图标
 * @method {String} title_icon_click 左侧图标点击事件
 * @param {String} disabled 是否可编辑
 * @param {String} value_ellipsis 是否省略显示过长的值
 * @param {String} border_bottom 是否显示下划线，默认显示
 * @param {String} app_type 文本框type
 * @param {String} validate 验证输入
 * @param {String} maxlength 最大长度
 * @param {String} placeholder 输入提示
 * @param {String} key_style 名称样式
 * @param {String} value_style 值样式
 */
Vue.component('app-text', {
    // props : [ 'app_id','app_key','app_value','editable','arrow_icon','show_arrow_icon', 'show', 'title_icon', 'title_icon_click', 'disabled', 'value_ellipsis', 'border_bottom', 'app_type', 'validate', 'maxlength', 'key_style', 'value_style' ],
    props : { app_id : String,
              app_key : String,
              app_value : String,
              editable : String,
              arrow_icon : String,
              show_arrow_icon : String,
              show : String, 
              show_must : String,
              title_icon : String, 
              title_icon_click : String, 
              disabled : String, 
              value_ellipsis : String, 
              border_bottom : String, 
              app_type : String, 
              validate : String, 
              maxlength : String, 
              placeholder : String,
              key_style : String, 
              value_style : String
            },
    template : `<div v-bind:app_id="app_id" class="jyb_text" v-show="show != 'none'"  @click="_fn_( $event )" _app_tag_="app-text" v-bind:disabled="disabled" >
                  
                  <div v-if="title_icon != null" class="jyb_text_div" v-bind:class="{ jyb_text_border_bottom : _border_bottom_( border_bottom ) }" >
                    <img v-if="title_icon_click != null" class="jyb_text_title_icon" v-bind:src="title_icon" @click="_tf_( $event )"></img>
                    <img v-else class="jyb_text_title_icon" v-bind:src="title_icon" ></img>

                    <div class="jyb_text_key jyb_detail text_key_color" style="margin-left:0.4rem;" v-bind:style="key_style" ><span v-show="show_must  == 'true'" style="color: red;">* </span>{{ app_key }}</div>
                    <input v-if="editable == 'true'" v-bind:id="app_id" v-bind:type="app_type == null ? 'text' : app_type" @focus="_validate_( $event )" @input="_input_( $event )" class="jyb_text_input jyb_detail text_value_color" style="text-align:right;" v-bind:value="app_value" v-bind:style="value_style" v-bind:placeholder="placeholder" />
                    <div v-else v-bind:id="app_id" class="jyb_text_value jyb_detail text_value_color" v-bind:class="{ css_ellipsis:value_ellipsis }" v-bind:style="value_style" >{{app_value}}</div>
                    <img v-if="arrow_icon != null" v-show="show_arrow_icon  == 'true'" class="jyb_text_arrow" v-bind:src="arrow_icon"></img>
                    <img v-else v-show="show_arrow_icon == 'true'" class="jyb_text_arrow" src="../../static/jybimage/arrow_right.png"></img>
                  </div>

                  <div v-else class="jyb_text_div" v-bind:class="{ jyb_text_border_bottom : _border_bottom_( border_bottom ) }" >
                    <div class="jyb_text_key jyb_detail text_key_color" v-bind:style="key_style" ><span v-show="show_must  == 'true'" style="color: red;">* </span>{{ app_key }}</div>
                    <input v-if="editable == 'true'" v-bind:id="app_id" v-bind:type="app_type == null ? 'text' : app_type" @focus="_validate_( $event )" @input="_input_( $event )" class="jyb_text_input jyb_detail text_value_color" style="text-align:right;" v-bind:maxlength = "maxlength" v-bind:value="app_value" v-bind:style="value_style" v-bind:placeholder="placeholder" />
                    <div v-else v-bind:id="app_id" class="jyb_text_value jyb_detail text_value_color" v-bind:class="{ css_ellipsis:value_ellipsis }" v-bind:style="value_style" >{{app_value}}</div>
                    <img v-if="arrow_icon != null" v-show="show_arrow_icon  == 'true'" class="jyb_text_arrow" v-bind:src="arrow_icon"></img>
                    <img v-else v-show="show_arrow_icon == 'true'" class="jyb_text_arrow" src="../../static/jybimage/arrow_right.png"></img>
                  </div>
                  <div style="clear:both;"></div>
                </div>`,
    methods : {
        _fn_ : function ( e ) {
               var el = e.currentTarget;
               var disabled = el.getAttribute( "disabled" );
               if ( typeof disabled != "undefined" && JSUtil.isNotEmpty( disabled ) ){
                  e.preventDefault();
                  e.stopPropagation();
               }
               var input = el.querySelector( "input" );
               if ( input ) {
                   input.focus();
               }
        },
        _tf_ : function ( e ) {
               e.stopPropagation();
               var el = e.currentTarget;
               var title_icon_click = this.title_icon_click;
               if( title_icon_click ){
                    var fun = eval( title_icon_click.split( "(" )[ 0 ] );
                    var _params_ = JSUtil._getFunctionParams_( title_icon_click );
                    var disabled = el.parentNode.parentNode.getAttribute( "disabled" );
                    if( typeof disabled == "undefined" || JSUtil.isEmpty( disabled ) ){
                        fun.apply( el.querySelector( ".jyb_text_title_icon" ), _params_ );
                    }
               }
        },
        _border_bottom_ : function ( border_bottom ) {
            if ( border_bottom && ( border_bottom == "false" || border_bottom == "none" ) ) {
                return false;
            } else {
                return true;
            }
        },
        _validate_ : function ( e ) {
            // var flag_type = true, flag = true, tip = null;
            // // console.log( this );
            var input_el = e.currentTarget;

            // if ( this.app_type ) {
            //     // flag_type = BaseEx.validateInput( input_el.value, this.app_type );
            //     var re = BaseEx._validate_[ this.app_type ]( input_el.value );
            //     flag_type = re[ 0 ];
            //     tip = re[ 1 ];
            // }

            // if ( this.validate && JSUtil.isFunction( this.validate ) ) {
            //     var fun = eval( this.validate.split("(")[0] );
            //     var ret = fun( input_el.value );
            //     flag = ret[0];
            //     tip = ret[1];
            // }

            // // 验证结果：
            // if ( !flag_type || !flag ) { // 未通过
            //     if ( input_el.className.indexOf( "jyb_validate_input" ) < 0 ) {
            //         input_el.className += " jyb_validate_input";

            //         var tip_div = document.createElement( "div" );
            //         var bind_target = document.querySelector("div[_app_tag_='app-body']") || document.body;
            //         tip_div.id = this.app_id + "_validate_";
            //         tip_div.className = "_validate_tip_";
            //         tip_div.innerHTML = tip ;
            //         tip_div.style.top = ( JSUtil.top( input_el ) - JSUtil.remToPx( 0.4 ) - JSUtil.top( bind_target ) ) + "px";
            //         tip_div.style.right = ( bind_target.offsetWidth - JSUtil.left( input_el ) - input_el.offsetWidth - JSUtil.left( bind_target ) ) + "px";

            //         bind_target.appendChild( tip_div );

            //     }
            // } else { // 通过
            //     if ( input_el.className.indexOf( "jyb_validate_input" ) >= 0 ) {
            //         input_el.className = input_el.className.replace( " jyb_validate_input", "" );
            //         var tip_div = document.querySelector( "#" + this.app_id + "_validate_" );
            //         if ( tip_div ) {
            //             JSUtil.remove( tip_div );
            //         }
            //     }
            // }
            
            BaseEx._app_validate_( input_el, this.app_type, this.validate );
        },
        _input_ : function ( e ) {
            var _restricted_input_ = function ( e ) {
                var input_el = e.currentTarget;
                if ( this.app_type ) {
                    var value = BaseEx._type_[ this.app_type ]( input_el.value );
                    input_el.value = value;
                    this.app_value = value;
                }
            };
            
            _restricted_input_( e );
            this._validate_( e );
        }
    }
});