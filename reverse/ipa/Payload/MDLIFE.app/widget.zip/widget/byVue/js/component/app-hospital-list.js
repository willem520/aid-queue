/*
 * 医院列表其一：
 * @param {String} app_id id标识
 * @param {String} show 是否显示
 * @param {String} hospital_name 医院名称字段
 * @param {String} hospital_address 医院地址字段
 * @param {String} hospital_level 医院等级字段
 * @param {String} hospital_level_name 医院等级名称字段
 * @param {String} hospital_tel 医院电话字段
 * @param {String} hospital_coordinate 医院坐标字段
 * @param {String} hospital_data json数据
 * @param {String} show_arrow_icon 显示箭头
 * @method {String} on_row_click 行点击
 */
Vue.component('app-hospital-list', {
    props : { app_id : String, 
              show : String, 
              hospital_id : String, 
              hospital_name : String, 
              hospital_address : String, 
              hospital_level : String, 
              hospital_level_name : String, 
              hospital_tel : String, 
              hospital_coordinate : String, 
              hospital_data : String, 
              show_arrow_icon : String,
              on_row_click : String 
            },
    template : `<div v-bind:app_id="app_id" v-bind:hospital_id="hospital_id" v-bind:hospital_name="hospital_name" v-bind:hospital_address="hospital_address" v-bind:hospital_level="hospital_level" v-bind:hospital_level_name="hospital_level_name" v-bind:hospital_tel="hospital_tel" v-bind:hospital_coordinate="hospital_coordinate" v-bind:on_row_click="on_row_click" class="_hospitals_list_" _app_tag_="app-hospital-list" >
                    <div v-for="(hospital, index) in _toArray_(hospital_data)" :key="hospital[ hospital_name ]" class="_main_list_div_" :hospital_name="hospital[hospital_name]" :hospital_id="hospital[hospital_id]" :hospital_level="hospital[hospital_level]" :hospital_address="hospital[hospital_address]" :hospital_coordinate="hospital[hospital_coordinate]" @click="_fn_row_click_( $event )">
                        <div class="_main_list_content_">
                            <div class="_hospital_name_ css_ellipsis">{{hospital[hospital_name]}}</div>
                            <div style="float: left;margin-top: 0.1rem;width: 95%;">
                                <img src="../../static/jybimage/hospital_icon.png" style="float:left;height:0.4rem;"/>
                                <input class="_hospital_level_" style="display:none;" value="{{hospital[hospital_level]}}"></input>
                                <div class="_hospital_level_name_" >{{hospital[ hospital_level_name ]}}</div>
                                <img src="../../static/jybimage/icon_call.png" style="float:left;height:0.4rem;margin-left:15%;"/>
                                <a class="_hospital_tel_" :href="'tel:' + hospital[hospital_tel]" @click="_fnCall_( $event )" >{{hospital[hospital_tel]}}</a>
                                <div class="_hospital_map_" :hospital_address="hospital[hospital_address]" :hospital_coordinate="hospital[hospital_coordinate]" @click="_fnGoMap_( $event )" >查看地图</div>
                            </div>
                            <div style="width:95%;float: left;margin-top: 0.1rem;">
                                <img src="../../static/jybimage/icon_area_b.png" style="float:left;height:0.4rem;"/>
                                <div class="_hospital_add_" >{{hospital[hospital_address]}}</div>
                            </div>
                            <div class="_hospital_arrow_" v-show="show_arrow_icon != 'none'" >
                                <img style="height: 0.35rem;" src="../../static/jybimage/arrow_right.png"></img>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                    </div>
                </div>`,
    methods : {
        _toArray_ : function ( str ) {
          var _str = eval(str);
          // console.log(_str);
          // alert( this.hospital_name );
          return _str;
        },
        _fnCall_ : function ( e ){
          e.stopPropagation();
          var el = e.currentTarget;
          var tel = el.getAttribute("href").split("tel:")[1];
          MDLifeEx.call( tel );
        },
        _fnGoMap_ : function ( e ){
          e.stopPropagation();
          var el = e.currentTarget;
          var hospital_address = $(el).attr("hospital_address");
          var hospital_coordinate = $(el).attr("hospital_coordinate");
          md.openWin({
              name: 'gomap',
              url: 'wgt://threeTreat/service/gomap.html',
              reload: true,
              pageParam: {
                  aae006 : hospital_address,
                  aab299 : hospital_coordinate
              }
          });
        },
        _fn_row_click_ : function ( e ) {
            e.stopPropagation();
            var el = e.currentTarget;
            var on_row_click = this.on_row_click;
            if ( on_row_click ) {
                var hospital_id = $(el).attr("hospital_id");
                var hospital_name = $(el).attr("hospital_name");
                var hospital_level = $(el).attr("hospital_level");
                var fun = eval( this.on_row_click.split("(")[0] );
                fun ( hospital_id, hospital_name, hospital_level );
            } else {
                _fnGoMap_( e );
            }
        }

    }
});