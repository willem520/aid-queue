/*
 * 标题：
 * @param {String} app_id id标识
 * @param {String} app_key 标题名称
 * @param {String} back_icon 返回上一页图标
 * @param {String} close_icon 关闭页面图标
 * @param {String} top_button_img 右侧图标，值为指定图标文件的路径
 * @method {String} top_button_img_click 右侧图标点击事件
 */
Vue.component('app-title', {
    // props: [ 'app_id', 'app_key', 'back_icon', 'top_button_img', 'top_button_img_click' ],
    props: { app_id : String,
             app_key : String,
             back_icon : String,
             close_icon : String,
             top_button_img : String,
             top_button_img_click : String
           },
    template:`<div v-bind:app_id="app_id" class="header" _app_tag_="app-title" >
    				
                  <div v-if="back_icon == 'false' || back_icon == 'none'" v-bind:id="app_id" class="header_title css_ellipsis" style="margin-left:20%;">
          				    {{ app_key }}<slot v-if=" typeof app_key == 'undefined' || app_key == '' " ></slot>
          				</div>
          				<div v-else class="back" :style="close_icon == 'true' ? 'width: 10%;' : ''">
          				    <img class="back_img" src="../../static/jybimage/icon_back.png" />
          				</div>

                  <div v-if="close_icon == 'true'" class="close">
                      <img class="close_img" src="../../static/jybimage/close_icon.png" />
                  </div>

          				<div v-if="back_icon == 'false' || back_icon == 'none'" ></div>
          				<div v-else v-bind:id="app_id" class="header_title css_ellipsis">
                      {{ app_key }}<slot v-if=" typeof app_key == 'undefined' || app_key == '' " ></slot>
                  </div>
          				
                  <div v-if="top_button_img" class="top_btn" v-on:click="top_button_img_click" >
          				    <img class="btn_img" v-bind:src="'../../static/jybimage/' + top_button_img" />
          				</div>

        			</div>`
});