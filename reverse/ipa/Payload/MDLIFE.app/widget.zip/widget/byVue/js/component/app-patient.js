/*
 * 就诊人：
 * @param {String} app_id id标识
 * @param {String} app_data 患者数据，json字符串
 * @param {String} show_id 是否显示身份证号
 * @param {String} show_ssc 是否显示社保卡号
 * @method {String} on_select 选择就诊人回调事件
 * @param {String} page_name 所在页面名称
 * @param {String} action_name 要调用的action地址
 * @param {String} show_isbindcard 是否显示“医保/自费”
 * @param {String} show_change_button 是否显示“切换”按钮
 */
Vue.component('app-patient', {
    // props: [ 'app_id', 'app_data', 'show_id', 'show_ssc', 'on_select', 'page_name', 'action_name', 'show_isbindcard' ],
    props: { app_id : String,
             app_data : String,
             show_id : String,
             show_ssc : String,
             on_select : String,
             page_name : String,
             action_name : String,
             show_isbindcard : String,
             show_change_button : String
           },
    template:`<div class="bindPeople" v-bind:app_id="app_id" @click="_fn_( $event )" _app_tag_="app-patient" v-bind:show_isbindcard="show_isbindcard" >
                <input id="buid" class="buid" style="display:none;" />
                <input id="real_buidcard" class="real_buidcard" style="display:none;" />
                <input id="bsex" class="bsex" style="display:none;" />
        				<img class="bindImg" />
        				<div class="bindInfo">
        					<p id="buname" class="buname text_value_color" _app_attribute_="buname" ><span style="color:#E8E8E8;">请选择就诊人</span></p>
        					<p class="buidcard text_key_color" style="display:block;" v-show="show_id != 'false'" >身份证号：<span id="buidcard" _app_attribute_="buidcard" ></span></p>
        					<p class="bussc text_key_color" style="display:block;" v-show="show_ssc  != 'false'" >社保卡号：<span id="bussc"  _app_attribute_="bussc"></span></p>
        				</div>
        				<div class="chooseBtn">
        					<p class="chooseText" v-show="show_change_button  != 'false'">切换</p>
        					<img v-show="show_change_button  != 'false'" src="../../static/jybimage/right_blue.png">
        				</div>
        			</div>`,
    methods : {
        _fn_ : function ( e ) {
               var el = e.currentTarget;
               var page_name = this.page_name;
               var action_name = this.action_name;
               var on_select = this.on_select;
               var _id_ = "_app_patient_" + Math.random();
               el.setAttribute( "_id_", _id_ );
               var select_fun = function( e ){
                  BaseEx._openUserSelect_( page_name, action_name, null, _id_ );
               };
               if ( on_select ) {
                 var fun = eval( on_select.split("(")[0] );
                 if ( typeof fun == "function" ) {
                   select_fun = function( e ){
                      BaseEx._openUserSelect_( page_name, action_name, on_select, _id_ );
                   };
                 }
               }
               select_fun.bind( el );
               select_fun( e );
        }
    },
    mounted : function () {
        var _app_data_;
        if ( JSUtil.isNotEmpty ( this.app_data ) ) {
            _app_data_ = JSON.parse( this.app_data );
            BaseEx.setValueForPatient( this.$el, _app_data_ );
        }
        // console.log( this.$el );
    }
});