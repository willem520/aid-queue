/*
 * 文本框：
 * @param {String} app_id id标识
 * @param {String} show 是否显示：true显示，none隐藏
 * @param {String} app_src 
 */
Vue.component('app-img', {
    props : { app_id : String,
              show : String,
              app_src : String
            },
    template : `<div v-bind:app_id="app_id" class="jyb_img" v-show="show != 'none'" @click="_click_( $event )" ondblclick="alert(3)" _app_tag_="app-img" >
                    <div>
                        <img v-bind:id="app_id" class="jyb_img_inner" v-bind:src="app_src" />
                    </div>
                    <div style="clear:both;"></div>
                </div>`,
    methods : {
        _click_ : function ( e ) {
            
        },
        _dbclick_ : function ( e ) {  alert(2);
            
        }
    }
});