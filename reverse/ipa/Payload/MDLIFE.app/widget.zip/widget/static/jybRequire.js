/**
  * 统一引入api
*/
document.write('<script type="text/javascript" src="../../static/jybapi/cas.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybapi/user.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybapi/intel.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybapi/regNur.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybapi/familySign.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybapi/wgDrug.js" ></script>');

/**
  * 统一引入css
*/
document.write('<link rel="stylesheet" href="../../static/jybcss/common.mobile.css" >');
document.write('<link rel="stylesheet" href="../../static/jybcss/mdui.mine.css" >');
document.write('<link rel="stylesheet" href="../../static/jybcss/threeTreat.css" >');
document.write('<link rel="stylesheet" href="../../static/jybcss/mdui.picker.css" >');
document.write('<link rel="stylesheet" href="../../static/jybcss/mdui.poppicker.css" >');
document.write('<link rel="stylesheet" href="../../static/jybcss/easyui.css" >');
document.write("<link rel='stylesheet' href='../../static/jybcss/jyb.css'>");
document.write("<link rel='stylesheet' href='../../static/jybcss/tag.css'>");
document.write('<link rel="stylesheet" href="../../static/jybcss/base.css" >');

/**
  * 统一引入js
*/
document.write('<script type="text/javascript" src="../../static/jybconfig/config.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/aes_1.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/sha256.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/header.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/mdui.min.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/mdlife.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/md5.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/common.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/toGetEssc.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/window.back.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/window.openH5.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/mdui.picker.js" ></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/mdui.poppicker.js" ></script>');
// document.write( '<script type="text/javascript" src="../../static/jybjs/jquery-1.10.2.min.js"></script>' );
document.write('<script type="text/javascript" src="../../static/jybjs/jsUtil.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/pinyin.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/_cache_.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/es-checker.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/md-extend.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/common-extend.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/common-tag.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/UIMjs.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/tag.js"></script>');
document.write('<script type="text/javascript" src="../../byVue/js/vue.min.js"></script>');
document.write('<script type="text/javascript" src="../../byVue/js/component.js"></script>');
document.write('<script type="text/javascript" src="../../static/jybjs/safeArea.js" ></script>');

