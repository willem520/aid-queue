window.config = {

	"serverPath" : "https://jyt.ylbz.tj.gov.cn/app-prod/", // 金医宝移植金医宝连后台服务地址

	"menuURL" : "wgt://dist/", // 金医宝页面

	"serverURL" : "https://jyt.ylbz.tj.gov.cn:4443/jyt-ui-prod/", // 金医宝移植金医宝连h5地址
	
}