var wgDrug = {
	'ospsCostSplit': 'med/osps/ospsCostSplit', //外购处方预结算
	'pdaQuryEntiy': 'med/osps/pdaQuryEntiy', //pda就诊方式查询
	'pdaQuryInfor': 'med/osps/pdaQuryInfor', //pda个人基本信息查询
	'quryOspsClctList': 'med/osps/quryOspsClctList', //外购处方订单列表
	'quryDetail': 'med/osps/quryDetail', //外购处方详细查询
	'quryMi': 'med/osps/quryMi', //获取药店信息
	'quryOpspNclct': 'med/osps/quryOpspNclct', //外购处方查询
	'quryOrdPayStatus': 'pay/mgt/qury', //支付状态查询
	'querySignWg': 'med/osps/querySign', //签约查询
	'cnfmOrd': 'med/osps/cnfmOrd', //外购处方确认订单
	'opsRevoke': 'med/otp/comm/undoOtpOrd', //门诊订单取消支付
}