window.regNur = {
	'getHospitalInfo': 'med/nurs/getHospitalInfo',  // 获取服务项目
	'applyAppointment': 'med/nurs/applyAppointment',  // 提交申请
	'cancelAppointment': 'med/nurs/cancelAppointment',  // 取消申请
	'evaluate': 'med/nurs/evaluate',  // 评价护士订单
	'queryHospitalList': 'med/nurs/queryHospitalList',  // 获取医院信息
	'queryMaterial': 'med/nurs/queryMaterial',  // 获取协议及须知
	'queryNurseSedual': 'med/nurs/queryNurseSedual',  // 获取医院护士排班
	'imageUpload': 'med/nurs/imageUpload',  // 删除图片
	'imageDelete': 'med/nurs/imageDelete',  // 上传证明图片
	'getImage': 'med/nurs/getImage',  // 获取项目图片
	'getImages': 'med/nurse/getImages',  // 获取证明图片
	'nurseApplyPay': 'med/nurs/nurseApplyPay',  // 支付申请
	'payFinishByZero': 'med/nurs/payFinishByZero',  // 个人零元支付
	'queryAppointment': 'med/nurs/queryAppointment',  // 获取申请列表
	'getAppointmentDetails': 'med/nurs/getAppointmentDetails',  // 获取申请详情
	'queryNurseSedual': 'med/nurs/queryNurseSedual',  // 获取医院护士排班
	'quryNursCount': 'med/nurs/quryNursCount',  // 查询用户订单数据量
	'quryNursStats': 'med/nurs/quryNursStats',  // 查询订单状态
	'quryServList': 'med/nurs/quryServList',  // 获取护士上门服务列表
	'updateNursOpt': 'med/nurs/updateNursOpt',  // 更新护士服务操作
}