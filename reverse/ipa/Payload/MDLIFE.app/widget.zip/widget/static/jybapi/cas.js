window.cas = {

	'applyAppointment': 'med/cas/applyAppointment', // 提交病案预约申请
	'cancelAppointmentbing': 'med/cas/cancelAppointment', // 取消病案申请
	'fileUpload': 'med/cas/fileUpload', // 文件上传
	'getAppointment': 'med/cas/getAppointment', // 获取预约记录详情
	'queryAppointmentbing': 'med/cas/queryAppointment', // 获取预约记录列表
	'queryHospitalize': 'med/cas/queryHospitalize', // 获取申请预约列表
	'queryHospitalizeList': 'med/cas/queryHospitalizeList', // 获取医院列表(支持病案复印)
	'getHospitalizeInfo': 'med/cas/getHospitalizeInfo', // 获取医院详情
	'applyAppointmentbing': 'med/cas/applyAppointment', // 提交病案预约申请
	'getHospitalizeImage': 'med/cas/getHospitalizeImage', // 病案-获取照片
	'iptCasTradeCrtd': 'med/cas/iptCasTradeCrtd', // 提交申请支付
	'queryHospitalizeStatus': 'med/cas/queryHospitalizeStatus', // 查询病案状态
	'reapplyAppointment': 'med/cas/reapplyAppointment', // 重新申请病案预约
	
}