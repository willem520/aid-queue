window.familySign = {

	'appySign': 'hi/familySign/appySign', // 申请家医签约
	'cancSign': 'hi/familySign/cancSign', // 家医取消签约
	'getSignNotice': 'hi/familySign/getSignNotice', // 家医获取协议
	'quryFamilySignInfo': 'hi/familySign/quryFamilySignInfo', // 查询人员签约情况
	'qurySignDist': 'hi/familySign/qurySignDist', // 家医获取区域
	'qurySignHos': 'hi/familySign/qurySignHos', // 家医获取医院
	'renewSign': 'hi/familySign/renewSign', // 家医签约续约 
	'queryServicePack': 'hi/familySign/getServpacInfo', // 获取服务包信息 
	
}