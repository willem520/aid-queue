window.intel = {
	'inQuiryuserQueryOrders': 'med/inquiry/userQueryOrders', // 用户端查询远程问诊订单
	'inQuiryQueryStatus': 'med/inquiry/queryOrdStas', // 查询远程问诊订单状态
	'inQuiryQueryOffice': 'med/inquiry/queryOffice', // 远程问诊科室
	'inQuiryQueryDoctorList': 'med/inquiry/queryDoctorList', // 远程问诊医师
	'getDoctor': 'med/otp/comm/quryOtpHorn',  // 获取医师号源详情
	'quryFavId': 'fav/quryFavId',  // 根据关联信息查询收藏 
	'addMyFavorite': 'fav/savFav',  // 添加收藏
	'cancelMyFavorite': 'fav/cancFav',  // 取消收藏
	'inQuiryQueryNotice': 'med/inquiry/queryNotice',  // 获取互联网医院协议
	'queryBindPeople': 'idetCrtf/quryMdtrterUserDetl',  // 获取用户详细信息
	'isCanInquiry': 'med/inquiry/isCanInquiry',  // 判断是否可进行远程问诊
	'inQuirymakeOrder': 'med/inquiry/makeOrder',  // 远程问诊生成订单
	'inQuiryoperateOrder': 'med/inquiry/operateOrder',  // 操作远程问诊订单
	'quryMdtrtWay': 'hi/qury/quryMdtrtWay',  // 获取就诊方式
	'queryReceptionStatus': 'med/inquiry/queryReceptionordStas',  // 查询医师接诊状态
	'getDrImage': 'med/dr/getDrImage',  // 获取医师头像
}