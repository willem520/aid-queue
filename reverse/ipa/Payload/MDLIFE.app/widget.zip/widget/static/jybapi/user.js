var user = {
	'quryMdtrterUserDetl': 'idetCrtf/quryMdtrterUserDetl', // 获取就诊人列表
	'quryAddr': 'addr/quryAddr', // 查询地址
	'queryHospital': 'med/hosp/quryHosp', // 查询医院列表
	'getHospImage': 'med/hosp/getHospImage',  // 医院图片
}