/*
 * mdlife扩展
 */

(function($) {

	if (typeof MDLifeEx == "undefined") {
	    MDLifeEx = {};
	    window.MDLifeEx = MDLifeEx;
	}

	/**
	  * 时间选项卡
	  */
	MDLifeEx.openTimePicker = function( defaultValue, fun ){
	    if( defaultValue ){
			defaultValue += ' 00:00'
	    }
	    md.openPicker({
	        type: 'date',
	        date:  defaultValue,
	        title: '选择时间'
	    }, function(ret, err){
	        if( ret ){
	      	    var selectedTime;
                var year = ret.year;
                var month = ( "0" + ret.month ).substr( -2 );
                var day = ( "0" + ret.day ).substr( -2 );
                selectedTime = year+"-"+month+"-"+day; 

	            fun( selectedTime );

	      }
	  });
	}

	MDLifeEx.call = function( tel ){
	  var systemType = md.systemType;
	  if(systemType=="android"){
	    md.call({
	        type: 'tel',
	        number: tel
	    });
	  }
	}

	MDLifeEx.openAreaSelect = function( fnCallBack, type, params, name ){
		if ( typeof fnCallBack == "function" ) {
			fnCallBack = fnCallBack.name;
		}
		var type = type || 2;
	    md.openWin( {
	        name: 'areaList',
	        url: 'wgt://threeTreat/common/areaList.html',
	        reload: true,
	        pageParam: {
	            name: name,
	            collectionAction: 'queryAllDiseaseRegister',
	            funcname: fnCallBack,
	            type : type,
	            params : params
	        }
	    } );
	}

	MDLifeEx.openUserSelect = function( pageName, collectionAction, fnCallBack, _id_ ){
		if ( typeof fnCallBack == "function" ) {
			fnCallBack = fnCallBack.name;
		}
	    md.openWin( {
	        name: 'userList',
	        url: 'wgt://JYB/intel/userList.html',
	        reload: true,
	        pageParam: {
	            name : pageName,
	            collectionAction : collectionAction,
	            funcname : fnCallBack,
	            _id_ : _id_
	        }
	    } );
	}

}($));