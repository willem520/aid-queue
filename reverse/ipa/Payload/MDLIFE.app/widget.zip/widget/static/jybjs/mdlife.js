(function() {
	var m = {};
	/**
	 * 复制对象方法
	 */
	m.extend = function(obj, prototypes) {
        for (var key in prototypes) {
            if (prototypes.hasOwnProperty(key)) {
                obj[key] = prototypes[key];
            }
        }
    }
    /**v
     * 判断是否是pc
     */
	m.isPC = function() {
	    var userAgentInfo = navigator.userAgent;
	    var Agents = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"];
	    var flag = true;
	    if(navigator.platform == "Win32") {
	    	flag == true;
	    	return flag;
	    }
	    for (var v = 0; v < Agents.length; v++) {
	        if (userAgentInfo.indexOf(Agents[v]) > 0) {
	            flag = Agents[v];
	            break;
	        }
	    }
	    return flag;
	}
	/**
	 * 初始化方法
	 */
	m.ready = function(func) {
		if(m.isPC() === true) {
			if(typeof $ != "undefined") {
				$(function() {
					func()
				});
			} else {
				func();
			}
		} else {
			window.onViewCreate = function() {
                m.appId = md.appId; //应用id
                m.fixStatusBar(document.getElementById("header"));
            }
            window.onViewOpen = function() {
                func();
            };
		}
	}
	/**
	 * 判断是否是mdlife平台
	 */
	m.isMD = function() {
		if(typeof md == "undefined") {
			return false;
		} 
		return true;
	}
    /**
       * 判断js对象是否存在
       * @method isExist
       * @param  obj 必选 验证的对象
       * @returns {boolean} true/fasle 
       */
     m.isExist=function(obj) {
        return (typeof obj !== 'undefined') && (obj !== null) && (obj !== ''); 
     }; 
	/**
     * json转字符串
     * @method jsonToStr 
     * @param  {object} json 必选 转换的对象
     * @returns {string} 字符串
     */
    m.jsonToStr=function(json) {
        if(typeof json === 'object'){
            return JSON && JSON.stringify(json);
        }
    };
    /**
     * 字符串转json
     * @method strToJson
     * @param  {string} str 必选 转换的字符串
     * @returns {object} json对象
     */
    m.strToJson=function(str){
        if(typeof str === 'string'){
            return JSON && JSON.parse(str);
        }
    };
    /**
     * 是否为数组
     * @method isArray
     * @param  {object} obj 必选 判断的对象
     * @returns {boolean} true/false 是返回true不是返回false 
     */
    m.isArray = function(obj) {
        if(Array.isArray){
            return Array.isArray(obj);
        }else{
            return obj instanceof Array;
        }
    };
    /**
     * 是否为函数
     * @method isFunction
     * @param  {Object} obj 必选 判断的对象
     * @returns {boolean} true/false 是返回true不是返回false 
     */
    m.isFunction = function(obj){
        return Object.prototype.toString.call(obj) === '[object Function]';
    };
    /**
     * 是否为字符串
     * @method isString
     * @param  {Object} obj 必选 判断的对象
     * @returns {boolean} true/false 是返回true不是返回false 
     */
    m.isString = function(obj){
        return Object.prototype.toString.call(obj) === '[object String]';
    };
    /**
     * 过滤字符串，去掉头尾空格
     * @method trim
     * @param  {String} str 必选 字符串
     * @returns {String}  去掉空格的字符串 
     */
	 m.trim=function(str) {
		if (String.prototype.trim) {
			return str == null ? "" : String.prototype.trim.call(str);
		} else {
			return str.replace(/(^\s*)|(\s*$)/g, "");
		}
	 };
	/**
     * 过滤所有字符串，去掉所有的空格
     * @method trimAll
     * @param  {String} str 必选 字符串
     * @returns {String} 去掉空格的字符串 
     */
	 m.trimAll=function(str){
        return str.replace(/\s*/g,'');
     };
	/**
	 * 存入本地存储
	 * 
	 * @method setStorage
	 * @param {String} key 必选 键
	 * @param {Object} value 必选 值
	 */
	 m.setStorage=function(key, value) {
		if (window.localStorage) {
			window.localStorage[key] = value;
//			window.localStorage.setItem(key, value);
		} else {
			alert('localStorage null');
		}
	};
	/**
	 * 获取本地存储
	 * 
	 * @method getStorage
	 * @required {String} key 必选 键
	 * @return {Object} 返回对应的值
	 */
	m.getStorage=function(key) {
		if (window.localStorage) {
			return window.localStorage[key];
//			return window.localStorage.getItem(key);
		} else {
			alert('localStorage error');
		}
	};
    /**
     * 是否是object对象
     * @method isObject
     * @param  {Object} obj 必选 判断的对象
     * @returns {boolean} true/false 是返回true不是返回false 
     */
    m.isObject = function(obj){
        return Object.prototype.toString.call(obj) === '[object Object]';
    };
    /**
     * 根据元素打开窗口
     * @method openFrameByEle
     * @param  {string} id 必选 id
     * @param {json} param 必选 json对象
     * @param {string} param.name 必选 frame名字
     * @param {string} param.url 必选 页面地址，可以为本地文件路径，支持相对路径和绝对路径，以及wgt://、fs://等协议路径，也可以为远程地址
     * @param {json} param.pageParam 可选项 页面参数，在新页面通过md.pageParam获取
     * @param {boolean} param.bounces 可选项 默认值为true, 页面是否弹动 
     * @param {boolean} param.bgColor （可选项）背景色，支持图片和颜色，格式为#ffffff，图片路径支持fs://、wgt://等MDLIFE自定义文件路径协议，如果设置为'transparent'，则不论config.json里是否配置了frameBackground都将会把背景设置为透明。
     * @param {boolean} param.vScrollBarEnabled （可选项）是否显示垂直滚动条 默认值：true，若在config.json里面配置了frame的vScrollBarEnabled，则默认值为配置的值。
     * @param {boolean} param.hScrollBarEnabled（可选项）是否显示水平滚动条 默认值：false，
     * @param {boolean} param.hAuto（可选项）是否自适应高度，输入法不挡住输入框
     * @param {string} param.reload （可选项）页面已经打开时，是否重新加载页面 默认值：false
     */
    m.openFrameByEle = function(id, param) {
    	var obj = document.getElementById(id);
    	var x = obj.offsetLeft || 0;
    	var y = obj.offsetTop || 0;
    	var w = obj.offsetWidth || 320;
    	var h = obj.offsetHeight || 480;
         if(param.bounces == undefined) {
           param.bounces = true; 
        }
        if(param.vScrollBarEnabled == undefined) {
           param.vScrollBarEnabled = true; 
        }
        if(param.hScrollBarEnabled == undefined) {
           param.hScrollBarEnabled = false; 
        }
        var rect = {
            x: x,
            y: y,
            w: w,
            h: h
        };
        if(param.hAuto === true) {
            delete rect.h;
        }
        
    	md.openFrame({
		    name: param.name,
		    url: param.url,
		    rect: rect,
		    pageParam: param.pageParam,
		    bounces: param.bounces,
		    bgColor: param.bgColor || "#ffffff",
		    vScrollBarEnabled: param.vScrollBarEnabled,
		    hScrollBarEnabled: param.hScrollBarEnabled,
		    reload: param.reload
		});
    }

    m.fixStatusBar = function(el) {
        if(!m.isExist(el)) {
            return false;
        }
        var sysType = md.systemType;
        if(sysType == 'ios'){
            el.style.paddingTop = '20px';
        }else if(sysType == 'android'){
            var ver = md.systemVersion;
            ver = parseFloat(ver);
            if(ver >= 4.4){
              //  el.style.paddingTop = '25px';
            }
        }
    };
    

	if(typeof Base == "undefined") {
		window.Base = m;
	} else {
		m.extend(Base, m);
	}
	
	
})();