$(document).on("click",".back",function(){
	
	var thisWin = md.winName;
   	md.closeWin();
    
});