/* input输入框方法 */
$(document).on("click",".inputClick",function(event){
    event.stopPropagation();
    var findid = $(this).attr("findid");
    document.getElementById(findid).focus();
    if($("#"+findid).attr("readonly")!="readonly"){
        $("#"+findid+"_delete").show();
    }
});
$(document).on("click",".input_delete",function(event){
    event.stopPropagation();
    var findid = $(this).attr("findid");
    /*document.getElementById(findid).focus();*/
    $("#"+findid).val('');
    setTimeout(function(){
        document.getElementById(findid).focus();
        if($("#"+findid).attr("readonly")!="readonly"){
            $("#"+findid+"_delete").show();
        }
    },100);
});
function inputOnblur(input) {
    setTimeout(function(){
        $("#"+input.id+"_delete").hide();
    },50);
}
function pushInput( list , callback ){
    var findid = list.findid;
    var titleImg = list.titleImg;
    var placeholder = list.placeholder;
    var boxname = list.boxname;
    var type = list.type;
    if(findid==""||titleImg==""){
        callback ("error");
    }else{
        var inputStr = '<div class=\"ydList inputClick\" findid=\"'+findid+'\">'
                    +'<img src=\"../images/'+titleImg+'\" class=\"ydImg\" />'
                    +'<input class=\"ydDetail\" type=\"'+type+'\" id=\"'+findid+'\" onblur=\"inputOnblur(this)\" placeholder=\"'+placeholder+'\" />'
                    +'<div class=\"input_delete\" findid=\"'+findid+'\" id=\"'+findid+'_delete\">'
                    +'<img src=\"../images/input_delete.png\" />'
                    +'</div>'
                    +'<div class=\"both\"></div>'
                    +'</div>';
        $(boxname).append(inputStr);
        callback ("success");
    }
} 
/* 同意选项 */
$(document).on("click",".agreeBtn",function(event){
    var checkNum = $(".agreeChecked").attr("check");
    if(checkNum=="1"){
        $(".agreeIcon").removeClass("agreeChecked").hide();
        $(".unagreeIcon").addClass("agreeChecked").show();
    }else if(checkNum=="0"){
        $(".agreeIcon").addClass("agreeChecked").show();
        $(".unagreeIcon").removeClass("agreeChecked").hide();
    }
    checkSubmit();
});

/* 获取焦点提示 */
function promptFocus( toast , focus ){
    md.toast({
        msg: toast,
        duration: 2000,
        location: 'middle'
    });
    document.getElementById(focus).focus();
};

/** 
     * 图片压缩，默认同比例压缩 
     * @param {Object} path     
     *         pc端传入的路径可以为相对路径，但是在移动端上必须传入的路径是照相图片储存的绝对路径 
     * @param {Object} obj 
     *         obj 对象 有 width， height， quality(0-1) 
     * @param {Object} callback 
     *         回调函数有一个参数，base64的字符串数据 
     */  
function dealImage(path, callback){  
    var img = new Image();  
    img.src = path;  
    img.onload = function(){  
        //默认按比例压缩  
        var w = this.width,  
            h = this.height; 
        var quality = 0.7; // 默认图片质量为0.7  
          
        //生成canvas  
        var canvas = document.createElement('canvas');  
        var ctx = canvas.getContext('2d');  
          
        // 创建属性节点  
        canvas.setAttribute("width", w);  
        canvas.setAttribute("height", h);
                
        ctx.drawImage(this, 0, 0, w, h);  
        // quality值越小，所绘制出的图像越模糊  
        var base64 = canvas.toDataURL('image/jpeg', quality); 
        // 回调函数返回base64的值  
        callback(base64);  
    };  
};




function jybInput(){
    var jybInput = $("jybInput");
    /*for(var i=0;i<jybInput.length;i++){
        var findid = jybInput[i].attr("id");
        alert(JSON.stringify(findid));
    }*/
    jybInput.each(function(){
        var findid = $(this).attr("findid");
        var titleImg = $(this).attr("titleImg");
        var placeholder = $(this).attr("placeholder");
        var type = $(this).attr("type");
        var readonly = $(this).attr("readonly")||false;
        var maxlength = $(this).attr("maxlength")||"";
        if(findid==""||titleImg==""){

        }else{
            var inputStr = '<div class=\"ydList inputClick\" findid=\"'+findid+'\">'
                        +'<img src=\"../images/'+titleImg+'\" class=\"ydImg\" />';
                        if(readonly==false){
                            inputStr = inputStr +'<input class=\"ydDetail\" type=\"'+type+'\" id=\"'+findid+'\" maxlength=\"'+maxlength+'\" onblur=\"inputOnblur(this)\" placeholder=\"'+placeholder+'\" />';
                        }else if(readonly){
                            inputStr = inputStr +'<input class=\"ydDetail\" type=\"'+type+'\" id=\"'+findid+'\" maxlength=\"'+maxlength+'\" readonly="readonly" onblur=\"inputOnblur(this)\" placeholder=\"'+placeholder+'\" />';
                        }
                        inputStr = inputStr +'<div class=\"input_delete\" findid=\"'+findid+'\" id=\"'+findid+'_delete\">'
                        +'<img src=\"../images/input_delete.png\" />'
                        +'</div>'
                        +'<div class=\"both\"></div>'
                        +'</div>';
            $(this).append(inputStr);
        }
    });
    
    
}

function jybTop(){
    $(document).off("click","#top_btn");
    var jybTop = $("jybTop");
    var title = jybTop.attr("title");
    var back = jybTop.attr("back");
    var topbtn = jybTop.attr("topbtn");
    var fnClick = jybTop.attr("click");
    // if(md.systemType=="ios"){
        var jybTopStr = '<div class=\"header\" style="padding-top:'+ md.getPrefs({key: 'safeArea'}) +'px;">';
    // }else{
        // var jybTopStr = '<div class=\"header\">';
    // }
    if(back=="true"){
        jybTopStr = jybTopStr + '<div class=\"back\">'
                    +'<img class=\"back_img\" src=\"../../static/jybimage/icon_back.png\" />'
                    +'</div>'
                    +'<div class=\"header_title\">'+title+'</div>';
    }else{
        jybTopStr = jybTopStr + '<div class=\"header_title\" style=\"margin-left:20%;\">实名认证</div>';
    }
    if(topbtn!=""){
        jybTopStr = jybTopStr + '<div class=\"top_btn\" id=\"top_btn\">'
                    + '<img class=\"btn_img\" src=\"../../static/jybimage/'+topbtn+'\" />'
                    + '</div>';
    }
    // if(md.systemType=="ios"){
        var btm = 40 + parseInt( md.getPrefs({key: 'safeArea'}) );
        jybTopStr = jybTopStr + '</div>'
                + '<div style="height:'+btm+'px;width:100%;background:#f7f7f7;"></div>';
    // }else{
    //     jybTopStr = jybTopStr + '</div>'
    //             + '<div style="height:0.8rem;width:100%;background:#f7f7f7;"></div>';
    // }
    
    jybTop.append(jybTopStr);
    $(document).on("click","#top_btn",function(){
        eval( fnClick );
    });
}

function faceCheck( buid , hospid , burname , hospname , yka209 , callback ){
    var accesstoken = md.getPrefs({key: 'accesstoken'});
    md.showProgress({
        content: '加载中，请稍候...',
        modal: true
    });
    bMap.getLocation({
        accuracy: '100m',
        autoStop: true,
        filter: 1
    }, function(ret, err){
        md.hideProgress();
        if(ret.status){
            lat=ret.lat;
            lon=ret.lon;
            lat=lat.toString();
            lon=lon.toString();
            bMap.close();
            Base.requestServer("checkNeedFace",{
                "accesstoken":accesstoken,
                "buid":buid,
                "ykc221":lon+","+lat,
                "akb020":hospid,
                "yka209":yka209,
                "akb021":hospname
            },function(dataCheck){
                if(dataCheck.appcode=="1"){
                    var isneed = dataCheck.output.isneed;
                    var iscan = dataCheck.output.iscan;
                    var aac002 = dataCheck.output.aac002;
                    var promptDetail = dataCheck.output.prompt;
                    if( iscan == "0" ){
                        
                        md.alert({
                            msg: promptDetail
                        }); 
                        
                        return;
                    }
                    // AliInitialize( accesstoken , buid , burname , aac002 , isneed , iscan , lon , lat , hospname , yka209 , function( ret ){
                    //     callback({
                    //         isneed:ret.isneed,
                    //         iscan:ret.iscan,
                    //         ykc221:ret.ykc221
                    //     });
                    // });
                    if( isneed == "1" ){
                        AliInitialize( accesstoken , buid , burname , aac002 , isneed , iscan , lon , lat , hospname , hospid , yka209 , function( ret ){
                            callback({
                                isneed:ret.isneed,
                                iscan:ret.iscan,
                                ykc221:ret.ykc221
                            });
                        });
                    }else if( isneed == "0" ){
                        callback({
                            isneed:isneed,
                            iscan:iscan,
                            ykc221:lon+","+lat
                        });
                    }
                  
                }else{
                    md.alert({
                        msg: dataCheck.appmsg
                    });
                }
            },true);
        }else{
            if( md.systemType == 'ios' ){
                md.alert({
                    msg: '请在设置→隐私→定位服务中开启定位服务，以获取您的就诊信息。'
                });
            }else{
                md.alert({
                    msg: '请在系统设置→金医宝→定位权限中开启定位服务，以获取您的就诊信息。'
                });
            }
            
            bMap.close();
            return;
        }
    });
    
}

function AliInitialize( accesstoken , buid , burname , aac002 , isneed , iscan , lon , lat , hospname , hospid , yka209 , callback ){
    Base.requestServer("doctorAliInitialize",{
        "accesstoken":accesstoken,
        "burname":burname,
        "buidcard":aac002
    },function(data){
        if(data.appcode==1){
            var tac004 = data.output.tac004;
            var tac003 = data.output.tac003;
            aliface.certFace({
                'certifyId':tac003,
                'url':tac004
            },function (ret) {
                // alert(JSON.stringify(ret))
                if( ret.resultStatus == "9001" ) {
                    md.removeEventListener({
                        name: 'resume'
                    });
                    md.addEventListener({
                        name: 'resume'
                    }, function(ret, err){

                        Base.requestServer("chkFaceIdtIsSuccess", {
                            'certifyId':tac003
                        }, function( data ) {
                            
                            if( data.appcode == 1 ) {
                                var result = data.output.result;
                                if( result ) {
                                    md.removeEventListener({
                                        name: 'resume'
                                    });
                                    var issuccess = '1';
                                    Base.requestServer("checkNeedFace",{
                                        "accesstoken":accesstoken,
                                        "buid":buid,
                                        "issuccess":issuccess,
                                        "ykc221":lon+","+lat,
                                        "yka209":yka209,
                                        "akb021":hospname,
                                        "akb020":hospid
                                    },function(dataRet){
                                        if( issuccess == '0' ){
                                            return;
                                        }
                                        if(dataRet.appcode==1){
                                            callback({
                                                isneed:isneed,
                                                iscan:iscan,
                                                ykc221:lon+","+lat
                                            });
                                        }else{
                                            md.alert({
                                                msg: dataRet.appmsg
                                            });
                                        }
                                    });
                                }
                            }else {
                                md.alert({
                                    msg: '人脸识别失败，请重试'
                                });
                            }
                        }, true);

                    });
                }
                else if(ret.resultStatus == "9000"){
                    var issuccess = '1';
                    Base.requestServer("checkNeedFace",{
                        "accesstoken":accesstoken,
                        "buid":buid,
                        "issuccess":issuccess,
                        "ykc221":lon+","+lat,
                        "yka209":yka209,
                        "akb021":hospname,
                        "akb020":hospid
                    },function(dataRet){
                        if( issuccess == '0' ){
                            return;
                        }
                        if(dataRet.appcode==1){
                            callback({
                                isneed:isneed,
                                iscan:iscan,
                                ykc221:lon+","+lat
                            });
                        }else{
                            md.alert({
                                msg: dataRet.appmsg
                            });
                        }
                    });
                    
                }else{
                    var issuccess = '0';
                    md.alert({
                        msg: '人脸不匹配，请重试'
                    });
                    Base.requestServer("checkNeedFace",{
                        "accesstoken":accesstoken,
                        "buid":buid,
                        "issuccess":issuccess,
                        "ykc221":lon+","+lat,
                        "yka209":yka209,
                        "akb021":hospname,
                        "akb020":hospid
                    },function(dataRet){
                        if( issuccess == '0' ){
                            return;
                        }
                        if(dataRet.appcode==1){
                            callback({
                                isneed:isneed,
                                iscan:iscan,
                                ykc221:lon+","+lat
                            });
                        }else{
                            md.alert({
                                msg: dataRet.appmsg
                            });
                        }
                    });
                }
                
                // callback("")
                // faceFinish( buid , isssuccess );
            });
        }else{
            md.alert({
                msg: data.appmsg
            });
        }
    },true);
}
