(function($) {

	if ( typeof Base == "undefined" ) {
		Base = {};
		window.Base = Base;
	}
	$.extend(Base, window.config);


	Base.openH5 = function ( param ) {

		var url = param.url;
		var name = param.name || url.substring( url.lastIndexOf('/') + 1, url.length );
		var reload = param.reload || true;
		var slidBackEnabled = param.slidBackEnabled == undefined ? true : param.slidBackEnabled;
		var pageParam = param.pageParam;
		var isIntel = param.isIntel || false;

		param.name = name;
    	param.pageParam = pageParam;

		var h5url = Base.createUrl( url, pageParam );

		if (h5url.indexOf("?") > -1) {
            h5url += "&h5first=1";
        } else {
            h5url += "?h5first=1";
        }

        param.h5url = h5url;

        if( isIntel ) {
            UIMClient.startUrl({
                name: name,
                url: Base.menuURL + 'navigationBar.html',
                reload: true,
                pageParam: param
            },function(ret,err){
                if( ret ){
                    console.log(JSON.stringify(ret))
                }else{
                    console.log(JSON.stringify(ret))
                }
            });
        }else{
			md.openWin({
		        name: name,
		        url: Base.menuURL + 'navigationBar.html',
		        reload: reload,
		        slidBackEnabled: slidBackEnabled,
		        pageParam: param
		    });
        }

	}

	Base.createUrl = function ( url, pageParam ) {
		var paramsList = '';
	    if( JSON.stringify( pageParam ) != '{}' ) {

	    	for( var i in pageParam ) {
	    		if (typeof pageParam[i] == "object") {
	                paramsList += "&" + i + "=" + JSON.stringify( pageParam[i] );
	            } else {
	                paramsList += "&" + i + "=" + pageParam[i];
	            }
	    	}

	    }

	    var h5url;
	    if (url.indexOf("?") > -1) {
	        h5url = Base.serverURL + handleUrl(url) + paramsList;
	    } else {
	        if (paramsList.length > 0) {
	            paramsList = paramsList.replace("&", "?");
	        }
	        h5url = Base.serverURL + handleUrl(url) + paramsList;
	    }

	    return h5url;
	}

	function handleUrl( url ){
	    if (url.indexOf("/") == 0) {
	        return "#" + url;
	    }
	    return "#/" + url;
	}


}($));