/*
 * Base扩展
 * 变量命名规则：仅做参考
 *     _paramName_:protected
 *     __paramName__:private
 */

(function(factory) {

		if (typeof define === 'function' && define.amd) {
			// AMD
			define(['jquery', 'jsutil', 'jcache'], function($, JSUtil, JCache) {
				return factory($, JSUtil, JCache, window, document);
			});
		} else if (typeof exports === 'object') {
			// CommonJS
			module.exports = function(root, $, JSUtil, JCache) {
				if (!root) {
					// CommonJS environments without a window global must pass a
					// root. This will give an error otherwise
					root = window;
				}

				if (!$) {
					$ = typeof window !== 'undefined' ? // jQuery's factory checks for a global window
						require('jquery') :
						require('jquery')(root);
				}

				if (!JSUtil) {
					JSUtil = typeof window !== 'undefined' ? // jQuery's factory checks for a global window
						require('jsutil') :
						require('jsutil')(root);
				}

				if (!JCache) {
					JCache = typeof window !== 'undefined' ? // jQuery's factory checks for a global window
						require('jcache') :
						require('jcache')(root);
				}

				return factory($, JSUtil, JCache, root, root.document);
			};
		} else {
			// Browser
			factory($, JSUtil, JCache, window, document);
		}
	}
	(function($, JSUtil, JCache, window, document) {


		// ( function( $, Base, JSUtil, MDLifeEx ) {

		var $ = window.$,
			Base = window.Base,
			MDLifeEx = window.MDLifeEx;

		if (typeof Base == "undefined") {
			throw "请先加载common.js";
		}

		if (typeof JSUtil == "undefined") {
			throw "请先加载jsUtil.js";
		}

		if (typeof JCache == "undefined") {
			throw "请先加载_cache_.js";
		}

		if (typeof MDLifeEx == "undefined") {
			throw "请先加载md-extend.js";
		}

		var version = "0.0.1",

			// Define a local copy of jQuery
			// jQuery = function( selector, context ) {

			// 	// The jQuery object is actually just the init constructor 'enhanced'
			// 	// Need init if jQuery is called (just allow error to be thrown if not included)
			// 	return new jQuery.fn.init( selector, context );
			// }
			BaseEx = {};

		BaseEx.expando = "BaseEx" + (version + Math.random()).replace(/\D/g, "");


		BaseEx._default_render_type_ = "vue";
		// BaseEx._default_render_type_ = "tag";

		/**
		 * 提交服务
		 * 
		 * @method submit
		 * @param {String}
		 *            url 根据类型取得服务器地址 必选
		 * @param {String}
		 *            params 请求参数对象 必选可为null，
		 * @param {String}
		 *            success 成功回调方法 可选
		 * @param {Boolean}
		 *            mask 是否显示蒙层 可选 默认false
		 * @param {String}
		 *            failed 失败回调方法 可选
		 * @param {String}
		 *            submit_ids 提交表单id 可选
		 */
		BaseEx.submit = function(url, params, success, mask, failed, submit_ids, requestEncrypt, responseEncrypt) {

			if (typeof(params) != "object") {
				console.log("请传入json对象！");
				params = {};
			}

			params.dataSouc = "1";
			// if ( submit_ids && JSUtil.isNotEmpty( submit_ids ) ) {
			// 	var idlist = submit_ids.split( "," );
			// 	for (var i = 0; i < idlist.length; i++) {
			// 		var list = BaseEx.getObj( idlist[i] ).querySelector( ".jyb_validate_input" );
			// 		if ( list && list.size() > 0 ) {
			// 			list[0].focus();
			// 			return ;
			// 		}
			// 	}
			// }
			if (!BaseEx.validate(submit_ids)) return;

			var _params_ = submit_ids ? BaseEx.getParams(submit_ids) : {};
			JSUtil.extend(_params_, params);
			console.log("-----------------url----------"+url)
			Base.requestServer(url, _params_, function(data) {
				if (data.code == 0) {
					var output = data.data,
						key;
					for (key in output) {
						BaseEx.setValue(key, output[key]);
					}
					if (success && typeof(success) == 'function') success(output, data.message);
				}else if(data.code == 320031){
					failed(data);
				} else {
					if (typeof(failed) == 'function') {
						failed(data.message);
					} else if (typeof(failed) == 'undefined' || failed == false) {
						md.alert({
							msg: data.message
						});
					}

				}
			}, mask, requestEncrypt, responseEncrypt);
		}
		/**
		 * 没有数据显示
		 */
		BaseEx.noDataPage = function(selector, text, bottom, top2, vue) {
			var $n = $(selector);
			if (!$n[0]) {
				$n = $(".md-content");
			}
			// if (text == undefined) {
			// 	text = "系统异常没有找到记录";
			// }
			text = ''
			if (bottom == undefined) {
				bottom = "0rem";
			}
			if (top2 == undefined) {
				top2 = "1.5rem";
			}
			var src = "../../static/jybimage/nodata.png";

			var div = '' + '<div class="md-box md-ac md-pc md-ver md-f1" style="position:fixed;top:0;left:0;width:100%;background-image:url(' + src +
				');height:7rem;background-size:100% 100%">'
				/*				+ '<div class="md-box no-page-img md-img"></div>'*/
				+
				'<div class="md-box no-text1" style="width:60%;position:absolute;top:0.4rem;left:1rem;font-size:0.35rem;display:block!important;color:#999;">' +
				text + '</div>' + '</div>';
			$n.html(div);
			/*
			 * $n.tap(function() { Base.refreshWin(); });
			 */
		};


		/**
		 * 验证是否可提交
		 * 
		 * @method validate
		 * @param {String}
		 *            submit_ids 要验证的表单 必选
		 */
		BaseEx.validate = function(submit_ids) {
			if (submit_ids && JSUtil.isNotEmpty(submit_ids)) {
				var idlist = submit_ids.split(","),
					list;
				for (var i = 0; i < idlist.length; i++) {
					list = BaseEx.getObj(idlist[i]).querySelectorAll(".jyb_validate_input");
					if (list && list.length > 0) {
						list[0].focus();
						return false;
					}
				}
			}
			return true;
		}

		/**
		 * 赋值
		 * 
		 * @method setValue
		 * @param {String}
		 *            key 元素id 必选
		 * @param {String}
		 *            value 值 必选
		 */
		BaseEx.setValue = function(key, value) {

			// var element = document.getElementById( key );
			var element = typeof key === "object" ? key : BaseEx.getObj(key) ? BaseEx.getObj(key) : document
				.getElementById(key);

			var _value_ = JSUtil.htmlEncode(BaseEx.filterUndefinedOrNull(value));

			if (element) {
				var _app_tag_ = element.getAttribute("_app_tag_");

				if (_app_tag_) {
					// app-text
					if (_app_tag_ === "app-text") {

						if (element.querySelector("input")) {
							element.querySelector("input").value = _value_;
						} else {
							element.querySelector(".jyb_text_value").innerText = _value_;
						}

						return value;
					}
					// app-input
					if (_app_tag_ === "app-input") {
						var input = element.querySelector("input");
						if (!_value_ && JSUtil.isEmpty(_value_)) {
							var app_key = element.getAttribute("app_key");
							var app_value = input.value;
							input.setAttribute("_is_key_flag_", true);
							input.className = input.className.replace("text_value_color", "text_key_color");
							if (app_value == app_key) {
								return value;
							} else {
								input.value = app_key;
								return value;
							}
						}
						input.value = _value_;
						input.setAttribute("_is_key_flag_", false);
						input.className = input.className.replace("text_key_color", "text_value_color");
						return value;
					}
					// app-select
					if (_app_tag_ === "app-select") {
						BaseEx.setSelectValue(element.getAttribute("app_id"), _value_);
						return value;
					}
					// app-radio
					if (_app_tag_ === "app-radio") {
						BaseEx.setRadioValue(element.getAttribute("app_id"), _value_);
						return value;
					}
					// app-textarea
					if (_app_tag_ === "app-textarea") {
						// element.querySelector( "textarea" ).innerText = _value_;
						element.querySelector("textarea").value = _value_;
						return value;
					}
					// app-textarea-nl
					if (_app_tag_ === "app-textarea-nl") {
						var textarea = element.querySelector("textarea");
						if (!_value_ && JSUtil.isEmpty(_value_)) {
							var app_key = element.getAttribute("app_key");
							var app_value = textarea.value;
							textarea.setAttribute("_is_key_flag_", true);
							textarea.className = textarea.className.replace("text_value_color",
								"text_key_color");
							if (app_value == app_key) {
								BaseEx.vueCommon.appTextareaNl._changeHeight_(textarea);
								return value;
							} else {
								textarea.value = app_key;
								BaseEx.vueCommon.appTextareaNl._changeHeight_(textarea);
								return value;
							}
						}

						textarea.value = _value_;
						textarea.setAttribute("_is_key_flag_", false);
						textarea.className = textarea.className.replace("text_key_color", "text_value_color");

						BaseEx.vueCommon.appTextareaNl._changeHeight_(textarea);

						return value;
					}
					return value;
				}

				// default
				if (element.tagName == "INPUT") {
					element.value = _value_;
				} else {
					element.innerText = _value_;
				}
			}

			return value;
		}

		/**
		 * 取值
		 * 
		 * @method getValue
		 * @param {String}
		 *            key 元素id 必选
		 */
		BaseEx.getValue = function(key) {

			// var result = JSUtil.htmlDecode(function(key){
			// var element = document.getElementById( key );
			var element = typeof key === "object" ? key : BaseEx.getObj(key) ? BaseEx.getObj(key) : document
				.getElementById(key);
			if (element) {
				var _app_tag_ = element.getAttribute("_app_tag_");

				if (_app_tag_) {
					// app-text
					if (_app_tag_ === "app-text") {

						if (element.querySelector("input")) {
							return element.querySelector("input").value;
						} else {
							return element.querySelector(".jyb_text_value").innerText;
						}
					}
					// app-input
					if (_app_tag_ === "app-input") {
						var app_key = element.getAttribute("app_key");
						var app_value = element.querySelector("input").value;
						if (app_key == app_value) {
							return "";
						}
						return app_value;
					}
					// app-select
					if (_app_tag_ === "app-select") {
						return BaseEx.getSelectValue(element.getAttribute("app_id"));
					}
					// app-radio
					if (_app_tag_ === "app-radio") {
						return BaseEx.getRadioValue(element.getAttribute("app_id"));
					}
					// app-textarea
					if (_app_tag_ === "app-textarea") {
						return element.querySelector("textarea").innerText || element.querySelector("textarea")
							.value;
					}
					// app-textarea-nl
					if (_app_tag_ === "app-textarea-nl") {
						var app_key = element.getAttribute("app_key");
						var app_value = element.querySelector("textarea").innerText || element.querySelector(
							"textarea").value;
						if (app_key == app_value) {
							return "";
						}
						return app_value;
					}
					return;
				}

				// default
				if (element.tagName == "INPUT") {
					return element.value;
				} else {
					return element.innerText;
				}
			}
			// }(key));

			// if(result != null){
			// 	return result;
			// }
		}

		BaseEx._body_scroll_ = function(e) {
			e.stopPropagation();
			return false;
		}

		/**
		 * 蒙层的样式名
		 */
		BaseEx.mask_class_name = "app_mask_div_";

		/**
		 * 显示蒙层
		 * 
		 * @method showMask
		 * @param {String} zIndex 样式z-index：层级
		 * @param {String} opacity 样式opacity：透明度
		 * @param {String} clickFun 单击蒙层方法
		 * 
		 */
		BaseEx.showMask = function(zIndex, opacity, clickFun) {
			var zIndex_ = 1000;
			var opacity_ = 0.5;
			if (zIndex && typeof zIndex == "number") {
				zIndex_ = zIndex;
			}
			if (opacity && typeof opacity == "number") {
				opacity_ = opacity;
			}
			var height = document.body.scrollHeight + "px";
			var width = document.body.scrollWidth + "px";
			var mask = document.querySelector("." + BaseEx.mask_class_name);
			if (mask) {
				// mask.style.display = "block";
				// mask.style.zIndex = zIndex_;
				// mask.style.opacity = opacity_;
				// mask.style.height = height;
				// mask.style.width = width;
				mask.parentNode.removeChild(mask);
			}

			mask = document.createElement("div");
			mask.style.cssText = "width: " + width + ";opacity:" + opacity_ +
				";position: absolute;background: black;z-index: " + zIndex_ + ";top: 0;height: " + height + ";"
			mask.setAttribute("class", BaseEx.mask_class_name);
			document.body.appendChild(mask);

			document.body.addEventListener('touchmove', BaseEx._body_scroll_, false);
			document.body.style.position = "fixed";
			document.body.style.width = "100%";
			if (clickFun) {
				JSUtil.addHandle(mask, "click", clickFun);
			}
		}

		/**
		 * 隐层蒙层
		 * 
		 * @method hideMask
		 * 
		 */
		BaseEx.hideMask = function() {
			var mask = document.querySelector("." + BaseEx.mask_class_name);
			if (mask) {
				mask.style.display = "none";
			}
			document.body.removeEventListener('touchmove', BaseEx._body_scroll_, false);
			document.body.style.position = "initial";
			document.body.style.height = "auto";
		}


		/**
		 * 判断是否已登录
		 * 
		 * @method isLogin
		 * @param {function} callback 未登录时的回调函数
		 * 
		 */
		BaseEx.isLogin = function(callback) {
			/*验证登录*/
			var accesstoken = md.getPrefs({
				key: 'accesstoken'
			});
			if (accesstoken) {
				Base.requestServer("isLogin", {
					"accesstoken": accesstoken
				}, function(data) {
					if (data.appcode == "1") {
						var ret = 1;
						callback(ret);
					} else {
						md.openWin({
							name: 'login',
							url: 'wgt://threeTreat/common/login.html',
							reload: true,
							pageParam: {
								name: 'login'
							}
						});
					}
				});
			} else {
				md.openWin({
					name: 'login',
					url: 'wgt://threeTreat/common/login.html',
					reload: true,
					pageParam: {
						name: 'login'
					}
				});
			}
		}

		BaseEx.haveLogin = function(successFun, errorFun) {
			/*验证登录*/
			var accesstoken = md.getPrefs({
				key: 'accesstoken'
			});
			if (accesstoken) {
				Base.requestServer("isLogin", {
					"accesstoken": accesstoken
				}, function(data) {
					if (data.appcode == "1") {
						if (successFun && typeof successFun == "function") {
							successFun();
						}
					} else {
						if (errorFun && typeof errorFun == "function") {
							errorFun();
						}
					}
				});
			} else {
				if (errorFun && typeof errorFun == "function") {
					errorFun();
				}
			}
		}

		/**
		 * 判断是否有未完成订单
		 * 
		 * @method isLogin
		 * @param {String} orderBtn 
		 * 
		 */
		BaseEx.isNeedPay = function(orderBtn) {
			/*是否有未完成订单*/
			var accesstoken = md.getPrefs({
				key: 'accesstoken'
			});
			Base.requestServer("queryIsNeedPay", {
				"accesstoken": accesstoken
			}, function(data) {
				if (data.appcode == "1") {
					if (data.output.isneedpay == 1) {
						if (orderBtn) {
							$("#orderimg").attr("src", "../images/icon_order_needPay2.png");
						} else {
							$("#orderimg").attr("src", "../images/icon_order_needPay.png");
						}
					} else {
						if (orderBtn) {
							$("#orderimg").attr("src", "../images/icon_order-2.png");
						} else {
							$("#orderimg").attr("src", "../images/icon_order.png");
						}
					}
				}
			});
		}

		// BaseEx.alert_class_name_ = "_app_alert_div_";
		BaseEx._alert_button_class_name_ = "_app_alert_button_div_";

		/**
		 * 弹框
		 * @method alert
		 * @param {String} msg 提示信息
		 * @param {function} fun 关闭弹框时的回调函数
		 */
		BaseEx.alert = function(msg, fun) {

			var title = "【提示信息】";
			if (msg.indexOf("【") >= 0 && msg.indexOf("】：") > 0) {
				title = msg.split("】：")[0].split("【")[1];
				msg = msg.split("】：")[1];
			}

			BaseEx.showMask(999998);
			var _id_ = "_alert_" + Math.random();
			var html = [];
			html.push('<div id="' + _id_ +
				'" class="__baseex_alert__" style="width:80%;background:#ffffff;border-radius:5px;position:fixed;left:10%;z-index:999999;">'
			);
			html.push(
				'<div style="width:100%;margin-top:0.1rem;line-height:1rem;text-align:center;font-size:0.3rem;color:#000000;font-family:PingFang-SC-Bold;font-weight:bold;">' +
				title + '</div>');
			html.push(
				'<div style="width:80%;white-space:normal;word-wrap:break-word;max-height:5rem;margin-left:10%;border-radius:5px;min-height:1rem;overflow-y:auto;color:#7f7f7f;text-align:center;">'
			);
			html.push(msg);
			html.push('</div>');
			html.push('<div class="' + BaseEx._alert_button_class_name_ +
				'" style="width:80%;background:#6595df;color:#ffffff;text-align:center;height:0.8rem;line-height:0.8rem;margin-left:10%;margin-top:0.1rem;float:left;border-radius:5px;font-size:0.3rem;margin-bottom: 0.2rem;">确定</div>'
			);
			html.push('</div>');

			var new_el = document.body.appendChild(JSUtil.parseDom(html.join(""))[0]);
			var win_height = document.documentElement.clientHeight;
			new_el.style.top = ((win_height - new_el.offsetHeight) / 2) + "px";
			var obj = new_el.querySelector("." + BaseEx._alert_button_class_name_);

			if (obj) {
				if (fun && typeof fun == "function") {
					JSUtil.addHandle(obj, "click", function() {
						BaseEx.hideMask();
						var Base_alert = document.getElementById(_id_);
						fun();
						Base_alert.parentNode.removeChild(Base_alert);
					});
				} else {
					JSUtil.addHandle(obj, "click", function() {
						BaseEx.hideMask();
						var Base_alert = document.getElementById(_id_);
						Base_alert.parentNode.removeChild(Base_alert);
					});
				}
			}
		}

		/**
		 * 选项卡
		 * @method openPicker
		 * @param {String} title 选项卡标题
		 * @param {String,json} data 选项数据
		 * @param {String} laber 要显示的字段
		 * @param {function} selectFun 选择时调用的的方法
		 * @param {function} cancelFun 取消时调用的的方法
		 * @param {String} order 排序
		 * @param {function} clearFun 清空回调
		 * @param {function} formatter 显示文本的格式化方法
		 */
		BaseEx.openPicker = function(title, data, laber, selectFun, cancelFun, order, clearFun, formatter) {

			var html = [];
			if (typeof data == "string") {
				data = JSON.parse(data);
			}

			if (data) {
				var obj;
				html.push('<div class="base_budiv_">');
				html.push('<div class="base_butitle_">' + title + '</div>');
				html.push('<div class="base_buli_">');

				var key, ht, fun;
				if (order && order == "desc") {
					for (var i = data.length - 1; i >= 0; i--) {
						obj = data[i];
						// var aaf018 = obj.aaf018;
						// var aab300 = obj.aab300;

						html.push('<div class="base_bucard_" ');
						for (key in obj) {
							html.push(key + '="' + JSUtil.htmlEncode(obj[key]) + '"');
						}
						ht = obj[laber];
						if (formatter && JSUtil.isFunction(formatter)) {
							fun = eval(formatter.split("(")[0]);
							ht = fun(ht, obj);
						}
						html.push("params = '" + JSON.stringify(obj) + "'");
						html.push(' >' + ht + '</div>');
					}
				} else {
					var i, key;
					for (i = 0; i < data.length; i++) {
						obj = data[i];
						// var aaf018 = obj.aaf018;
						// var aab300 = obj.aab300;

						html.push('<div class="base_bucard_" ');
						for (key in obj) {
							html.push(key + '="' + JSUtil.htmlEncode(obj[key]) + '"');
						}
						ht = obj[laber];
						if (formatter && JSUtil.isFunction(formatter)) {
							fun = eval(formatter.split("(")[0]);
							ht = fun(ht, obj);
						}
						html.push("params = '" + JSON.stringify(obj) + "'");
						html.push(' >' + ht + '</div>');
					}
				}

				html.push('</div>');
				html.push('<div>');

				if (clearFun && JSUtil.isFunction(clearFun)) {
					html.push('<div class="base_cancel_div_" style="width:50%;" >取消</div>');
					html.push('<div class="base_clear_div_">清空</div>');
				} else {
					html.push('<div class="base_cancel_div_">取消</div>');
				}

				html.push('</div>');
				html.push('</div>');

				BaseEx.showMask();
				var el = JSUtil.parseDom(html.join(""))[0];
				document.body.appendChild(el);

				var list = el.querySelectorAll(".base_bucard_"),
					i, j, params, nodeName, pel;
				for (i = 0; i < list.length; i++) {
					JSUtil.addHandle(list[i], "click", function(e) {
						params = {};
						params[laber] = this.innerText;
						for (j = 0; j < this.attributes.length; j++) {
							nodeName = this.attributes[j].nodeName;
							// 过滤原型属性
							// if( BaseEx.isProtoAttribute( nodeName ) ){
							// 	continue;
							// }
							if (nodeName == 'params') {
								params = JSON.parse(this.attributes[j].nodeValue);
								break;
							}
						}

						selectFun(params);
						pel = this.parentNode.parentNode;
						pel.parentNode.removeChild(pel);
						BaseEx.hideMask();
					});
				}


				var cancel = el.querySelector(".base_cancel_div_");
				if (cancelFun) {
					JSUtil.addHandle(cancel, "click", function(e) {
						var pel = this.parentNode.parentNode;
						cancelFun();
						pel.parentNode.removeChild(pel);
						BaseEx.hideMask();
					});
				} else {
					JSUtil.addHandle(cancel, "click", function(e) {
						var el = this.parentNode.parentNode;
						el.parentNode.removeChild(el);
						BaseEx.hideMask();
					});
				}

				if (clearFun && JSUtil.isFunction(clearFun)) {
					var clear = el.querySelector(".base_clear_div_");
					JSUtil.addHandle(clear, "click", function(e) {
						clearFun(e);
						var el = this.parentNode.parentNode;
						el.parentNode.removeChild(el);
						BaseEx.hideMask();
					});
				}

			}

		}

		/**
		 * 判断是否为标准属性
		 * @method isProtoAttribute
		 * @param {String} attr 属性
		 */
		BaseEx.isProtoAttribute = function(attr) {
			var array = ['class', 'style'];
			if (array.indexOf(attr) >= 0) {
				return true;
			}
			return false;
		}

		/**
		 * 获取自定义元素对象
		 * @method getObj
		 * @param {String} id 
		 */
		BaseEx.getObj = function(id) {
			if (typeof id === "string") {
				return document.querySelector("[app_id='" + id + "']");
			}
			if (typeof id === "object") {
				return id;
			}
			return null;
		}

		/**
		 * 设置app-select选项卡的选项
		 * @method setSelectData
		 * @param {String} id 
		 * @param {String} collectionData 选项数据
		 */
		BaseEx.setSelectData = function(id, collectionData) {
			var obj = BaseEx.getObj(id);
			BaseEx._clearSelectValue_(id);
			if (!collectionData) {
				collectionData = "";
			}
			if (typeof collectionData != "string") {
				obj.setAttribute("app_collection_data", JSON.stringify(collectionData));
			} else {
				obj.setAttribute("app_collection_data", collectionData);
			}
			return obj;
		}

		/**
		 * 获取app-select标签的值，默认取id
		 * @method getSelectValue
		 * @param {String} id 
		 * @param {String} field 要获取值的字段，默认取id字段
		 */
		BaseEx.getSelectValue = function(id, field) {
			var obj = BaseEx.getObj(id);
			if (JSUtil.isEmpty(field)) {
				var app_key_name = obj.getAttribute("app_key_name");
				if (app_key_name) {
					field = app_key_name;
				} else {
					field = "id";
				}
			}
			return obj.getAttribute("_select_value_" + field);
		}

		/**
		 * 设置app-select标签的值，默认以app_laber_name的值为要显示的字段，可以通过field进行指定。
		 * @method setSelectValue
		 * @param {String} id 
		 * @param {String} value 要赋值的数据，必须是app_key_name字段
		 * @param {String} field 要显示的字段，默认app_laber_name字段
		 */
		BaseEx.setSelectValue = function(id, value, field) {
			var obj = BaseEx.getObj(id);
			var _app_tag_ = obj.getAttribute("_app_tag_");
			if (_app_tag_ == "app-select") {

				var app_laber_name = obj.getAttribute("app_laber_name");
				var app_key_name = obj.getAttribute("app_key_name");
				var app_collection_data = obj.getAttribute("app_collection_data");
				if (JSUtil.isEmpty(app_collection_data)) {
					// BaseEx.setValue( id, "" );
					// obj.querySelector( "#" + id ).innerText = "";
					BaseEx._clearSelectValue_(id);
					return;
				}
				app_collection_data = JSON.parse(app_collection_data);

				if (JSUtil.isEmpty(field)) {
					field = app_laber_name;
				}

				if (JSUtil.isEmpty(value)) {
					BaseEx._clearSelectValue_(id);
				} else {
					var i, data, key;
					for (i = 0; i < app_collection_data.length; i++) {
						data = app_collection_data[i];
						if (data[app_key_name] == value) {
							for (key in data) {
								obj.setAttribute("_select_value_" + key, data[key]);
							}
							// BaseEx.setValue( id, data[ field ] );
							obj.querySelector("#" + id).innerText = data[field];
						}
					}
				}

			}
		}


		/**
		 * 用于app-select标签，清除选项值
		 * 
		 * @method _clearSelectValue_
		 * @param {String}
		 *            id 元素id 必选
		 */
		BaseEx._clearSelectValue_ = function(id) {
			var obj = BaseEx.getObj(id);
			var app_collection_data = obj.getAttribute("app_collection_data");
			if (app_collection_data) {
				app_collection_data = JSON.parse(app_collection_data);
				var data = app_collection_data[0],
					key;
				for (key in data) {
					obj.removeAttribute("_select_value_" + key, "");
				}
			}
			obj.querySelector("#" + id).innerText = "";
		}

		/**
		 * 过滤undefined和null
		 * @method filterUndefinedOrNull
		 * @param {String} value 值 必填
		 */
		BaseEx.filterUndefinedOrNull = function(value) {
			if (typeof value == "undefined" || value == null || value == "null") {
				return "";
			}
			return value;
		}

		/**
		 * 显示
		 * @method showObj
		 * @param {String} app_id 元素id 必填
		 */
		BaseEx.showObj = function(app_id) {
			var ids = app_id.split(",");
			var obj, list, j, target, textarea;
			if (ids.length > 0) {
				for (var i = ids.length - 1; i >= 0; i--) {
					obj = BaseEx.getObj(ids[i]);
					if (typeof obj == "undefined") {
						obj = document.getElementById(ids[i]);
					}
					if (obj) {
						obj.style.display = "";

						// 解决隐藏状态下，app-textarea-nl标签被赋值后，高度不会自动变化的问题。
						list = obj.querySelectorAll("div[_app_tag_='app-textarea-nl']");

						for (j = 0; j < list.length; j++) {
							target = list[j];
							textarea = target.querySelector("textarea");
							textarea.focus();
							BaseEx.vueCommon.appTextareaNl._changeHeight_(textarea);
							textarea.blur();
						}

					}
				}
			}
		}

		/**
		 * 隐藏
		 * @method hideObj
		 * @param {String} app_id 元素id 必填
		 */
		BaseEx.hideObj = function(app_id) {
			var ids = app_id.split(",");
			if (ids.length > 0) {
				for (var i = ids.length - 1; i >= 0; i--) {
					var obj = BaseEx.getObj(ids[i]);
					if (typeof obj == "undefined") {
						obj = document.getElementById(ids[i]);
					}
					if (obj) {
						obj.style.display = "none";
					}
				}
			}
		}

		/**
		 * 设置文本框标签的首图标是否显示，以及要显示的图标的路径（可选）
		 * @method setTextTitleIcon
		 * @param {String} app_id 元素id 必填
		 * @param {String} show 是否显示 默认显示
		 * @param {String} title_icon图标的路径 选填
		 */
		BaseEx.setTextTitleIcon = function(app_id, show, title_icon) {
			var obj = BaseEx.getObj(app_id);
			if (obj) {
				// 是否显示首图标
				if (typeof show == "undefined" || show == false || show == "false" || show == "none") { // 不显示
					var _title_icon = obj.querySelector(".jyb_text_title_icon");
					var app_key = obj.querySelector(".jyb_text_key");
					if (_title_icon) {
						_title_icon.style.display = "none";
					}
					if (app_key) {
						app_key.style.marginLeft = "";
					} else {
						throw "该对象可能不是app-text标签！";
					}
				} else { // 显示
					var _title_icon = obj.querySelector(".jyb_text_title_icon");
					var app_key = obj.querySelector(".jyb_text_key");
					if (app_key) {
						app_key.style.marginLeft = "0.4rem";
					} else {
						throw "该对象可能不是app-text标签！";
					}
					if (_title_icon) {
						_title_icon.style.display = "";
					} else {
						if (JSUtil.isEmpty(title_icon)) {
							throw "请传入要显示的图标的路径！";
						}
						var html = [];
						html.push('<img class="jyb_text_title_icon" src="' + title_icon + '"></img>');
						_title_icon = JSUtil.insertBefore(app_key, html.join(''))[0];
					}
				}
			}
		}

		/**
		 * 设置标题
		 * @method setTitle
		 * @param {String} app_id 元素id 必填
		 * @param {String} title 要显示的标题，必填
		 */
		BaseEx.setTitle = function(app_id, title) {
			var obj = BaseEx.getObj(app_id);
			if (obj) {
				var _app_tag_ = obj.getAttribute("_app_tag_");
				if (_app_tag_ == "app-title") {
					var header_title = obj.querySelector(".header_title");
					header_title.innerText = title;
				}
			}
		}

		/**
		 * 打开区域选择页面
		 * @method openAreaSelect
		 * @param {function} fun 回调函数 必填
		 * @param {String} type 调用不同方法 必填
		 * @param {object} params 传参
		 * @param {String} name 方法的所在页面的名称 必填
		 */
		BaseEx.openAreaSelect = function(fun, type, params, name) {
			MDLifeEx.openAreaSelect(fun, type, params, name);
		}

		/**
		 * 就诊人选择页面
		 * @method _openUserSelect_
		 * @param {String} pageName 页面名称 必填
		 * @param {String} action action地址 必填
		 * @param {function} fun 回调函数 必填
		 * @param {String} _id_ 要当做唯一标识的字段 必填
		 */
		BaseEx._openUserSelect_ = function(pageName, action, fun, _id_) {
			MDLifeEx.openUserSelect(pageName, action, fun, _id_);
		}

		/**
		 * 内部方法：
		 * 就诊人选择回调参数处理
		 * @method _userSelectCallBack_
		 * @param {String} _id_ 元素id 必填
		 * @param {String} output json格式数据 必填
		 * @param {String} functionName 回调方法名 必填
		 */
		BaseEx._userSelectCallBack_ = function(_id_, output, functionName) {
			var output = JSON.parse(decodeURIComponent(output));
			BaseEx.setValueForPatient(document.querySelector("div[_id_='" + _id_ + "']"), output);
			var fun = eval(functionName.split("(")[0]);
			if (typeof fun == "function") {
				fun.call(this, output);
			}
		}

		/**
		 * 禁用元素方法
		 * @method setDisabled
		 * @param {String} app_id 元素id 必填
		 * @param {String} gray 是否置灰 必填
		 */
		BaseEx.setDisabled = function(app_ids, gray) {
			var list = app_ids.split(",");
			var i, obj, app_id, _app_tag_, input, _height_, _width_, mark;
			for (i = 0; i < list.length; i++) {
				app_id = list[i];
				obj = BaseEx.getObj(app_id);
				if (obj) {
					_app_tag_ = obj.getAttribute("_app_tag_");
					if (_app_tag_ == "app-text") {
						obj.setAttribute("disabled", "disabled");
						input = obj.getElementsByTagName("input")[0];
						if (input) {
							input.readOnly = true;
						}
						// 隐藏箭头
						obj.querySelector(".jyb_text_arrow").style.display = "none";
					}
					if (_app_tag_) {
						obj.setAttribute("disabled", "disabled");
						if (!obj.parentNode.querySelector("#" + app_id + "_app_disabled_mask_")) {

							// var textarea = obj.getElementsByTagName( "textarea" )[0];
							// if( textarea ){
							// 	textarea.readOnly = true;
							// }

							_height_ = obj.offsetHeight;
							_width_ = obj.offsetWidth;
							mark = document.createElement("div");
							mark.style.height = _height_ + "px";
							mark.style.width = _width_ + "px";
							mark.style.position = "absolute";
							mark.style.top = JSUtil.top(obj) - JSUtil.top(obj.parentNode) + "px";
							mark.style.left = JSUtil.left(obj) - JSUtil.left(obj.parentNode) + "px";
							mark.style.zIndex = "99";
							mark.className = "_app_disabled_mask_";
							mark.id = app_id + "_app_disabled_mask_";
							if (typeof gray == "undefined" || gray == true) {
								mark.style.backgroundColor = "#CCCCCC";
							}

							obj.parentNode.appendChild(mark);

						}

					}
				}
			}
		}

		/**
		 * 可编辑，能调用方法
		 * @method setEnable
		 * @param {String} app_id 元素id 必填
		 */
		BaseEx.setEnable = function(app_ids) {
			var list = app_ids.split(",");
			var app_id, obj, _app_tag_, input, mark;
			for (var i = 0; i < list.length; i++) {
				app_id = list[i];
				obj = BaseEx.getObj(app_id);
				_app_tag_ = obj.getAttribute("_app_tag_");
				if (_app_tag_ == "app-text") {
					// obj.removeAttribute( "disabled" );
					input = obj.getElementsByTagName("input")[0];
					if (input) {
						input.readOnly = false;
					}
				}
				if (_app_tag_) {
					obj.removeAttribute("disabled");
					mark = obj.parentNode.querySelector("#" + app_id + "_app_disabled_mask_");
					JSUtil.remove(mark);
				}
			}
		}

		/**
		 * 设置按钮显示文本
		 * @method setButtonKey
		 * @param {String} app_id 元素id 必填
		 * @param {String} key 按钮名称 必填
		 */
		BaseEx.setButtonKey = function(app_id, key) {
			var obj = BaseEx.getObj(app_id);
			var _app_tag_ = obj.getAttribute("_app_tag_");
			if (_app_tag_ == "app-button") {
				obj.innerText = key;
			}
		}

		/**
		 * 设置提示信息显示文本
		 * @method setPrompts
		 * @param {String} app_id 元素id 必填
		 * @param {String} value 提示信息 必填
		 */
		BaseEx.setPrompts = function(app_id, value) {
			var obj = BaseEx.getObj(app_id);
			var _app_tag_ = obj.getAttribute("_app_tag_");
			if (_app_tag_ == "app-prompts") {
				obj.querySelector(".app_prompts_body_").innerText = value;
			}
		}

		/**
		 * 赋值就诊人
		 * @method setValueForPatient
		 * @param {String} app_id 元素id 必填
		 * @param {String} user json格式的就诊人信息 必填
		 */
		BaseEx.setValueForPatient = function(app_id, user) {
			var obj;
			if (typeof app_id == "object") {
				obj = app_id;
			} else if (typeof app_id == "string") {
				obj = BaseEx.getObj(app_id);
			} else {
				throw "第一个参数请传入app_id或元素！";
			}
			var _app_tag_ = obj.getAttribute("_app_tag_");
			if (_app_tag_ == "app-patient") {
				obj.setAttribute("output", JSON.stringify(user));
				obj.querySelector(".buid").value = BaseEx.filterUndefinedOrNull(user.mdtrterId);
				obj.querySelector(".real_buidcard").value = BaseEx.filterUndefinedOrNull(user.certno);
				obj.querySelector(".bsex").value = BaseEx.filterUndefinedOrNull(user.gend);

				var bsex = BaseEx.filterUndefinedOrNull(user.gend);
				var bage = BaseEx.filterUndefinedOrNull(user.age);
				var buname = BaseEx.filterUndefinedOrNull(user.psnName);
				var isbindcard = user.regLv;
				// if (bage && JSUtil.isNotEmpty(bage)) {
				// 	buname += '<span id="bage" style="padding-left:4%;">' + bage + '</span>岁';
				// }
				var show_isbindcard = obj.getAttribute("show_isbindcard");
				if (isbindcard && show_isbindcard && show_isbindcard == "true") {
					buname += '<span id="isbindcard" style="padding-left:10%;">' + (isbindcard == "0" ? "自费" :
						"医保") + '</span>';
				}

				obj.querySelector(".buname").innerHTML = buname;
				obj.querySelector("span[_app_attribute_='buidcard']").innerText = BaseEx.filterUndefinedOrNull(
					user.certno);
				obj.querySelector("span[_app_attribute_='bussc']").innerText = BaseEx.filterUndefinedOrNull(user
					.insuSscno);

				// 设置头像：
				var _head = BaseEx.__getHeadImage__(bsex, bage);
				obj.querySelector(".bindImg").src = "../../static/jybimage/" + _head + ".png";
			}
		}

		BaseEx.getValueForPatient = function(app_id) {
			var obj;
			if (typeof app_id == "object") {
				obj = app_id;
			} else if (typeof app_id == "string") {
				obj = BaseEx.getObj(app_id);
			} else {
				throw "第一个参数请传入app_id或元素！";
			}
			var _app_tag_ = obj.getAttribute("_app_tag_");
			if (_app_tag_ == "app-patient") {
				var output = obj.getAttribute("output");
				return JSON.parse(output);
			}
			return null;
		}

		/**
		 * 设置列表数据
		 * @method setListData
		 * @param {String} app_id 元素id 必填
		 * @param {String} data json格式的列表数据 必填
		 * @param {String} refresh 是否刷新页面 必填
		 * @param {String} _tag_ 渲染方式：vue或者tag 必填
		 */
		BaseEx.setListData = function(app_id, data, refresh, _tag_) {
			var el, list;
			refresh = refresh === undefined ? true : refresh;
			if (typeof app_id == "object") {
				el = app_id;
			} else if (typeof app_id == "string") {
				el = BaseEx.getObj(app_id);
			} else {
				throw "第一个参数请传入app_id或元素！";
			}
			if (typeof data == "object") {
				list = JSON.stringify(data);
			} else {
				list = data;
			}
			var _app_tag_ = el.getAttribute("_app_tag_");
			if (_app_tag_ == "app-hospital-list") {
				var newEl = document.createElement(_app_tag_);
				JSUtil.extendsAttributes(el, newEl, []);
				newEl.setAttribute("hospital_data", list);
				el.parentNode.replaceChild(newEl, el);
				if (refresh) BaseEx.renderTag(newEl.parentNode, _tag_);
			}
			if (_app_tag_ == "app-hospital-list-s") {
				var newEl = document.createElement(_app_tag_);
				JSUtil.extendsAttributes(el, newEl, []);
				newEl.setAttribute("hospital_data", list);
				el.parentNode.replaceChild(newEl, el);
				if (refresh) BaseEx.renderTag(newEl.parentNode, _tag_);
			}
			if (_app_tag_ == "app-list") {
				// var _show = el.style.display;
				// var newEl = JSUtil.parseDom( decodeURIComponent( el.getAttribute( "_original_html_" ) ) )[0];
				// newEl.setAttribute( "app_list_data", list );
				// // 解决show属性会被修改的问题。
				// if ( _show && _show === "none" ) {
				// 	newEl.setAttribute( "show", "none" );
				// } else {
				// 	newEl.setAttribute( "show", "" );
				// }

				// el.parentNode.replaceChild( newEl, el );

				// if ( refresh ) BaseEx.renderTag( newEl.parentNode, _tag_ );


				JCache.public.set(el, "app_list_data", list);

				if (refresh) {
					var _app_list_body_ = el.querySelector("._app_list_body_");
					JSUtil.removeChild(_app_list_body_);
					if (JSUtil.isNotEmpty(list)) {
						list = JSON.parse(list);
						var i;
						for (i = 0; i < list.length; i++) {
							BaseEx.vueCommon.appList._addListRow_(app_id, list[i], i, false);
						}
					}
				}

			}
			if (_app_tag_ == "app-list-c") {
				var newEl = document.createElement(_app_tag_);
				JSUtil.extendsAttributes(el, newEl, []);
				newEl.setAttribute("list_data", list);
				el.parentNode.replaceChild(newEl, el);
				BaseEx.renderTag(newEl.parentNode, _tag_);
			}
			if (_app_tag_ == "app-list-ca") {

				JCache.public.set(el, "app_list_data", list);

				if (refresh) BaseEx.vueCommon.appList2.initList(app_id);

			}
		}

		BaseEx.vueCommon = {
			appList: {
				_get_width_: function(width) {
					if (width) {
						return width;
					} else {
						return "2rem";
					}
				},
				_getValue_: function(_row_, _col_, str, row_data, _data_config_) {
					if (str) {
						if (_data_config_[_col_]["formatter"]) {
							var fun = eval(_data_config_[_col_]["formatter"]);
							return fun(_row_, _col_, str, row_data);
						} else {
							return str;
						}
					} else {
						return "";
					}
				},
				_getDataConfig_: function(list) {
					var _data_config_ = new Array(),
						el, row_config, attributes, attribute, i, j;
					for (i = 0; i < list.length; i++) {
						el = list[i];
						// console.log( el );
						if (el.nodeName = "app-list-item") {
							row_config = {};
							attributes = el.attributes;
							for (j = 0; j < attributes.length; j++) {
								attribute = attributes[j];
								row_config[attribute.nodeName] = attribute.nodeValue;
							}
							_data_config_.push(row_config);
						}
					}
					return _data_config_;
				},

				// deviation : 1.033, // 页面行高偏差
				deviation: function() {
					return 1
				}, // 页面行高偏差
				row_height: 0.8, // 列表行高

				_addListRow_: function(app_id, row_data, row) {
					var target = BaseEx.getObj(app_id);
					var _data_config_ = JSON.parse(target.getAttribute("data_config")) || BaseEx.vueCommon
						.appList2.cacheConfig(target);
					var _app_list_body_ = target.querySelector("._app_list_body_");
					var _inner_list_ = _app_list_body_.children;
					var item, html = [],
						_width_, _align_, i = row,
						j;
					var show_arrow_icon = target.getAttribute("show_arrow_icon");
					var app_click = target.getAttribute("app_click");

					html.push('<div class="_app_list_row_" _row_="' + i +
						'" _app_click_="_app_click_()"  style="');
					//   if ( ca_flag ) {
					// html.push( 'position:absolute;' );
					//   }
					// html.push( 'top:' + ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + 'px;' );
					html.push('" >');

					for (j = 0; j < _data_config_.length; j++) {
						item = _data_config_[j];
						_width_ = BaseEx.vueCommon.appList._get_width_(item['app_width']);
						_align_ = item['align'];
						html.push(
							'<div class="_app_list_row_cell_ text_key_color" style="font-size:0.25rem;overflow:hidden;width:' +
							_width_ + ';text-align:' + _align_ + ';" >' + BaseEx.vueCommon.appList
							._getValue_(i, j, row_data[item["app_id"]], row_data, _data_config_) +
							'</div>');
					}

					if (!show_arrow_icon || show_arrow_icon != "none") {
						html.push('<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>');
					}
					html.push('<div style="clear:both;"></div>');
					html.push('</div>');

					var el = JSUtil.parseDom(html.join(""))[0];
					//   if ( ca_flag ) {
					// el.style.position = "absolute";
					//   }
					// el.style.top = ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + "px";
					_app_list_body_.appendChild(el);

					var clist = el.children,
						cell, cell_height, cell_top;
					var row_height = el.offsetHeight;
					for (j = 0; j < clist.length; j++) {
						cell = clist[j];
						cell_height = cell.offsetHeight;
						// console.log( row_height + "::" + cell_height );
						cell_top = (row_height - cell_height) / 2;
						cell.style.top = cell_top + "px";
					}

					el.setAttribute("_row_data_", encodeURIComponent(JSON.stringify(row_data)));

					if (app_click) {
						// el.setAttribute( "_app_click_", app_click );
						JSUtil.addHandle(el, "click", function(e) {
							var fun = eval(app_click.split("(")[0]);
							if (typeof fun == "function") {
								var obj = e.currentTarget;
								var _row_data_ = obj.getAttribute("_row_data_");
								var params = JSON.parse(decodeURIComponent(_row_data_));
								fun(params);
							}
						});
					}

				},
				_removeListRow_: function(app_id, row) {
					var target = BaseEx.getObj(app_id);
					var _app_list_content_ = target.querySelector("._app_list_content_");
					var row_elm = _app_list_content_.querySelector("div[_row_='" + row + "']");
					if (row_elm) {
						JSUtil.remove(row_elm);
					}
				},

			},

			appList2: {
				cacheConfig: function(app_id, config) {
					var target = BaseEx.getObj(app_id);
					if (config) {
						JCache.public.set(target, "_data_config_", config);
					} else {
						return JCache.public.get(target, "_data_config_");
					}
				},
				initList: function(app_id) {
					var target = BaseEx.getObj(app_id);
					var list = JCache.public.get(target, "app_list_data");

					var _app_list_body_ = target.querySelector("._app_list_body_");
					var row_height = JSUtil.remToPx(BaseEx.vueCommon.appList.row_height) + BaseEx.vueCommon
						.appList.deviation();
					var win_length = Math.ceil(_app_list_body_.offsetHeight * 2 / row_height);

					// 添加数据行
					var _app_list_content_ = target.querySelector("._app_list_content_");
					JSUtil.removeChild(_app_list_content_);
					var row_data, item, html = [],
						_width_, _align_, i;

					list = list ? eval(list) : [];

					_app_list_content_.style.height = (row_height * list.length) + "px";

					var length = list.length > win_length ? win_length : list.length;
					for (i = 0; i < length; i++) {
						row_data = list[i];

						BaseEx.vueCommon.appList2._addListRow_(app_id, row_data, i, true);

					}

				},
				scrollList: function(app_id) {

					var target = BaseEx.getObj(app_id);

					// 清除重复事件
					// var _timeout_ = JCache.public.get( target, "_timeout_" );
					// if ( _timeout_ ) {
					// 	clearTimeout( _timeout_ );
					// }

					// var st = setTimeout( function ( e ) {

					var _app_list_body_ = target.querySelector("._app_list_body_");
					var _app_list_content_ = target.querySelector("._app_list_content_");
					var inner_list = _app_list_content_.children;

					var list = JCache.public.get(target, "app_list_data");
					list = list ? eval(list) : [];
					var _data_config_ = JCache.public.get(target, "_data_config_");

					var list_height = _app_list_content_.offsetHeight;
					var row_height = JSUtil.remToPx(BaseEx.vueCommon.appList.row_height) + BaseEx.vueCommon
						.appList.deviation();
					var win_length = Math.ceil(_app_list_body_.offsetHeight * 2 / row_height);

					var scroll_top = _app_list_body_.scrollTop;
					var start_row = Math.ceil(scroll_top / row_height);
					start_row = start_row - win_length / 4 >= 0 ? start_row - win_length / 4 : 0;
					start_row = Math.ceil(start_row);

					var end_row = start_row + win_length;
					if (end_row > list.length) {
						end_row = list.length;
						start_row = end_row - win_length;
					}

					var i, row_elm, row_num, row_data;
					// 删除
					for (i = 0; i < inner_list.length; i++) {
						row_elm = inner_list[i];
						row_num = row_elm.getAttribute("_row_");
						if (row_num && (row_num < start_row || row_num > end_row)) {
							JSUtil.remove(row_elm);
						}
					}
					// 添加
					for (i = start_row; i < end_row; i++) {
						row_data = list[i];
						if (_app_list_content_.querySelector("div[_row_='" + i + "']")) {
							continue;
						}
						BaseEx.vueCommon.appList2._addListRow_(target, row_data, i, true);
					}

					// console.log( "scroll" );
					// }, 100 );

					// JCache.public.set( target, "_timeout_", st );

				},

				_addListRow_: function(app_id, row_data, row, ca_flag) {
					var target = BaseEx.getObj(app_id);
					var _data_config_ = JSON.parse(target.getAttribute("data_config")) || BaseEx.vueCommon
						.appList2.cacheConfig(target);
					var _app_list_content_ = target.querySelector("._app_list_content_");
					var _inner_list_ = _app_list_content_.children;
					var item, html = [],
						_width_, _align_, i = row,
						j;
					var show_arrow_icon = target.getAttribute("show_arrow_icon");
					var app_click = target.getAttribute("app_click");

					html.push('<div class="_app_list_row_" _row_="' + i +
						'" _app_click_="_app_click_()"  style="');
					if (ca_flag) {
						// el.style.position = "absolute";
						html.push('position:absolute;');
					}
					html.push('top:' + ((JSUtil.remToPx(BaseEx.vueCommon.appList.row_height) + BaseEx
						.vueCommon.appList.deviation()) * row) + 'px;');
					html.push('" >');

					for (j = 0; j < _data_config_.length; j++) {
						item = _data_config_[j];
						_width_ = BaseEx.vueCommon.appList._get_width_(item['app_width']);
						_align_ = item['align'];
						html.push(
							'<div class="_app_list_row_cell_ text_key_color" style="font-size:0.25rem;overflow:hidden;width:' +
							_width_ + ';text-align:' + _align_ + ';" >' + BaseEx.vueCommon.appList
							._getValue_(i, j, row_data[item["app_id"]], row_data, _data_config_) +
							'</div>');
					}

					if (!show_arrow_icon || show_arrow_icon != "none") {
						html.push('<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>');
					}
					html.push('<div style="clear:both;"></div>');
					html.push('</div>');

					var el = JSUtil.parseDom(html.join(""))[0];
					//   if ( ca_flag ) {
					// el.style.position = "absolute";
					//   }
					// el.style.top = ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + "px";
					_app_list_content_.appendChild(el);

					var clist = el.children,
						cell, cell_height, cell_top;
					var row_height = el.offsetHeight;
					for (j = 0; j < clist.length; j++) {
						cell = clist[j];
						cell_height = cell.offsetHeight;
						// console.log( row_height + "::" + cell_height );
						cell_top = (row_height - cell_height) / 2;
						cell.style.top = cell_top + "px";
					}

					el.setAttribute("_row_data_", encodeURIComponent(JSON.stringify(row_data)));

					if (app_click) {
						// el.setAttribute( "_app_click_", app_click );
						JSUtil.addHandle(el, "click", function(e) {
							var fun = eval(app_click.split("(")[0]);
							if (typeof fun == "function") {
								var obj = e.currentTarget;
								var _row_data_ = obj.getAttribute("_row_data_");
								var params = JSON.parse(decodeURIComponent(_row_data_));
								fun(params);
							}
						});
					}

				},

			},

			appTextareaNl: {
				_changeHeight_: function(elm) {
					var height = elm.getAttribute("_original_height_");
					elm.style.height = height + "px";
					var scroll_height = elm.scrollHeight;
					if (scroll_height > height) {
						elm.style.height = scroll_height + "px";
					}
				}
			},

		};
		// BaseEx.vueCommon.appList = {};
		// BaseEx.vueCommon.appList._get_width_ = function ( width ) {
		//     if ( width ) {
		//         return width;
		//     } else {
		//         return "2rem";
		//     }
		// };
		// BaseEx.vueCommon.appList._getValue_ = function ( _row_, _col_, str, row_data, _data_config_ ) {
		//     if ( str ) {
		//         if ( _data_config_[ _col_ ][ "formatter" ] ) {
		//             var fun = eval( _data_config_[ _col_ ][ "formatter" ] );
		//             return fun( _row_, _col_, str, row_data );
		//         } else {
		//             return str;
		//         }
		//     } else {
		//         return "";
		//     }
		// };
		// BaseEx.vueCommon.appList._getDataConfig_ = function ( list ) {
		// 	var _data_config_ = new Array(),el,row_config,attributes,attribute,i,j;
		//     for ( i = 0; i < list.length; i++ ) {
		//         el = list[i];
		//         // console.log( el );
		//         if ( el.nodeName = "app-list-item" ) {
		//             row_config = {};
		//             attributes = el.attributes;
		//             for ( j = 0; j < attributes.length; j++ ) {
		//                 attribute = attributes[ j ];
		//                 row_config[ attribute.nodeName ] = attribute.nodeValue;
		//             }
		//             _data_config_.push( row_config );
		//         }
		//     }
		//     return _data_config_;
		// };

		// BaseEx.vueCommon.appList.deviation = 1.033; // 页面行高误差
		// BaseEx.vueCommon.appList.row_height = 0.8; // 列表行高

		// BaseEx.vueCommon.appList._addListRow_ = function ( app_id, row_data, row ) {
		//     var target = BaseEx.getObj( app_id );
		// 	var _data_config_ = JSON.parse( target.getAttribute( "data_config" ) ) || BaseEx.vueCommon.appList2.cacheConfig( target );
		//     var _app_list_body_ = target.querySelector( "._app_list_body_" );
		//     var _inner_list_ = _app_list_body_.children;
		//     var item,html=[],_width_,_align_,i = row,j;
		//     var show_arrow_icon = target.getAttribute( "show_arrow_icon" );
		//     var app_click = target.getAttribute( "app_click" );

		// 	html.push( '<div class="_app_list_row_" _row_="' + i + '" _app_click_="_app_click_()"  style="' );
		//   //   if ( ca_flag ) {
		// 		// html.push( 'position:absolute;' );
		//   //   }
		// 	// html.push( 'top:' + ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + 'px;' );
		//     html.push( '" >' );

		//     for (j = 0; j < _data_config_.length; j++) {
		//         item = _data_config_[j];
		//         _width_ = BaseEx.vueCommon.appList._get_width_( item['app_width'] );
		//         _align_ = item['align'];
		//         html.push( '<div class="_app_list_row_cell_ text_key_color" style="font-size:0.25rem;overflow:hidden;width:' + _width_ + ';text-align:' + _align_ + ';" >' + BaseEx.vueCommon.appList._getValue_( i, j, row_data[ item[ "app_id" ] ], row_data, _data_config_ ) + '</div>' );
		//     }

		//     if ( !show_arrow_icon || show_arrow_icon != "none" ) {
		//         html.push( '<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>' );
		//     }
		//         html.push( '<div style="clear:both;"></div>' );
		//     html.push( '</div>' );

		//     var el = JSUtil.parseDom( html.join("") )[0];
		//   //   if ( ca_flag ) {
		// 		// el.style.position = "absolute";
		//   //   }
		//     // el.style.top = ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + "px";
		//     _app_list_body_.appendChild( el );

		//     var clist = el.children, cell, cell_height, cell_top;
		//     var row_height = el.offsetHeight;
		//     for (j = 0; j < clist.length; j++) {
		//         cell = clist[ j ];
		//         cell_height = cell.offsetHeight;
		//         // console.log( row_height + "::" + cell_height );
		//         cell_top = ( row_height - cell_height ) / 2;
		//         cell.style.top = cell_top + "px";
		//     }

		//     el.setAttribute( "_row_data_", encodeURIComponent( JSON.stringify( row_data ) ) );

		//     if ( app_click ) {
		//         // el.setAttribute( "_app_click_", app_click );
		//         JSUtil.addHandle( el, "click", function ( e ) {
		//         	var fun = eval( app_click.split( "(" )[0] );
		//             if ( typeof fun == "function" ) {
		//                 var obj = e.currentTarget;
		//                 var _row_data_ = obj.getAttribute( "_row_data_" );
		//                 var params = JSON.parse( decodeURIComponent( _row_data_ ) );
		//                 fun( params );
		//             }
		//         } );
		//     }

		// }

		// BaseEx.vueCommon.appList._removeListRow_ = function ( app_id, row ) {
		//     var target = BaseEx.getObj( app_id );
		//     var _app_list_content_ = target.querySelector( "._app_list_content_" );
		//     var row_elm = _app_list_content_.querySelector( "div[_row_='" + row + "']" );
		// 	if ( row_elm ) {
		// 		JSUtil.remove( row_elm );
		// 	}
		// }

		// BaseEx.vueCommon.appList2 = {};

		// BaseEx.vueCommon.appList2.cacheConfig = function ( app_id, config ) {
		//     var target = BaseEx.getObj( app_id );
		//     if ( config ) {
		// 		JCache.public.set( target, "_data_config_", config );
		//     } else {
		//     	return JCache.public.get( target, "_data_config_" );
		//     }
		// }

		// BaseEx.vueCommon.appList2.initList = function ( app_id ) {
		//     var target = BaseEx.getObj( app_id );
		//     var list = JCache.public.get( target, "app_list_data" );

		//     var _app_list_body_ = target.querySelector( "._app_list_body_" );
		//     var row_height = JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation;
		//     var win_length = Math.ceil( _app_list_body_.offsetHeight * 2 / row_height );

		//     // 添加数据行
		//     var _app_list_content_ = target.querySelector( "._app_list_content_" );
		//     JSUtil.removeChild( _app_list_content_ );
		//     var row_data, item, html=[], _width_, _align_, i;

		//     list = list ? eval( list ) : [];

		//     _app_list_content_.style.height = ( row_height * list.length ) + "px";

		//     var length = list.length > win_length ? win_length : list.length;
		//     for (i = 0; i < length; i++) {
		//         row_data = list[i];

		//         BaseEx.vueCommon.appList2._addListRow_( app_id, row_data, i, true );

		//     }

		// }

		// BaseEx.vueCommon.appList2.scrollList = function ( app_id ) {

		//     var target = BaseEx.getObj( app_id );

		//     // 清除重复事件
		// 	// var _timeout_ = JCache.public.get( target, "_timeout_" );
		// 	// if ( _timeout_ ) {
		// 	// 	clearTimeout( _timeout_ );
		// 	// }

		// 	// var st = setTimeout( function ( e ) {

		//      var _app_list_body_ = target.querySelector( "._app_list_body_" );
		//      var _app_list_content_ = target.querySelector( "._app_list_content_" );
		//      var inner_list= _app_list_content_.children;

		//      var list = JCache.public.get( target, "app_list_data" );
		//      list = list ? eval( list ) : [];
		//      var _data_config_ = JCache.public.get( target, "_data_config_" );

		//      var list_height = _app_list_content_.offsetHeight;
		//      var row_height = JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation;
		//      var win_length = Math.ceil( _app_list_body_.offsetHeight * 2 / row_height );

		//      var scroll_top = _app_list_body_.scrollTop;
		//      var start_row = Math.ceil( scroll_top / row_height );
		//      start_row = start_row - win_length / 4 >= 0 ? start_row - win_length / 4 : 0;
		//      start_row = Math.ceil( start_row );

		//      var end_row = start_row + win_length;
		//      if ( end_row > list.length ) {
		//      	end_row = list.length;
		//      	start_row = end_row - win_length;
		//  	}

		//      var i,row_elm,row_num,row_data;
		//      // 删除
		//      for ( i = 0; i < inner_list.length; i++) {
		//      	row_elm = inner_list[i];
		//      	row_num = row_elm.getAttribute( "_row_" );
		//      	if ( row_num && ( row_num < start_row || row_num > end_row )  ) {
		//      		JSUtil.remove( row_elm );
		//      	}
		//      }
		//      // 添加
		//      for ( i = start_row; i < end_row; i++ ) {
		//      	row_data = list[i];
		//      	if ( _app_list_content_.querySelector( "div[_row_='" + i + "']" ) ) {
		//      		continue;
		//      	}
		//      	BaseEx.vueCommon.appList2._addListRow_( target, row_data, i, true );
		//      }

		//      // console.log( "scroll" );
		// 	// }, 100 );

		// 	// JCache.public.set( target, "_timeout_", st );

		// }

		// BaseEx.vueCommon.appList2._addListRow_ = function ( app_id, row_data, row, ca_flag ) {
		//     var target = BaseEx.getObj( app_id );
		// 	var _data_config_ = JSON.parse( target.getAttribute( "data_config" ) ) || BaseEx.vueCommon.appList2.cacheConfig( target );
		//     var _app_list_content_ = target.querySelector( "._app_list_content_" );
		//     var _inner_list_ = _app_list_content_.children;
		//     var item,html=[],_width_,_align_,i = row,j;
		//     var show_arrow_icon = target.getAttribute( "show_arrow_icon" );
		//     var app_click = target.getAttribute( "app_click" );

		// 	html.push( '<div class="_app_list_row_" _row_="' + i + '" _app_click_="_app_click_()"  style="' );
		//     if ( ca_flag ) {
		// 		// el.style.position = "absolute";
		// 		html.push( 'position:absolute;' );
		//     }
		// 	html.push( 'top:' + ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + 'px;' );
		//     html.push( '" >' );

		//     for (j = 0; j < _data_config_.length; j++) {
		//         item = _data_config_[j];
		//         _width_ = BaseEx.vueCommon.appList._get_width_( item['app_width'] );
		//         _align_ = item['align'];
		//         html.push( '<div class="_app_list_row_cell_ text_key_color" style="font-size:0.25rem;overflow:hidden;width:' + _width_ + ';text-align:' + _align_ + ';" >' + BaseEx.vueCommon.appList._getValue_( i, j, row_data[ item[ "app_id" ] ], row_data, _data_config_ ) + '</div>' );
		//     }

		//     if ( !show_arrow_icon || show_arrow_icon != "none" ) {
		//         html.push( '<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>' );
		//     }
		//         html.push( '<div style="clear:both;"></div>' );
		//     html.push( '</div>' );

		//     var el = JSUtil.parseDom( html.join("") )[0];
		//   //   if ( ca_flag ) {
		// 		// el.style.position = "absolute";
		//   //   }
		//     // el.style.top = ( JSUtil.remToPx( BaseEx.vueCommon.appList.row_height ) * BaseEx.vueCommon.appList.deviation * row ) + "px";
		//     _app_list_content_.appendChild( el );

		//     var clist = el.children, cell, cell_height, cell_top;
		//     var row_height = el.offsetHeight;
		//     for (j = 0; j < clist.length; j++) {
		//         cell = clist[ j ];
		//         cell_height = cell.offsetHeight;
		//         // console.log( row_height + "::" + cell_height );
		//         cell_top = ( row_height - cell_height ) / 2;
		//         cell.style.top = cell_top + "px";
		//     }

		//     el.setAttribute( "_row_data_", encodeURIComponent( JSON.stringify( row_data ) ) );

		//     if ( app_click ) {
		//         // el.setAttribute( "_app_click_", app_click );
		//         JSUtil.addHandle( el, "click", function ( e ) {
		//         	var fun = eval( app_click.split( "(" )[0] );
		//             if ( typeof fun == "function" ) {
		//                 var obj = e.currentTarget;
		//                 var _row_data_ = obj.getAttribute( "_row_data_" );
		//                 var params = JSON.parse( decodeURIComponent( _row_data_ ) );
		//                 fun( params );
		//             }
		//         } );
		//     }

		// }

		// BaseEx.vueCommon.appTextareaNl = {};
		// BaseEx.vueCommon.appTextareaNl._changeHeight_ = function ( elm ) {
		//        var height = elm.getAttribute( "_original_height_" );
		//        elm.style.height = height + "px";
		//        var scroll_height = elm.scrollHeight;
		//        if ( scroll_height > height ) {
		//            elm.style.height = scroll_height + "px";
		//        }
		//    }


		/**
		 * 获取列表数据
		 * @method getListData
		 * @param {String} app_id 元素id 必填
		 */
		BaseEx.getListData = function(app_id) {
			var el;
			var list;
			if (typeof app_id == "object") {
				el = app_id;
			} else if (typeof app_id == "string") {
				el = BaseEx.getObj(app_id);
			} else {
				throw "第一个参数请传入app_id或元素！";
			}
			var _app_tag_ = el.getAttribute("_app_tag_");
			if (_app_tag_ == "app-hospital-list") {
				list = JSON.parse(el.getAttribute("hospital_data"));
			}
			if (_app_tag_ == "app-hospital-list-s") {
				list = JSON.parse(el.getAttribute("hospital_data"));
			}
			if (_app_tag_ == "app-list") {
				list = JSON.parse(encodeURIComponent(el.getAttribute("app_list_data")));
			}
			if (_app_tag_ == "app-list-c") {
				list = JSON.parse(newEl.getAttribute("list_data"));
			}
			if (_app_tag_ == "app-list-ca") {
				list = JSON.parse(JCache.public.get(el, "app_list_data"));
			}
			return list;
		}

		/**
		 * 设置选项卡的选项
		 * @method setRadioData
		 * @param {String} app_id 元素id 必填
		 * @param {String} collectionData json格式的选项卡数据 必填
		 */
		BaseEx.setRadioData = function(app_id, collectionData) {
			// BaseEx.showMask();
			var el;
			var event_array = [];
			var list;
			if (typeof app_id == "object") {
				el = app_id;
			} else if (typeof app_id == "string") {
				el = BaseEx.getObj(app_id);
			} else {
				throw "第一个参数请传入app_id或元素！";
			}
			if (typeof collectionData == "object") {
				list = JSON.stringify(collectionData);
			} else {
				list = collectionData;
			}
			var _app_tag_ = el.getAttribute("_app_tag_");
			if (_app_tag_ == "app-radio") {
				var newEl = JSUtil.parseDom(decodeURIComponent(el.getAttribute("_original_html_")))[0];
				newEl.setAttribute("app_collection_data", list);
				el.parentNode.replaceChild(newEl, el);
				BaseEx.renderTag(newEl.parentNode);
			}
			// BaseEx.hideMask();
		}

		/**
		 * 设置选项卡的选项
		 * @method setRadioValue
		 * @param {String} app_id 元素id 必填
		 * @param {String} value 值 必填
		 */
		BaseEx.setRadioValue = function(app_id, value) {
			var obj = BaseEx.getObj(app_id);
			if (obj.getAttribute("_app_tag_") == "app-radio") {
				var list = obj.querySelectorAll("._app_radio_option_");
				for (var i = list.length - 1; i >= 0; i--) {
					if (list[i].getAttribute("_app_value_") == value) {
						list[i].querySelector("._app_radio_icon_").className =
							"_app_radio_icon_ _app_radio_checked_";
					} else {
						list[i].querySelector("._app_radio_icon_").className =
							"_app_radio_icon_ _app_radio_uncheck_";
					}
				}
			}
		}

		/**
		 * 设置选项卡的选项
		 * @method setRadioValue
		 * @param {String} app_id 元素id 必填
		 * @param {String} laber 要取值的字段，不设置时使用标签中设置的字段
		 */
		BaseEx.getRadioValue = function(app_id, laber) {
			var obj = BaseEx.getObj(app_id);
			if (obj.getAttribute("_app_tag_") == "app-radio") {
				var ooo = obj.querySelector("._app_radio_checked_");
				if (ooo) {
					var option = ooo.parentNode.parentNode;
					if (option) {
						var _radio_option_ = JSON.parse(option.getAttribute("_radio_option_"));
						if (JSUtil.isEmpty(laber)) {
							return option.getAttribute("_app_value_");
						}
						return _radio_option_[laber];
					}
				}
			}
			if (obj.getAttribute("_app_tag_") == "app-list-c") {
				var ooo = obj.querySelector("._app_radio_checked_");
				if (ooo) {
					var option = ooo.parentNode.parentNode;
					if (option) {
						var _radio_option_ = JSON.parse(option.getAttribute("_row_data_"));
						if (JSUtil.isEmpty(laber)) {
							return option.getAttribute("_app_value_");
						}
						return _radio_option_[laber];
					}
				}
			}
		}

		/**
		 * 渲染标签
		 * 必须放在 onViewOpen 方法里使用
		 * @method renderTag
		 * @param {String} el 元素 必填
		 * @param {String} type 渲染方式：默认为vue
		 */
		BaseEx.renderTag = function(el, type) {
			var layouter;
			var _type_ = null;
			if (typeof el == "string") {
				el = document.getElementById(el);
			}

			// 默认方式
			if (typeof type === "undefined" || JSUtil.isEmpty(type)) {
				_type_ = BaseEx._default_render_type_;
			}

			// alert( Supports.letConst );
			// 判断是否支持es6，强制不使用vue
			if (!Supports.letConst || !Supports.templateString || !Supports.arrow) {
				_type_ = "tag";
			}
			// if ( md && md.systemType === "android" && parseFloat( md.systemVersion ) < 5 ) {
			// 	_type_ = "tag";
			// }

			if (_type_ == "vue") {
				// Vue.config.devtools = "development";
				// Vue.config.performance = true;
				layouter = new Vue({
					el: el,
					// performance : true,
					// devtools : "development"
				});
			} else {
				layouter = RenderTag.renderTag(el);
			}

			return layouter;
		}

		/**
		 * 排版
		 * 必须放在 onViewOpen 方法里或后面使用
		 * @method layout  1、解决苹果和部分安卓手机的留海屏幕兼容问题。
		 *                 2、解决苹果手机的页面滑动不流畅问题
		 */
		BaseEx.layout = function() {

			// 清空alert
			var list = document.querySelectorAll(".__baseex_alert__");
			for (var i = 0; i < list.length; i++) {
				JSUtil.remove(list[i]);
			}

			// 调整页面高度
			var sysType = md.systemType;
			// if(sysType == 'ios'){
			var _top_ = parseInt(md.getPrefs({
				key: 'safeArea'
			}));
			var _app_title_ = document.querySelector(".header");
			if (_app_title_) {
				_app_title_.style.paddingTop = _top_ + "px";
			}
			var _app_body_ = document.querySelector("._app_body_");
			if (_app_body_) {
				var _haveLayout_ = _app_body_.getAttribute("_haveLayout_");
				if (!_haveLayout_) {
					if (_app_title_) {
						_app_body_.style.top = _app_title_.offsetHeight + "px";
					} else {
						_app_body_.style.top = _top_ + "px";
					}
					_app_body_.style.height = (_app_body_.offsetHeight - _top_) + "px";
					_app_body_.setAttribute("_haveLayout_", "true");
				}
			}

			// 滑动不流畅的应对：-webkit-overflow-scrolling:touch
			document.body.style.WebkitOverflowScrolling = "touch";

			// }else if(sysType == 'android'){

			// }

		}

		/**
		 * 通知
		 * @method showInfo
		 * @param {String} title 通知标题 必填
		 * @param {String} notice 通知内容 必填
		 * @param {function} fun 回调函数 选填
		 */
		BaseEx.showInfo = function(title, notice, fun) {
			var html = [];

			BaseEx.showMask(9998);
			var _id_ = ("_base_info_" + Math.random()).replace(/\D/g, "");

			html.push('<div class="_base_budiv_" id="' + _id_ + '" >');
			html.push('<div class="_base_butitle_"><p style="padding-left:5%;">' + title + '</p></div>');
			html.push('<div style="max-height:8rem;overflow:auto;">');
			html.push('<div class="_base_bucard_">');
			html.push(notice);
			html.push('</div>');
			html.push('</div>');
			html.push('<div class="_base_cancel_div_" >确定</div>');
			html.push('</div>');

			var new_el = document.body.appendChild(JSUtil.parseDom(html.join(""))[0]);
			var obj = new_el.querySelector("._base_cancel_div_");
			if (obj) {
				if (fun && typeof fun == "function") {
					JSUtil.addHandle(obj, "click", function() {
						BaseEx.hideMask();
						var Base_alert = document.getElementById(_id_);
						fun();
						Base_alert.parentNode.removeChild(Base_alert);
					});
				} else {
					JSUtil.addHandle(obj, "click", function() {
						BaseEx.hideMask();
						var Base_alert = document.getElementById(_id_);
						Base_alert.parentNode.removeChild(Base_alert);
					});
				}
			}
		}

		/**
		 * 协议书
		 * @method showAgreement
		 * @param {String} title 协议书标题 必填
		 * @param {String} agreement 协议书内容 必填
		 * @param {function} _base_agreement_confirm_ 确认回调 选填
		 * @param {function} _base_agreement_confuse_ 拒绝回调 选填
		 */
		BaseEx.showAgreement = function(title, agreement, _base_agreement_confirm_, _base_agreement_confuse_) {
			var html = [];

			BaseEx.showMask(9998);
			var _id_ = ("_base_agreement_" + Math.random()).replace(/\D/g, "");
			var timeBegin = 5;
			// var _agreement = JSUtil.htmlDecode( agreement );
			var _agreement = agreement;

			html.push('<div class="_base_agreement_" id="' + _id_ + '" >');
			html.push('<div class="_base_agreement_title_">' + title + '</div>');
			html.push('<div class="_base_agreement_text_">');
			html.push(
				'<p id="notice" style="width:95%;float:left;padding-left:2.5%;background:#ffffff;margin-bottom:0.5rem;margin-top:0.2rem;font-size:0.3rem;line-height:0.5rem;text-indent:0.56rem;">'
			);
			html.push(_agreement);
			html.push('</p>');
			html.push('</div>');
			html.push(
				'<div style="margin-top:0.6rem;font-size:0.3rem;background:white;padding-bottom:0.2rem;">');
			html.push(
				'<div style="color:#333;text-align:center;background:white;width:76%;float:left;padding-bottom:0.2rem;padding-left:12%;padding-right:12%;padding-top:0.3rem;">'
			);
			html.push('<div class="_base_agreement_btnyz_" id="_base_agreement_fou_Li_"></div>');
			html.push('<div class="_base_agreement_btnyz_" id="_base_agreement_fou_icon_" ></div>');
			html.push('<div class="_base_agreement_btnyz_" id="_base_agreement_shi_icon_" ></div>');
			html.push('<div>我已阅读并同意签约服务协议</div>');
			html.push('</div>');
			html.push('</div>');
			html.push('<div class="_base_agreement_btn_group_">');
			html.push('<div class="_base_agreement_confuse_">拒绝</div>');
			html.push('<div class="_base_agreement_confirm2_">确定</div>');
			html.push('</div>');
			html.push('</div>');

			var __fn_base_agreement_no__ = function() {
				var obj = event.currentTarget;
				obj.parentNode.querySelector("#_base_agreement_shi_icon_").style.display = "block";
				obj.parentNode.querySelector("#_base_agreement_fou_icon_").style.display = "none";
				obj.parentNode.parentNode.parentNode.querySelector("._base_agreement_confirm2_").className =
					"_base_agreement_confirm_";
			}

			var __fn_base_agreement_yes__ = function() {
				var obj = event.currentTarget;
				obj.parentNode.querySelector("#_base_agreement_shi_icon_").style.display = "none";
				obj.parentNode.querySelector("#_base_agreement_fou_icon_").style.display = "block";
				obj.parentNode.parentNode.parentNode.querySelector("._base_agreement_confirm_").className =
					"_base_agreement_confirm2_";
			}

			var new_el = document.body.appendChild(JSUtil.parseDom(html.join(""))[0]);

			JSUtil.addHandle(new_el.querySelector("#_base_agreement_fou_icon_"), "click",
				__fn_base_agreement_no__);
			JSUtil.addHandle(new_el.querySelector("#_base_agreement_shi_icon_"), "click",
				__fn_base_agreement_yes__);

			var timer = function(_id_) {
				var el = document.getElementById(_id_);
				el.querySelector("._base_agreement_confirm2_").innerHTML = '（' + timeBegin + '）';
				if (!el.querySelector("._base_agreement_confirm2_")) {
					return;
				}
				if (timeBegin > 0) {
					setTimeout(function() {
						timeBegin = timeBegin - 1;
						timer(_id_);
					}, 1000);
				} else if (timeBegin == 0) {
					el.querySelector("._base_agreement_confirm2_").className = "_base_agreement_confirm_";
					el.querySelector("#_base_agreement_fou_Li_").style.display = "none";
					el.querySelector("#_base_agreement_shi_icon_").style.display = "block";
					el.querySelector("._base_agreement_confirm_").innerHTML = "确定";

					var confirm_btn = el.querySelector("._base_agreement_confirm_");
					if (confirm_btn) {
						if (_base_agreement_confirm_ && typeof _base_agreement_confirm_ == "function") {
							JSUtil.addHandle(confirm_btn, "click", function() {
								var _base_agreement_shi_icon_ = el.querySelector(
									"#_base_agreement_shi_icon_");
								if (_base_agreement_shi_icon_.style.display == "block") {
									BaseEx.hideMask();
									var Base_alert = document.getElementById(_id_);
									_base_agreement_confirm_();
									Base_alert.parentNode.removeChild(Base_alert);
								}
							});
						} else {
							JSUtil.addHandle(confirm_btn, "click", function() {
								var _base_agreement_shi_icon_ = el.querySelector(
									"#_base_agreement_shi_icon_");
								if (_base_agreement_shi_icon_.style.display == "block") {
									BaseEx.hideMask();
									var Base_alert = document.getElementById(_id_);
									Base_alert.parentNode.removeChild(Base_alert);
								}
							});
						}
					}
				}
			};

			timer(_id_);

			var confuse_btn = new_el.querySelector("._base_agreement_confuse_");
			if (confuse_btn) {
				if (_base_agreement_confuse_ && typeof _base_agreement_confuse_ == "function") {
					JSUtil.addHandle(confuse_btn, "click", function() {
						BaseEx.hideMask();
						var Base_alert = document.getElementById(_id_);
						_base_agreement_confuse_();
						Base_alert.parentNode.removeChild(Base_alert);
					});
				} else {
					JSUtil.addHandle(confuse_btn, "click", function() {
						BaseEx.hideMask();
						var Base_alert = document.getElementById(_id_);
						Base_alert.parentNode.removeChild(Base_alert);
					});
				}
			}

		}

		/**
		 * 提示：淡入淡出方式
		 * @method toast
		 * @param {String} msg 提示内容 必填
		 * @param {String} duration 显示时长 必填
		 * @param {String} location 显示位置 必填
		 */
		BaseEx.toast = function(msg, duration, location) {
			md.toast({
				msg: msg,
				duration: duration,
				location: location
			});
		}

		/**
		 * 打开页面
		 * @method toast
		 * @param {String} name 页面名称 必填
		 * @param {String} url 页面地址 必填
		 * @param {String} reload 是否重载
		 * @param {String} pageParam 传参
		 * @param {String} slidBackEnabled 下拉刷新
		 * @param {String} bounces 
		 * @param {String} allowEdit 允许编辑
		 */
		BaseEx.openWindow = function(name, url, reload, pageParam, slidBackEnabled, bounces, allowEdit) {

			BaseEx.showMask();

			if (reload && reload == true) {
				reload = true;
			} else {
				reload = false;
			}
			if (slidBackEnabled && slidBackEnabled == false) {
				slidBackEnabled = false;
			} else {
				slidBackEnabled = true;
			}
			if (bounces && bounces == true) {
				bounces = true;
			} else {
				bounces = false;
			}
			md.openWin({
				name: name,
				url: url,
				reload: reload,
				allowEdit: allowEdit,
				bounces: bounces,
				slidBackEnabled: slidBackEnabled,
				pageParam: pageParam
			});

			BaseEx.hideMask();
		}

		BaseEx.closeWindow = function(name) {
			md.closeWin({
				name: name
			});
		}

		BaseEx.closeToWin = function(name) {
			md.closeToWin({
				name: name
			});
		}

		BaseEx.execScript = function(name, script) {
			md.execScript({
				name: name,
				script: script
			});
		}

		/**
		 * 下载
		 * @method download
		 * @param {String} url 下载地址 必填
		 * @param {String} savePath 保存地址
		 * @param {String} report 传参
		 * @param {String} cache 下拉刷新
		 * @param {String} allowResume 
		 * @param {String} success 成功回调
		 * @param {String} failed 失败回调
		 */
		BaseEx.download = function(url, savePath, report, cache, allowResume, success, failed) {
			BaseEx.showMask();
			var html = [];
			html.push('<div class="_base_download_div_" >');
			html.push('<div class="_base_download_outer_" >');
			html.push('<div id="_loadBar_" class="_base_download_inner_" ></div>');
			html.push(
				'<span id="_loadParent_" style="text-align:center;display:block;margin-top:0.1rem;" >0%</span>'
			);
			html.push('</div>');

			html.push(
				'<div id="_base_download_cancel_" style="postion:relative;top:1.2rem;width:90%;left:5%;border-top:1px #9C9C9C solid">'
			);
			html.push('<app-button >取消</app-button>');
			html.push('</div>');

			html.push('</div>');
			var el = document.body.appendChild(JSUtil.parseDom(html.join(''))[0]);
			BaseEx.renderTag(el);

			var error = null;
			el = document.querySelector("._base_download_div_");
			var _base_download_cancel_ = document.querySelector("#_base_download_cancel_");
			JSUtil.addHandle(_base_download_cancel_, "click", function() {
				error = "用户已取消下载";
				md.cancelDownload({
					url: url
				});
				el.parentNode.removeChild(el);
				BaseEx.hideMask();
			});

			// 失败处理
			function fnFailed(error, el, err, failed) {
				error = error == null ? err && err.msg : error;
				error = error == null ? "" : error;
				if (failed && JSUtil.isFunction(failed)) {
					failed(error);
				} else {
					BaseEx.alert("下载失败:" + error);
				}
				el.parentNode.removeChild(el);
				BaseEx.hideMask();
			}

			md.download({
				url: url,
				savePath: savePath,
				report: report,
				cache: cache,
				allowResume: allowResume
			}, function(ret, err) {
				if (ret) {
					if (ret.state == 0) { // 下载中
						if (el.style.display = "none") {
							el.style.display = "block";
						}
						// console.log( "当前下载进度：" + ret.percent + "%" );
						el.querySelector("#_loadBar_").style.width = ret.percent + "%";
						el.querySelector("#_loadParent_").innerText = ret.percent + "%";
					} else if (ret.state == 1) { // 下载成功

						el.querySelector("#_loadBar_").style.width = "100%";
						el.querySelector("#_loadParent_").innerText = "100%";

						if (failed && JSUtil.isFunction(success)) {
							success(ret.fileSize, ret.savePath);
						} else {
							BaseEx.alert("下载成功,文件存放在:" + ret.savePath);
						}
						el.parentNode.removeChild(el);
					} else { // 下载失败
						fnFailed(error, el, err, failed);
					}
				} else { // 下载出现错误
					fnFailed(error, el, err, failed);
				}

			});
		}

		// BaseEx._validate_exp_ = {};
		// BaseEx._validate_exp_.tel = /^(\+\d{2}-)?(0\d{2,3}-)?\d{7,8}(-\d{3,4})?$/;
		// BaseEx._validate_exp_.mobile = /^1[34578]\d{9}$/;
		// BaseEx._validate_exp_.city = {11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江 ",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北 ",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏 ",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外 "};
		// BaseEx._validate_exp_.ID = /^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i;
		// BaseEx._validate_exp_.email = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/;
		// BaseEx._validate_exp_.chinese = /^[\u4e00-\u9fa5]+$/;

		BaseEx._validate_exp_ = {
			tel: /^(\+\d{2}-)?(0\d{2,3}-)?\d{7,8}(-\d{3,4})?$/,
			mobile: /^1[34578]\d{9}$/,
			city: {
				11: "北京",
				12: "天津",
				13: "河北",
				14: "山西",
				15: "内蒙古",
				21: "辽宁",
				22: "吉林",
				23: "黑龙江 ",
				31: "上海",
				32: "江苏",
				33: "浙江",
				34: "安徽",
				35: "福建",
				36: "江西",
				37: "山东",
				41: "河南",
				42: "湖北 ",
				43: "湖南",
				44: "广东",
				45: "广西",
				46: "海南",
				50: "重庆",
				51: "四川",
				52: "贵州",
				53: "云南",
				54: "西藏 ",
				61: "陕西",
				62: "甘肃",
				63: "青海",
				64: "宁夏",
				65: "新疆",
				71: "台湾",
				81: "香港",
				82: "澳门",
				91: "国外 "
			},
			ID: /^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i,
			email: /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/,
			chinese: /^[\u4e00-\u9fa5]+$/
		};

		BaseEx._validate_ = {
			"tel": function(arg) {
				var pass = true;
				var tip = "请输入正确的电话号码！";
				if (arg) {
					if (BaseEx._validate_exp_.tel.test(arg)) {
						pass = true;
					} else if (BaseEx._validate_exp_.mobile.test(arg)) {
						pass = true;
					} else {
						pass = false;
					}
				}
				return [pass, tip];
			},
			"mobile": function(arg) {
				var pass = true;
				var tip = "请输入正确的手机号！";
				if (arg) {
					var exp = BaseEx._validate_exp_.mobile;
					if (exp.test(arg)) {
						pass = true;
					} else {
						pass = false;
					}
				}
				// console.log( arg + "::" + pass + "::" + tip );
				return [pass, tip];
			},
			"ID": function(arg) {
				var code = arg;
				var tip = "身份证号码错误";
				var pass = true;
				if (code) {
					var city = BaseEx._validate_exp_.city;

					if (!code || !BaseEx._validate_exp_.ID.test(code)) {
						tip = "身份证号格式错误";
						pass = false;
					} else if (!city[code.substr(0, 2)]) {
						tip = "地址编码错误";
						pass = false;
					} else {
						//18位身份证需要验证最后一位校验位
						if (code.length == 18) {
							code = code.split('');
							//∑(ai×Wi)(mod 11)
							//加权因子
							var factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
							//校验位
							var parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
							var sum = 0;
							var ai = 0;
							var wi = 0;
							for (var i = 0; i < 17; i++) {
								ai = code[i];
								wi = factor[i];
								sum += ai * wi;
							}
							var last = parity[sum % 11];
							if (parity[sum % 11] != code[17]) {
								tip = "校验位错误";
								pass = false;
							}
						}
					}
				}
				return [pass, tip];
			},
			"email": function(arg) {
				var pass = true;
				var tip = "请输入正确的邮箱地址！";
				var exp = BaseEx._validate_exp_.email;
				if (arg) {

					if (exp.test(arg)) {
						pass = true;
					} else {
						pass = false;
					}
				}
				return [pass, tip];
			},
			"chinese": function(arg) {
				var pass = true;
				var tip = "请输入中文！";
				var exp = BaseEx._validate_exp_.chinese;

				if (arg) {
					if (exp.test(arg)) {
						pass = true;
					} else {
						pass = false;
					}
				}

				return [pass, tip];
			}
		}

		// BaseEx._type_exp_ = {};
		// BaseEx._type_exp_.tel = /[^\d-]/g;
		// BaseEx._type_exp_.mobile = /[^\d]/g;
		// BaseEx._type_exp_.ID = /[^\dX]/g;
		// BaseEx._type_exp_.email = /[^a-zA-Z0-9_@.]/g;
		// BaseEx._type_exp_.chinese = /[^\u4e00-\u9fa5]/g;
		BaseEx._type_exp_ = {
			tel: /[^\d-]/g,
			mobile: /[^\d]/g,
			ID: /[^\dX]/g,
			email: /[^a-zA-Z0-9_@.]/g,
			chinese: /[^\u4e00-\u9fa5]/g
		};

		BaseEx._type_ = {
			"tel": function(arg) {
				return arg = arg.replace(BaseEx._type_exp_.tel, "");
			},
			"mobile": function(arg) {
				return arg = arg.replace(BaseEx._type_exp_.mobile, "");
			},
			"ID": function(arg) {
				return arg = arg.replace(BaseEx._type_exp_.ID, "");
			},
			"email": function(arg) {
				return arg = arg.replace(BaseEx._type_exp_.email, "");
			},
			"chinese": function(arg) {
				return arg = arg.replace(BaseEx._type_exp_.chinese, "");
			}
		}

		/**
		 * 输入验证
		 * @method validateInput
		 * @param {String} value 值 必填
		 * @param {String} type 文本类型 必填
		 */
		BaseEx.validateInput = function(value, type) {
			var re = [true];
			if (value && type) {
				if (BaseEx._validate_[type]) {
					re = BaseEx._validate_[type](value);
				}
			}
			return re[0];
		}

		/**
		 * 获取变量，返回object
		 * @method getParams
		 * @param {String} app_ids 元素app_id
		 */
		BaseEx.getParams = function(app_ids) {
			var params = {};
			var obj, list, app_id, el, app_id, app_value;
			var idlist = app_ids.split(","),
				i, j;
			for (i = 0; i < idlist.length; i++) {
				app_id = idlist[i];
				obj = BaseEx.getObj(app_id);
				list = obj.querySelectorAll("[_app_tag_]");
				for (j = 0; j < list.length; j++) {
					el = list[j];
					app_id = el.getAttribute("app_id");
					app_value = BaseEx.getValue(app_id);
					// console.log( el );
					// console.log( app_id + "::" + app_value );
					if (app_id) {
						params[app_id] = app_value;
					}
				}
			}
			return params;
		}

		/**
		 * 清空表单
		 * @method clearForm
		 * @param {String} args 元素app_id
		 */
		BaseEx.clearForm = function(args) {
			var ids = args.split(",");
			var obj, list, i, j;
			for (i = 0; i < ids.length; i++) {
				obj = BaseEx.getObj(ids[i]);
				list = obj.querySelectorAll("[_app_tag_]");

				for (j = 0; j < list.length; j++) {
					el = list[j];
					BaseEx.setValue(el, "");
					// console.log( el );
					// console.log( app_id + "::" + app_value );
				}

				// list = obj.querySelectorAll( "input" );

				// for (var j = 0; j < list.length; j++) {
				// 	el = list[j];
				// 	BaseEx.setValue( el, "" );
				// }

				// list = obj.querySelectorAll( "textarea" );

				// for (var j = 0; j < list.length; j++) {
				// 	el = list[j];
				// 	BaseEx.setValue( el, "" );
				// }

			}
		}

		// ↓金医宝私有方法
		BaseEx.__getHeadImage__ = function(usex, uage) {
			var headImg = "adult_man";
			if (usex == "1") {
				if (uage < 18) {
					headImg = "child_man"
				} else if (uage < 60 && uage >= 18) {
					headImg = "adult_man"
				} else if (uage >= 60) {
					headImg = "older_man"
				}
			} else if (usex == "2") {
				if (uage < 18) {
					headImg = "child_woman"
				} else if (uage < 60 && uage >= 18) {
					headImg = "adult_woman"
				} else if (uage >= 60) {
					headImg = "older_woman"
				}
			}
			return headImg;
		}
		// ↑金医宝私有方法

		BaseEx._app_validate_ = function(input_el, app_type, validate) {
			var flag_type = true,
				flag = true,
				tip = null,
				app_id = input_el.id;
			// console.log( this );

			if (app_type && app_type != "text") {
				var re = BaseEx._validate_[app_type](input_el.value);
				flag_type = re[0];
				tip = re[1];
			}

			if (validate && JSUtil.isFunction(validate)) {
				var fun = eval(validate.split("(")[0]);
				var ret = fun(input_el.value);
				flag = ret[0];
				tip = ret[1];
			}

			// 验证结果：
			if (!flag_type || !flag) { // 未通过
				if (input_el.className.indexOf("jyb_validate_input") < 0) {
					input_el.className += " jyb_validate_input";

					if (!document.querySelector("#" + app_id + "_validate_")) {
						var tip_div = document.createElement("div");
						var bind_target = document.querySelector("div[_app_tag_='app-body']") || document.body;
						tip_div.id = app_id + "_validate_";
						tip_div.className = "_validate_tip_";
						tip_div.innerHTML = tip;
						tip_div.style.top = (JSUtil.top(input_el) - JSUtil.remToPx(0.4) - JSUtil.top(
							bind_target)) + "px";
						tip_div.style.right = (bind_target.offsetWidth - JSUtil.left(input_el) - input_el
							.offsetWidth - JSUtil.left(bind_target)) + "px";

						bind_target.appendChild(tip_div);
					}

				}
			} else { // 通过
				if (input_el.className.indexOf("jyb_validate_input") >= 0) {
					input_el.className = input_el.className.replace(" jyb_validate_input", "");
					var tip_div = document.querySelector("#" + app_id + "_validate_");
					if (tip_div) {
						JSUtil.remove(tip_div);
					}
				}
			}
		}

		// var rnothtmlwhite = ( /[^\x20\t\r\n\f]+/g ); // 空白开头

		// function Data() {
		// 	this.expando = BaseEx.expando + Data.uid++;
		// }

		// Data.uid = 1;

		// Data.prototype = {

		// 	cache: function( owner ) {

		// 		// Check if the owner object already has a cache
		// 		var value = owner[ this.expando ];

		// 		// If not, create one
		// 		if ( !value ) {
		// 			value = {};

		// 			// We can accept data for non-element nodes in modern browsers,
		// 			// but we should not, see #8335.
		// 			// Always return an empty object.
		// 			if ( acceptData( owner ) ) {

		// 				// If it is a node unlikely to be stringify-ed or looped over
		// 				// use plain assignment
		// 				if ( owner.nodeType ) {
		// 					owner[ this.expando ] = value;

		// 				// Otherwise secure it in a non-enumerable property
		// 				// configurable must be true to allow the property to be
		// 				// deleted when data is removed
		// 				} else {
		// 					Object.defineProperty( owner, this.expando, {
		// 						value: value,
		// 						configurable: true
		// 					} );
		// 				}
		// 			}
		// 		}

		// 		return value;
		// 	},
		// 	set: function( owner, data, value ) {
		// 		var prop,
		// 			cache = this.cache( owner );

		// 		// Handle: [ owner, key, value ] args
		// 		// Always use camelCase key (gh-2257)
		// 		if ( typeof data === "string" ) {
		// 			cache[ camelCase( data ) ] = value;

		// 		// Handle: [ owner, { properties } ] args
		// 		} else {

		// 			// Copy the properties one-by-one to the cache object
		// 			for ( prop in data ) {
		// 				cache[ camelCase( prop ) ] = data[ prop ];
		// 			}
		// 		}
		// 		return cache;
		// 	},
		// 	get: function( owner, key ) {
		// 		return key === undefined ?
		// 			this.cache( owner ) :

		// 			// Always use camelCase key (gh-2257)
		// 			owner[ this.expando ] && owner[ this.expando ][ camelCase( key ) ];
		// 	},
		// 	remove: function( owner, key ) {
		// 		var i,
		// 			cache = owner[ this.expando ];

		// 		if ( cache === undefined ) {
		// 			return;
		// 		}

		// 		if ( key !== undefined ) {

		// 			// Support array or space separated string of keys
		// 			if ( Array.isArray( key ) ) {

		// 				// If key is an array of keys...
		// 				// We always set camelCase keys, so remove that.
		// 				key = key.map( camelCase );
		// 			} else {
		// 				key = camelCase( key );

		// 				// If a key with the spaces exists, use it.
		// 				// Otherwise, create an array by matching non-whitespace
		// 				key = key in cache ?
		// 					[ key ] :
		// 					( key.match( rnothtmlwhite ) || [] );
		// 			}

		// 			i = key.length;

		// 			while ( i-- ) {
		// 				delete cache[ key[ i ] ];
		// 			}
		// 		}

		// 		// Remove the expando if there's no more data
		// 		if ( key === undefined || JSUtil.isEmptyObject( cache ) ) {

		// 			// Support: Chrome <=35 - 45
		// 			// Webkit & Blink performance suffers when deleting properties
		// 			// from DOM nodes, so set to undefined instead
		// 			// https://bugs.chromium.org/p/chromium/issues/detail?id=378607 (bug restricted)
		// 			if ( owner.nodeType ) {
		// 				owner[ this.expando ] = undefined;
		// 			} else {
		// 				delete owner[ this.expando ];
		// 			}
		// 		}
		// 	},
		// 	hasData: function( owner ) {
		// 		var cache = owner[ this.expando ];
		// 		return cache !== undefined && !JSUtil.isEmptyObject( cache );
		// 	}
		// };

		// var dataUser = new Data();

		// // Matches dashed string for camelizing
		// var rmsPrefix = /^-ms-/,
		// 	rdashAlpha = /-([a-z])/g;

		// // Used by camelCase as callback to replace()
		// function fcamelCase( all, letter ) {
		// 	return letter.toUpperCase();
		// }

		// // Convert dashed to camelCase; used by the css and data modules
		// // Support: IE <=9 - 11, Edge 12 - 15
		// // Microsoft forgot to hump their vendor prefix (#9572)
		// function camelCase( string ) {
		// 	return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
		// }

		// var acceptData = function( owner ) {

		// 	// Accepts only:
		// 	//  - Node
		// 	//    - Node.ELEMENT_NODE
		// 	//    - Node.DOCUMENT_NODE
		// 	//  - Object
		// 	//    - Any
		// 	//  - NON-ELEMENT_NODE
		// 	//    - _app_tag_
		// 	return owner.nodeType === 1 || owner.nodeType === 9 || !( +owner.nodeType ) || owner.getAttribute( "_app_tag_" );
		// };


		BaseEx.Certificate = function(certificateNo) {
			/*var pat = /^\d{6}(((19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])\d{3}([0-9]|x|X))|(\d{2}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])\d{3}))$/;  
      	if(!pat.test(certificateNo))  
            return null;  */
			var idCardCheck = IdentityCodeValid(certificateNo);
			//console.log(idCardCheck)
			if (idCardCheck == false)
				return null;
			var parseInner = function(certificateNo, idxSexStart, birthYearSpan) {
				var res = {};
				var idxSex = 1 - certificateNo.substr(idxSexStart, 1) % 2;
				res.sex = idxSex == '1' ? '女' : '男';

				var year = (birthYearSpan == 2 ? '19' : '') + certificateNo.substr(6, birthYearSpan);
				var month = certificateNo.substr(6 + birthYearSpan, 2);
				var day = certificateNo.substr(8 + birthYearSpan, 2);
				res.birthday = year + '-' + month + '-' + day;

				var d = new Date(); //当然，在正式项目中，这里应该获取服务器的当前时间  
				var monthFloor = ((d.getMonth() + 1) < parseInt(month, 10) || (d.getMonth() + 1) ==
					parseInt(month, 10) && d.getDate() < parseInt(day, 10)) ? 1 : 0;
				res.age = d.getFullYear() - parseInt(year, 10) - monthFloor;
				return res;
			};
			return parseInner(certificateNo, certificateNo.length == 15 ? 14 : 16, certificateNo.length == 15 ?
				2 : 4);
		};

		/*function idCardNo(value){
	  	//验证身份证号方法
	  	var area = { 11: "北京", 12: "天津", 13: "河北", 14: "山西", 15: "内蒙古", 21: "辽宁", 22: "吉林", 23: "黑龙江", 31: "上海", 32: "江苏", 33: "浙江", 34: "安徽", 35: "福建", 36: "江西", 37: "山东", 41: "河南", 42: "湖北", 43: "湖南", 44: "广东", 45: "广西", 46: "海南", 50: "重庆", 51: "四川", 52: "贵州", 53: "云南", 54: "西藏", 61: "陕西", 62: "甘肃", 63: "青海", 64: "宁夏", 65: "xinjiang", 71: "台湾", 81: "香港", 82: "澳门", 91: "国外" }
	  	var idcard, Y, JYM;
	  	var idcard=value;
	  	var S, M;
	  	var idcard_array = new Array();
	  	idcard_array = idcard.split("");
	  	if (area[parseInt(idcard.substr(0, 2))] == null) return false;
	  	switch (idcard.length) {
	      	case 15:
	          	if ((parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0 || ((parseInt(idcard.substr(6, 2)) + 1900) % 100 == 0 && (parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0)) {
	              	ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/; //测试出生日期的合法性
	          	}
	          	else {
	              	ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/; //测试出生日期的合法性
	          	}
	          	if (ereg.test(idcard))
	              	//return Errors[0];
	            	var res = true;
	          	else
	              	//return Errors[2];
	            	var res = false;
	          	return res;
	          	break;
	      	case 18:
	          	if (parseInt(idcard.substr(6, 4)) % 4 == 0 || (parseInt(idcard.substr(6, 4)) % 100 == 0 && parseInt(idcard.substr(6, 4)) % 4 == 0)) {
	              	ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/; //闰年出生日期的合法性正则表达式
	          	}
	          	else {
	              	ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/; //平年出生日期的合法性正则表达式
	          	}
	          	if (ereg.test(idcard)) {
	              	S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7 + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9 + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10 + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5 + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8 + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4 + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2 + parseInt(idcard_array[7]) * 1 + parseInt(idcard_array[8]) * 6 + parseInt(idcard_array[9]) * 3;
	              	Y = S % 11;
	              	M = "F";
	              	JYM = "10X98765432";
	              	M = JYM.substr(Y, 1);
	              	if (M == idcard_array[17])
	                  	//return Errors[0];
	                	var res = true;
	              	else
	                  	//return Errors[3];
	                	var res = false;
	          	}
	          	else
	              	//return Errors[2];
	            	res = false;
	          	return res;
	          	break;
	      	default:
	          	res = false;
	          	return res;
	          	break;
	    };
	}*/

		function IdentityCodeValid(code) {
			var city = {
				11: "北京",
				12: "天津",
				13: "河北",
				14: "山西",
				15: "内蒙古",
				21: "辽宁",
				22: "吉林",
				23: "黑龙江 ",
				31: "上海",
				32: "江苏",
				33: "浙江",
				34: "安徽",
				35: "福建",
				36: "江西",
				37: "山东",
				41: "河南",
				42: "湖北 ",
				43: "湖南",
				44: "广东",
				45: "广西",
				46: "海南",
				50: "重庆",
				51: "四川",
				52: "贵州",
				53: "云南",
				54: "西藏 ",
				61: "陕西",
				62: "甘肃",
				63: "青海",
				64: "宁夏",
				65: "新疆",
				71: "台湾",
				83: "台湾",
				81: "香港",
				82: "澳门",
				91: "国外 "
			};
			var tip = "";
			var pass = true;

			if (!code || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(code)) {
				tip = "身份证号格式错误";
				pass = false;
			} else if (!city[code.substr(0, 2)]) {
				tip = "地址编码错误";
				pass = false;
			} else {
				//18位身份证需要验证最后一位校验位
				if (code.length == 18) {
					code = code.split('');
					//∑(ai×Wi)(mod 11)
					//加权因子
					var factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
					//校验位
					var parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
					var sum = 0;
					var ai = 0;
					var wi = 0;
					for (var i = 0; i < 17; i++) {
						ai = code[i];
						wi = factor[i];
						sum += ai * wi;
					}
					var last = parity[sum % 11];
					if (parity[sum % 11] != code[17]) {
						tip = "校验位错误";
						pass = false;
					}
				}
			}
			if (!pass);
			return pass;
		}



		// Register as a named AMD module, since jQuery can be concatenated with other
		// files that may use define, but not via a proper concatenation script that
		// understands anonymous AMD modules. A named AMD is safest and most robust
		// way to register. Lowercase jquery is used because AMD module names are
		// derived from file names, and jQuery is normally delivered in a lowercase
		// file name. Do this after creating the global so that if an AMD module wants
		// to call noConflict to hide this version of jQuery, it will work.

		// Note that for maximum portability, libraries that are not jQuery should
		// declare themselves as anonymous modules, and avoid setting a global if an
		// AMD loader is present. jQuery is a special case. For more information, see
		// https://github.com/jrburke/requirejs/wiki/Updating-existing-libraries#wiki-anon

		if (typeof define === "function" && define.amd) {
			define("baseex", [], function() {
				return BaseEx;
			});
		}


		var

			// Map over jQuery in case of overwrite
			_BaseEx = window.BaseEx,

			// Map over the $ in case of overwrite
			_Be = window.Be;

		BaseEx.noConflict = function(deep) {
			if (window.Be === BaseEx) {
				window.Be = _Be;
			}

			if (deep && window.BaseEx === BaseEx) {
				window.BaseEx = _BaseEx;
			}

			return BaseEx;
		};

		BaseEx.openArticle = function(title, articleid, channelName, click) {

			md.openWin({
				name: 'articlePanel',
				// url: 'wgt://threeTreat/refreshTop/refreshTopFrame.html',
				url: 'wgt://newVersion/article/articlePanel.html',
				reload: true,
				pageParam: {
					name: 'article',
					url: "http://" + Base.serverPath.split("/")[2] + '/article/html/' + articleid +
						'.html?click=' + click,
					title: title,
					share: true,
					articleId: articleid,
					channelName: channelName,
					click: click,
				}
			});

		};

		// Expose jQuery and $ identifiers, even in AMD
		// (#7102#comment:10, https://github.com/jquery/jquery/pull/557)
		// and CommonJS for browser emulators (#13566)

		// if ( !noGlobal ) {
		window.BaseEx = window.Be = BaseEx;
		// }

		return BaseEx;
	}));
