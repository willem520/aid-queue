
// (function() {

( function( global, factory ) {

  // "use strict";

  if ( typeof module === "object" && typeof module.exports === "object" ) {

    // For CommonJS and CommonJS-like environments where a proper `window`
    // is present, execute the factory and get jQuery.
    // For environments that do not have a `window` with a `document`
    // (such as Node.js), expose a factory as module.exports.
    // This accentuates the need for the creation of a real `window`.
    // e.g. var jQuery = require("jquery")(window);
    // See ticket #14549 for more info.
    module.exports = global.document ?
      factory( global, true ) :
      function( w ) {
        if ( !w.document ) {
          throw new Error( "JSUtil requires a window with a document" );
        }
        return factory( w );
      };
  } else {
    factory( global );
  }

// Pass this if window is not defined yet
} )( typeof window !== "undefined" ? window : this, function( window, noGlobal ) {


  if (typeof JSUtil == "undefined") {
    JSUtil = {};
    window.JSUtil = window.Fj = JSUtil;
  }

  // var version = "0.0.1";

  // JSUtil.expando = "JSUtil" + ( version + Math.random() ).replace( /\D/g, "" );

  // function Data() {
  //     this.expando = JSUtil.expando + Data.uid++;
  // }

  // Data.uid = 1;

  // Data.prototype = {

  //     cache: function( owner ) {

  //       // Check if the owner object already has a cache
  //       var value = owner[ this.expando ];

  //       // If not, create one
  //       if ( !value ) {
  //         value = {};

  //         // We can accept data for non-element nodes in modern browsers,
  //         // but we should not, see #8335.
  //         // Always return an empty object.
  //         if ( acceptData( owner ) ) {

  //           // If it is a node unlikely to be stringify-ed or looped over
  //           // use plain assignment
  //           if ( owner.nodeType ) {
  //             owner[ this.expando ] = value;

  //           // Otherwise secure it in a non-enumerable property
  //           // configurable must be true to allow the property to be
  //           // deleted when data is removed
  //           } else {
  //             Object.defineProperty( owner, this.expando, {
  //               value: value,
  //               configurable: true
  //             } );
  //           }
  //         }
  //       }

  //       return value;
  //     },
  // }

  // var acceptData = function( owner ) {

  //   // Accepts only:
  //   //  - Node
  //   //    - Node.ELEMENT_NODE
  //   //    - Node.DOCUMENT_NODE
  //   //  - Object
  //   //    - Any
  //   //  - NON-ELEMENT_NODE
  //   //    - _app_tag_
  //   return owner.nodeType === 1 || owner.nodeType === 9 || !( +owner.nodeType ) || owner.getAttribute( "_app_tag_" );
  // };


  JSUtil.get = function ( arg ) {
      if ( JSUtil.isNotEmpty( arg ) ) {
          if ( typeof arg == "string" ) {
              return document.querySelector( arg );
          }
          if ( typeof arg == "object" ) {
              return arg;
          }
      }
  }

  /* js工具 */
  JSUtil.addHandle = function( element, type, handle, data ) {
      var handleObj,handlers,events;
      var elmData = JCache.private.get( element );
      if ( !( events = elmData.events ) ) {
          events = elmData.events = {};
      }

      if ( !( handlers = events[ type ] ) ) {
          handlers = events[ type ] = [];
      }

      handleObj = {
          "handle" : handle,
          "type" : type,
          "data" : data
      };

      handlers.push( handleObj );

      if( element.addEventListener ) {
          element.addEventListener( type, handle );
      } else if ( element.attachEvent ) {
          element.attachEvent( "on"+type, handle );
      } else {
          element[ "on" + type ] = handle;
      }
  }

  JSUtil.removeHandle = function( element,type,handle ) {
      var handleObj,handlers,events;
      var elmData = JCache.private.get( element );
      if ( !( events = elmData.events ) ) {
          events = elmData.events = {};
      }

      // if ( !( handlers = events[ type ] ) ) {
      //     handlers = events[ type ] = [];
      // }
      handlers = events[ type ];

      if ( handle ) {
          if ( handlers.indexOf( handle ) > -1) {
              handlers.splice( handlers.indexOf( handle ), 1 );
          }
          if ( element.removeEventListener ) {
              element.removeEventListener( type, handle );
          } else if ( element.detachEvent ) {
              element.detachEvent( "on" + type, handle );
          } else {
              element[ "on" + type ] = null;
          }
      } else {
          var i,handleObj;
          for ( i = 0; i < handlers.length; i++ ) {
              handleObj = handlers[i];

              if ( element.removeEventListener ) {
                  element.removeEventListener( type, handleObj.handle );
              } else if ( element.detachEvent ) {
                  element.detachEvent("on"+type,handleObj.handle);
              } else {
                  element["on"+type] = null;
              }

          }
      }

      // if ( !handlers.length ) {
      //     delete events[ type ];
      // }

  }

  JSUtil.parseDom = function(arg) {
　　 var obj = document.createElement("div");
　　 obj.innerHTML = arg;
// 　　 var list = obj.childNodes;
     var list = obj.children;
     obj = null;
　　 return list;
  }

  JSUtil.domToString = function ( el ) {
　　  var obj = document.createElement("div");
      obj.appendChild( el.cloneNode( true ) );
      return obj.innerHTML;
  }

  JSUtil.insertBefore = function( el, arg ) {
    var nodeList = JSUtil.parseDom( arg );
    var nodes = [];
    for (var j = 0; j < nodeList.length; j++) {
      nodes.push(el.parentNode.insertBefore(nodeList[j], el));
    }
    return nodes;
  }

  JSUtil.append = function( el, arg ) {
    var nodeList = JSUtil.parseDom( arg );
    var doms = [];
    for (var j = 0; j < nodeList.length; j++) {
      doms.push(el.appendChild(nodeList[j], el));
    }
    return doms;
  }

  JSUtil.getAllElements = function ( arg ) {
    var el;
    if( typeof arg == "object" ){
      el = arg;
    } else if ( typeof arg == "string" ){
      el = document.getElementById(arg);
    } else {
      return null;
    }
    return el.querySelectorAll("*");
  }

  JSUtil.isNotEmpty = function ( arg ) {
    if( arg && arg != null && arg != "" ){
      return true;
    }else{
      return false;
    }
  }

  JSUtil.isEmpty = function ( arg ) {
    if( typeof arg == "undefined" || arg == null || arg == "" ){
      return true;
    }
    return false;
  }

  JSUtil.isFunction = function ( arg ) {
    if ( JSUtil.isNotEmpty( arg ) ) {
        if ( typeof arg === "function" ) {
            return true;
        }
        var fun = eval( arg.split( "(" )[0] );
        if ( typeof fun === "function" ) {
            return true;
        }
    }
    return false;
  }

  JSUtil.getFunction = function ( arg, getParams ) {
      if ( JSUtil.isNotEmpty(arg) ) {
          var fun = eval( arg.split( "(" )[0] );
          if ( typeof fun == "function" ) {
              if ( getParams ) {
                  return  JSUtil.stringToFunction( arg );
              } else {
                  return fun;
              }
          }
      }
      return null;
  }

  JSUtil.extendsAttributes = function ( el, newEl, props ) {
      var attributes = el.attributes;
      var attributeName;
      for (var i = 0; i < attributes.length; i++) {
          attributeName = attributes[i].nodeName;
          if( props.indexOf( attributeName ) >= 0){
              continue;
          }
          if( attributeName == "class" ){
              newEl.setAttribute( attributeName, newEl.getAttribute( attributeName ) + " " + attributes[i].nodeValue );
          } else {
              newEl.setAttribute( attributeName, attributes[i].nodeValue );
          }
      }
  }

  JSUtil.stringToFunction = function ( name, el ) {
      var fun = eval( name.split( "(" )[ 0 ] );
      var _params_ = JSUtil._getFunctionParams_( name );
      var obj = this;
      if( el && typeof el == "object" ){
          obj = el;
      }
      var fn = function () {
          fun.apply( obj, _params_ );
      }
      return fn;
  }

  JSUtil._getFunctionParams_ = function ( name ) {
      var _params_ = name.split( "(" )[ 1 ];
      if( _params_ != null ){
          _params_ = _params_.split( ")" )[ 0 ];
          if( _params_ != null ){
              _params_ = _params_.split( "," );
          }
      }
      _params_ = _params_.map( function( val, index, arr ){
        return eval( val );
      } );
      return _params_;
  }

  JSUtil.remove = function ( arg ) {
      var obj;
      if ( typeof arg == "string" ) {
          obj = document.getElementById( arg );
      } else if ( typeof arg == "object" ) {
          obj = arg;
      } else {
          throw "请传入字符串或dom元素";
      }
      if ( obj ) {
          obj.parentNode.removeChild( obj );
      }
  }

  JSUtil.prev = function ( el ) {
      return el.previousElementSibling || el.previousSbiling;
  }

  JSUtil.next = function ( el ) {
      return el.nextElementSibling || el.nextSbiling;
  }

  JSUtil.prevAll = function ( el ) {
      var array = new Array();
      var prev = JSUtil.prev( el );
      while ( prev ) {
          if ( prev.nodeType == 1 ) {
              array.push( prev );
          }
          prev = JSUtil.prev( prev );
      }
      return array;
  }

  JSUtil.nextAll = function ( el ) {
      var array = new Array();
      var next = JSUtil.next( el );
      while ( next ) {
          if ( next.nodeType == 1 ) {
              array.push( next );
          }
          next = JSUtil.next( next );
      }
      return array;
  }

  // JSUtil.remToPx = function ( rem, fontSize ) {
  //     if ( JSUtil.isEmpty( fontSize ) )  {
  //         fontSize = 16;
  //     }
  //     return rem*16;
  // }

  JSUtil.remToPx = function ( rem ) {
      var elm = document.createElement( "div" );
      elm.style.height = rem + "rem";
      // elm.style.display = "none";
      document.body.appendChild( elm );
      var h = elm.offsetHeight;
      JSUtil.remove( elm );
      return h;
  }

  JSUtil.pxToRem = function ( px ) {
      var elm = document.createElement( "div" );
      elm.style.height = 1 + "rem";
      // elm.style.display = "none";
      document.body.appendChild( elm );
      var h = elm.offsetHeight;
      JSUtil.remove( elm );

      var ratio = 1 / h

      return px * ratio;
  }

  JSUtil.css = function ( el, attribute, value ) {
      if ( typeof value != "undefined" ) {
          JSUtil.get( el ).style[ attribute ] = value;
      } else {
          var value = JSUtil.get( el ).style[ attribute ];
          if ( JSUtil.isEmpty( value ) ) {
              value = "0";
          }
          return value;

      }
  }

  JSUtil.css_left = function ( el ) {
      var value = JSUtil.get( el ).left;
      if ( JSUtil.isEmpty( value ) ) {
          return 0;
      }
      return value;
  }

  JSUtil.array_sum = function (arr) {
      var s = 0;
      arr.forEach(function(val, idx, arr) {
          s += val;
      }, 0);
      return s;
  }

  /**
   * html编码
   */
  JSUtil.encode = function ( obj, hasClone ){
    var new_obj = null;
    if ( hasClone ) {
        new_obj = JSUtil.clone( obj );
    } else {
        new_obj = obj;
    }
    if ( new_obj && Array.isArray( new_obj ) ) {
        for (var i = 0; i < new_obj.length; i++) {
          new_obj[ i ] = JSUtil.encode( new_obj[ i ] );
        }
    } else if ( new_obj && typeof new_obj === "object" ) {
        var key,value;
        for ( key in new_obj ) {
          value = new_obj[key];
          new_obj[key] = JSUtil.encode( value );
        }
    } else {
      new_obj = htmlEncode( new_obj );
    }
    return new_obj;
  }

  /*1.用浏览器内部转换器实现html转码*/
  JSUtil.htmlEncode = function ( html ) {
      var output = null;
      if ( html ) {
          //1.首先动态创建一个容器标签元素，如DIV
          var temp = document.createElement ("div");
          //2.然后将要转换的字符串设置为这个元素的innerText(ie支持)或者textContent(火狐，google支持)
          (temp.textContent != undefined ) ? (temp.textContent = html) : (temp.innerText = html);
          //3.最后返回这个元素的innerHTML，即得到经过HTML编码转换的字符串了
          output = temp.innerHTML;
          temp = null;
      }
      return output;
  }

  /*2.用浏览器内部转换器实现html解码*/
  JSUtil.htmlDecode = function ( text ) {
      var output = null;
      if ( text ) {
          //1.首先动态创建一个容器标签元素，如DIV
          var temp = document.createElement("div");
          //2.然后将要转换的字符串设置为这个元素的innerHTML(ie，火狐，google都支持)
          temp.innerHTML = text;
          //3.最后返回这个元素的innerText(ie支持)或者textContent(火狐，google支持)，即得到经过HTML解码的字符串了。
          output = temp.innerText || temp.textContent;
          temp = null;
      }
      return output;
  }

  JSUtil.clone = function ( obj ) {
      var o = null;
      if ( obj && Array.isArray( obj ) ) { // 数组
          o = obj.concat();
      } else if ( obj && typeof obj === "function" ) { // 方法
        o = obj;
      } else if ( obj && typeof obj === "object" ) { // 对象
          if ( Object.assign ) {
              o = Object.assign( {}, obj );
          } else {
              o = new Object();
              var key,value;
              for ( key in obj ) {
                  value = obj[ key ];
                  o[ key ] = JSUtil.clone( value );
              }
          }
      } else {
          o = obj;
      }
      return o;
  }

  JSUtil.removeChild = function ( obj ) {
      var list = obj.children;
      for (var i = list.length - 1; i >= 0; i--) {
          obj.removeChild( list[i] );
      }
  }

  JSUtil.isNumber = function ( obj ) {
      return obj == +obj
  }

  JSUtil.top = function ( obj ) {
      var win = obj.ownerDocument.defaultView;
      var top = obj.getBoundingClientRect().top + win.pageYOffset;
      return top;
  }

  JSUtil.left = function ( obj ) {
      var win = obj.ownerDocument.defaultView;
      var left = obj.getBoundingClientRect().left + win.pageXOffset;
      return left;
  }

  // copy from jquery
  JSUtil.extend = function () {
      var options, name, src, copy, copyIsArray, clone,
        target = arguments[ 0 ] || {},
        i = 1,
        length = arguments.length,
        deep = false;

      // Handle a deep copy situation
      if ( typeof target === "boolean" ) {
        deep = target;

        // Skip the boolean and the target
        target = arguments[ i ] || {};
        i++;
      }

      // Handle case when target is a string or something (possible in deep copy)
      if ( typeof target !== "object" && !isFunction( target ) ) {
        target = {};
      }

      // Extend jQuery itself if only one argument is passed
      if ( i === length ) {
        target = this;
        i--;
      }

      for ( ; i < length; i++ ) {

        // Only deal with non-null/undefined values
        if ( ( options = arguments[ i ] ) != null ) {

          // Extend the base object
          for ( name in options ) {
            src = target[ name ];
            copy = options[ name ];

            // Prevent never-ending loop
            if ( target === copy ) {
              continue;
            }

            // Recurse if we're merging plain objects or arrays
            if ( deep && copy && ( jQuery.isPlainObject( copy ) ||
              ( copyIsArray = Array.isArray( copy ) ) ) ) {

              if ( copyIsArray ) {
                copyIsArray = false;
                clone = src && Array.isArray( src ) ? src : [];

              } else {
                clone = src && jQuery.isPlainObject( src ) ? src : {};
              }

              // Never move original objects, clone them
              target[ name ] = JSUtil.extend( deep, clone, copy );

            // Don't bring in undefined values
            } else if ( copy !== undefined ) {
              target[ name ] = copy;
            }
          }
        }
      }

      // Return the modified object
      return target;
  }

  JSUtil.isEmptyObject = function( obj ) {

      /* eslint-disable no-unused-vars */
      // See https://github.com/eslint/eslint/issues/6125
      var name;

      for ( name in obj ) {
        return false;
      }
      return true;
  }

// })();

// var version = "0.0.1",JSUtil = function() {
//     return new JSUtil.fn.init();
// };

// JSUtil.fn = JSUtil.prototype = {

// }

// var init = JSUtil.fn.init = function () {

//     return this;
// }

// init.prototype = JSUtil.fn;

// return JSUtil;


  // Register as a named AMD module, since jQuery can be concatenated with other
  // files that may use define, but not via a proper concatenation script that
  // understands anonymous AMD modules. A named AMD is safest and most robust
  // way to register. Lowercase jquery is used because AMD module names are
  // derived from file names, and jQuery is normally delivered in a lowercase
  // file name. Do this after creating the global so that if an AMD module wants
  // to call noConflict to hide this version of jQuery, it will work.

  // Note that for maximum portability, libraries that are not jQuery should
  // declare themselves as anonymous modules, and avoid setting a global if an
  // AMD loader is present. jQuery is a special case. For more information, see
  // https://github.com/jrburke/requirejs/wiki/Updating-existing-libraries#wiki-anon

  if ( typeof define === "function" && define.amd ) {
    define( "jsutil", [], function() {
      return JSUtil;
    } );
  }


  var

    // Map over jQuery in case of overwrite
    _JSUtil = window.JSUtil,

    // Map over the $ in case of overwrite
    _Ju = window.Ju;

  JSUtil.noConflict = function( deep ) {
    if ( window.Ju === JSUtil ) {
      window.Ju = _Ju;
    }

    if ( deep && window.JSUtil === JSUtil ) {
      window.JSUtil = _JSUtil;
    }

    return JSUtil;
  };

  // Expose jQuery and $ identifiers, even in AMD
  // (#7102#comment:10, https://github.com/jquery/jquery/pull/557)
  // and CommonJS for browser emulators (#13566)

  if ( !noGlobal ) {
    window.JSUtil = window.Ju = JSUtil;
  }

  return JSUtil;
} );