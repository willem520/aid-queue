(function($) {

	if (typeof Base == "undefined") {
		Base = {};
		window.Base = Base;
	}
	$.extend(Base, window.config);
	// Base.urlPath = {
	// 	...cas
	// }

	var cas = window.cas;
	var user = window.user;
	var intel = window.intel;
	var regNur = window.regNur;
	var wgDrug = window.wgDrug;

	var familySign = window.familySign;
	Base.urlPath = new Object();
	Object.assign(Base.urlPath, cas, user, intel, regNur, wgDrug, familySign);

	Base.requestServer = function(url, param = {}, callback, mask = true, requestEncrypt = true, responseEncrypt = true,
		type = 'post') {
		if (mask) {
			md.showProgress({
				content: '加载中，请稍候...',
				modal: true
			});
		}

		param.dataSouc = '1';
		console.log("---------------url---" + url)
		// alert(url+"---"+mask)
		console.log("---------------param---" + JSON.stringify(param));
		param = Base.requestInterceptor(param, requestEncrypt); // 加密方法

		var token = md.getPrefs({
			key: 'token'
		}) || '';

		if (!requestEncrypt) {

			param = JSON.stringify(param);

		}

		var urlPath = Base.serverPath + Base.urlPath[url];
		var timestamp = (Date.now() / 1000).toFixed();
		var nonce = Math.random().toString(36).substr(2);
		var paasid = 'jyt_test';
		var paastoken = 'gfq0ZGRLWwOuJE2GJO5Srcgko2yXsjVL';

		var XTsignature = getSignature(timestamp, paastoken, nonce, timestamp);
		var signature = hex_md5( timestamp + nonce + token + "jyb4443" );

		md.ajax({

			method: type,
			headers: {
				// "user-agent" : system,
				/*
				 * 过网关需要的参数
				 */
				"X-Tif-Nonce": nonce,
				"X-Tif-Timestamp": timestamp,
				"X-Tif-Paasid": paasid,
				"X-Tif-Signature": XTsignature,

				"jyb-timestamp": timestamp,
				"jyb-nonce": nonce,
				"jyb-signature": signature,

				"Content-Type": "application/json;charset=UTF-8",
				"token": token,
				"dataSouc": '1',
			},
			url: urlPath,
			data: {
				body: param
			}

		}, function(ret, err) {

			if (mask) {
				md.hideProgress();
			}

			if (ret) {

				var response = Base.responseInterceptor(ret.body, responseEncrypt); // 解密方法
				console.log("------------------------------response------------------------------" + response)

				// console.log(response);


				if (responseEncrypt) {
					response = JSON.parse(response);
				}

				// console.log(JSON.stringify(response));
				callback(response);


				// if ( response.code != 0 ) {
				// 	var getMsg = response.message || "接口连接异常，请稍后再试。";
				// 	md.alert({
				// 	    msg: getMsg
				// 	});
				// }else {


				// }


			}

			if (err) {
				console.log(JSON.stringify(err))
				var statusCode = '';

				if (md.systemType == 'android') {
					statusCode = err.code;
				}

				if (md.systemType == 'ios') {
					statusCode = err.statusCode;
				}

				/**
				 * 403时登录token失效，此时调用登录界面，并增加通知的监听，在登录成功后获取到监听，可在catch中进行后续操作
				 */
				if (statusCode == 403) {
					md.hideProgress();
					md.execScript({
						name: 'root',
						script: 'toLgin();'
					});

					md.removeEventListener({
						name: 'login'
					});

					md.addEventListener({
						name: 'login'
					}, (ret) => {
						md.removeEventListener({
							name: 'login'
						});
						md.closeWin({
							name: md.winName
						});
					});

					md.removePrefs({
						key: 'token'
					});
				}
			}
		});

	}

	Base.removeInput = function() {
		$("#inputMC,#inputArea").remove();
	}

	Base.jybConfirm = function(content, callback1, callback2) {
		$(document).off("click", "#confirmBtn");
		$(document).off("click", "#cancelBtn");

		var title = content.title || "";
		var confirm = content.confirm;
		var cancel = content.cancel || "";
		var detail = content.detail;
		var align = content.align || "left";
		var amplify = content.amplify || false;
		var countdown = content.countdown || '';
		var height = "auto";
		var top = "25%";
		var maxHeight = "4.2rem";
		if (amplify) {
			var winHeight = md.winHeight;
			height = winHeight * 0.8 + "px";
			top = winHeight * 0.1 + "px";
			maxHeight = winHeight * 0.8 - (55 + 44 + 22) + "px";
			if (title == "") {
				maxHeight = winHeight * 0.8 - (20 + 44 + 22) + "px";
			}
		}

		var ret;
		var inputWin =
			"<div id=\"inputMC\" style=\"width:100%;opacity:0.5;position:fixed;background:black;z-index:999;top:0;height:100%;\"></div>" +
			"<div id=\"inputArea\" style=\"width:80%;height:" + height +
			";background:#ffffff;border-radius:5px;position:fixed;top:" + top + ";left:10%;z-index:1000;\">";
		if (title == "") {
			inputWin += "<div style=\"width:100%;height:20px;text-align:center;\"></div>";
		} else {
			inputWin +=
				"<div style=\"width:100%;line-height:35px;text-align:center;font-size:0.32rem;color:#000000;padding:10px 0;\">" +
				title + "</div>";
		}
		inputWin +=
			"<div id=\"inputBtn\" style=\"width:80%;margin-left:10%;border-radius:5px;color:#999999;max-height:" +
			maxHeight + ";min-height:1.2rem;overflow:auto;overflow-y:auto;text-align:" + align + "\">" +
			detail + "</div>";
		if (cancel == "") {
			inputWin +=
				"<div id=\"confirmBtn\" style=\"width:80%;background:#6595df;color:#ffffff;text-align:center;height:0.8rem;line-height:0.8rem;margin-left:10%;margin-top:0.2rem;float:left;border-radius:5px;font-size:0.3rem;margin-bottom: 0.2rem;\">" +
				confirm + "</div>" +
				"</div>";
		} else {
			inputWin +=
				"<div id=\"cancelBtn\" style=\"width:40%;background:#ffffff;color:#7f7f7f;text-align:center;height:0.8rem;line-height:0.8rem;margin-left:8%;margin-top:0.2rem;float:left;border:1px solid #eeeeee;border-radius:5px;font-size:0.3rem;margin-bottom: 0.2rem;\">" +
				cancel + "</div>" +
				"<div id=\"confirmBtn\" style=\"width:40%;background:#6595df;color:#ffffff;text-align:center;height:0.8rem;line-height:0.8rem;margin-right:8%;margin-top:0.2rem;float:right;border-radius:5px;font-size:0.3rem;margin-bottom: 0.2rem;\">" +
				confirm + "</div>" +
				"</div>";
		}

		$("body").append(inputWin);
		if (countdown != '') {
			$("#confirmBtn").css('background', '#aaaaaa').text(countdown);
			$("#confirmBtn").attr('id', 'cannotBtn');
			setTimeout(function() {
				submitCount(countdown);
			}, 1000);
		}
		$(document).on("click", "#confirmBtn", function() {
			Base.removeInput();
			callback1();
		});
		$(document).on("click", "#cancelBtn", function() {
			$("#inputMC,#inputArea").remove();
			Base.removeInput();
			if (callback2) {
				callback2();
			}
		});

		function submitCount(countdown) {
			countdown = parseInt(countdown);
			if (countdown > 0) {
				countdown--;
				$("#cannotBtn").text(countdown);
				setTimeout(function() {
					submitCount(countdown);
				}, 1000)
			} else if (countdown == 0) {
				$("#cannotBtn").css('background', '#6595df').text(confirm);
				$("#cannotBtn").attr('id', 'confirmBtn');
			}
		}
	}


	/**
	 * 点击事件
	 * 
	 * @method click
	 * @param {string}
	 *            selector 必选 选择器
	 * @param {string}
	 *            act 可选 点击效果class: md-act1(背景色为#eee)、md-act2(点击缩小弹动效果)
	 * @param {function}
	 *            func 必须 回调方法， 接收两个参数1：点击当前元素$(this), 2: 点击事件状态e
	 */
	Base.click = function(selector, func, act) {
		var hasTouch = ('ontouchstart' in window);
		var className = act || "";
		if (className) {
			if (hasTouch) {
				$(document).on("touchstart", selector, function() {
					$(this).addClass(className);
				});
				$(document).on("touchend", selector, function() {
					$(this).removeClass(className);
				});
				$(document).on("touchcancel", selector, function() {
					$(this).removeClass(className);
				});
				$(document).on("touchmove", selector, function() {
					$(this).removeClass(className);
				});
			} else {
				$(document).on("mousedown", selector, function() {
					$(this).addClass(className);
				});
				$(document).on("mouseup", selector, function() {
					$(this).removeClass(className);
				});
			}
		}
		var eventName = "click";
		if (typeof mdui != "undefined" && "ontouchstart" in window) {
			eventName = "tap";
		}
		$(document).on(eventName, selector, function(e) {
			var $this = $(this);
			func($this, e);
		});
	}

	Base.requestInterceptor = function(param, encrypted) {

		if (encrypted) {
			// 加密
			if (param) {
				var aesKey = md.getPrefs({
					key: 'aesKey'
				}) || '';
				var aesIv = md.getPrefs({
					key: 'aesIv'
				}) || '';
				var result = encrypt(JSON.stringify(param), aesKey, aesIv);
				param = result;
			}
		}
		return param;

	}

	Base.responseInterceptor = function(param, encrypted) {

		if (encrypted) {
			// 解密
			if (param) {
				var aesKey = md.getPrefs({
					key: 'aesKey'
				}) || '';
				var aesIv = md.getPrefs({
					key: 'aesIv'
				}) || '';
				var result = decrypt(param, aesKey, aesIv);
				param = result;

			}
		}
		return param;

	}

	/**
	 * 没有数据显示显示
	 */
	Base.noDataPage = function(selector, text, bottom, top2, vue) {
		var $n = $(selector);
		if (!$n[0]) {
			$n = $(".md-content");
		}
		// if (text == undefined) {
		// 	text = "系统异常没有找到记录";
		// }
		text = ''
		if (bottom == undefined) {
			bottom = "0rem";
		}
		if (top2 == undefined) {
			top2 = "1.5rem";
		}
		var src = "../images/nodata.png";
		if (vue) {
			src = "../jybimage/nodata.png";
		}
		var div = '' + '<div class="md-box md-ac md-pc md-ver md-f1" style="position:fixed;top:0;left:0;width:100%;background-image:url(' + src + ');height:7rem;background-size:100% 100%">'
			/*              + '<div class="md-box no-page-img md-img"></div>'*/
			+
			'<div class="md-box no-text1" style="width:60%;position:absolute;top:0.4rem;left:1rem;font-size:0.35rem;display:block!important;color:#999;">' +
			text + '</div>' + '</div>';
		$n.html(div);
		/*
		 * $n.tap(function() { Base.refreshWin(); });
		 */
	};

	/*

	    * 远程问诊功能
	    
	    * intelLogin:登录
	    * setUserInfo:设置账户信息
	    * chatTo:打开对话列表
	    * addMsgListener:添加消息监听事件
	    * addCustomNotifyListener:添加自定义通知消息监听事件
	    * addOogeListener:添加应用消息监听事件
	    * startUrl:会话窗口打开页面方法，参数同openWin
	    * setSessionBottomMenu:设置会话菜单
	    * sendMsg:发送自定义消息
	    * sendNoticeMsg:发送系统通知
	    * backToStart:返回下层页面
	    * sendTextMsg:发送消息

	*/

	Base.intelLogin = function(uid, callback) {
		md.showProgress({
			content: '加载中，请稍候...',
			modal: true
		});
		UIMClient.login({
			"uid": uid,
			"token": '',
			"needInitData": false
		}, function(ret, err) {

			if (ret && ret.code == 0) {
				md.hideProgress();
				console.log("login+++++" + JSON.stringify(ret))
				var ret = 1;
				callback(ret);
			}
			// else{
			//      console.log( "login+++++" + JSON.stringify( ret ) )
			//      Base.intelLogin( uid );
			// }
		});



	}

	Base.setUserInfo = function(uid, sex, nickName, tel, callback) {
		UIMClient.setUserInfo({
			"uid": uid,
			"sex": sex,
			"nickName": nickName,
			"avatar": "../images/adult_man.png",
			"email": "",
			"tel": tel,
			"phone": tel,
		}, function(ret, err) {
			if (ret) {
				console.log("setUserInfo+++++" + JSON.stringify(ret));
				callback("1");
			} else {
				console.log("setUserInfo+++++" + JSON.stringify(ret))
				callback("0");
			}
		});
	}

	Base.chatTo = function(uid, callback) {

		UIMClient.setUIMClientParams({
			isShowUserDetailInfo: false
		});

		md.setPrefs({
			key: 'intoRoom',
			value: '0'
		});

		UIMClient.chatTo({
			"uid": uid,
		}, function(ret, err) {
			if (ret) {
				console.log("chatTo+++++" + JSON.stringify(ret));
				if (ret.code == 1) {
					if (md.systemType == 'android') {

						UIMClient.clearCache(function(ret, err) {});

					}
				} else {
					var ret = "1";
					callback(ret);
				}

			} else {
				console.log("chatTo+++++" + JSON.stringify(ret));
			}
		});
	}

	Base.addMsgListener = function(callback) {


		UIMClient.addMsgListener(function(ret, err) {
			if (ret.code === 0) {
				console.log("addMsgListener+++++" + JSON.stringify(ret));
				callback("1");
			} else {
				console.log("addMsgListener+++++" + JSON.stringify(ret));
			}
		});

	}

	Base.addCustomNotifyListener = function(callback) {
		UIMClient.addCustomNotifyListener(function(ret, err) {
			if (md.systemType == "ios") {
				var result = ret.result;
			} else {
				var result = JSON.parse(ret.result);
			}
			if (ret.code == 0) {
				console.log("addCustomNotifyListener+++++" + JSON.stringify(ret));
				callback("1");
			} else {
				console.log("addCustomNotifyListener+++++" + JSON.stringify(ret));
			}
		});
	}

	Base.addOogeListener = function(callback) {

		UIMClient.addOogeListener(function(ret, err) {

			if (md.systemType == "ios") {
				var result = ret.result;
			} else {
				var result = JSON.parse(ret.result);
			}
			if (ret.code == 0) {
				var callMethod = JSON.parse(result.ooge.callMethod);
				callback(callMethod);
			}

		});

	}

	Base.startUrl = function(name, url, param) {
		UIMClient.startUrl({
			name: name,
			url: 'wgt://' + url,
			reload: true,
			pageParam: param
		}, function(ret, err) {
			if (ret) {
				console.log("startUrl+++++" + JSON.stringify(ret));
			} else {
				console.log("startUrl+++++" + JSON.stringify(ret));
			}
		});
	}

	Base.setSessionBottomMenu = function(callback) {
		UIMClient.clearListener({
			listenerType: 'bottomMenu'
		}, function(ret, err) {
			if (ret) {
				UIMClient.setSessionBottomMenu({
					"menus": [{
							icon: "wgt://threeTreat/images/bottomMenu_jieshu.png",
							index: 2,
							menuName: "结束接诊",
							callMethod: ""
						},
						{
							icon: "wgt://threeTreat/images/bottomMenu_miaoshu.png",
							index: 3,
							menuName: "病情描述",
							callMethod: ""
						},
						{
							icon: "wgt://threeTreat/images/bottomMenu_menzhen.png",
							index: 4,
							menuName: "续方号",
							callMethod: ""
						},
						{
							icon: "wgt://threeTreat/images/bottomMenu_fujia.png",
							index: 5,
							menuName: "续方附加号",
							callMethod: ""
						}
					]
				}, function(ret, err) {
					console.log(ret)
					if (md.systemType == "ios") {
						var result = ret.result;
					} else {
						var result = JSON.parse(ret.result);
					}
					if (ret.code == 0) {
						var menu = result.menu;
						callback(menu.index);
					}
				});
			} else {
				alert(JSON.stringify(ret))
			}
		});


	}

	Base.backToStart = function() {
		UIMClient.backToStart(function(ret, err) {
			if (ret) {
				console.log(JSON.stringify(ret));
			} else {
				console.log(err.msg);
			}
		});
	}

	Base.sendMsg = function(param, callback) {
		md.showProgress({
			content: '加载中，请稍候...',
			modal: false
		});

		if (md.systemType == "ios") {
			param = JSON.stringify(param);
		}

		md.ajax({
			method: 'post',
			headers: {
				'Content-Type': 'application/json',
				'UIM-SECRET': 'QWERTY!@#$%ASD'
			},
			url: 'http://yqim.tjyinhai.cn:80/uim/uim/msg/sendMessage',
			data: {
				body: param
			}
		}, function(ret, err) {
			if (ret) {
				md.hideProgress();
				callback(1);
			} else {
				md.toast({
					msg: '网络异常',
					duration: 2000,
					location: 'middle'
				});
				md.hideProgress();
			}
		});

	}

	Base.sendNoticeMsg = function(param, callback) {
		md.showProgress({
			content: '加载中，请稍候...',
			modal: false
		});

		if (md.systemType == "ios") {
			param = JSON.stringify(param);
		}

		md.ajax({
			method: 'post',
			headers: {
				'Content-Type': 'application/json',
				'UIM-SECRET': 'QWERTY!@#$%ASD'
			},
			url: 'http://yqim.tjyinhai.cn:80/uim/uim/msg/sendPushMessage',
			data: {
				body: param
			}
		}, function(ret, err) {
			if (ret) {
				md.hideProgress();
			} else {
				md.toast({
					msg: '网络异常',
					duration: 2000,
					location: 'middle'
				});
				md.hideProgress();
			}
		});

	}

	Base.sendTextMsg = function(param, callback, mask) {

		if (mask) {
			md.showProgress({
				content: '加载中，请稍候...',
				modal: true
			});
		}

		if (md.systemType == "ios") {
			param = JSON.stringify(param);
		}

		md.ajax({
			method: 'post',
			headers: {
				'Content-Type': 'application/json',
				'UIM-SECRET': 'QWERTY!@#$%ASD'
			},
			url: 'http://yqim.tjyinhai.cn:80/uim/uim/msg/sendMessage',
			data: {
				body: param
			}
		}, function(ret, err) {
			if (ret) {
				md.hideProgress();
				callback('1');
			} else {
				md.toast({
					msg: '网络异常',
					duration: 2000,
					location: 'middle'
				});
				md.hideProgress();
			}
		});

	}


	/*

	    * 远程问诊功能

	*/


}($));
