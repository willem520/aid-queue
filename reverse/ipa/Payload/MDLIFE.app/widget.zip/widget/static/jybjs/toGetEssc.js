(function($) {

	if ( typeof Base == "undefined" ) {
		Base = {};
		window.Base = Base;
	}
    $.extend(Base, window.config);

	Base.bindBUSSC = function( data ){
        var utype;
        var mdtrterId = data.mdtrterId;
        var closeWin = data.closeWin;
        var userId = md.getPrefs({key: 'userid'}) || '';
        if( mdtrterId == userId ) {
            utype = '1';
        }else {
            utype = '2'
        }

        var winParam = {
            title: '',
            name: 'realName',
            url: '/realName',
            bgColor: 'transparent',
            pageParam: {
                showBar: false,
                essctype: '2',
                utype: utype,
                mdtrterId: mdtrterId,
                closeWin: closeWin,
            }
        }
        
        md.openFrame({
            name: winParam.name,
            url: Base.menuURL + 'navigationBar.html',
            reload: true,
            slidBackEnabled: false,
            bgColor: 'transparent',
            bounces: false,
            pageParam: winParam
        });

    }


}($));