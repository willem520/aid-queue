
(function($, JSUtil, BaseEx) {

  if (typeof JSUtil == "undefined") {
    throw "请先加载jsUtil.js";
  }

  if (typeof BaseEx == "undefined") {
    throw "请先加载common-extend.js";
  }

  if (typeof RenderTag == "undefined") {
    RenderTag = {};
    window.RenderTag = RenderTag;
  }

  TagConfig = {
    eventArray : [], // 缓存事件
    components : {

      /*
       * 文本框：
       * @param {String} app_id id标识
       * @param {String} app_key 文本框名称
       * @param {String} app_value 值
       * @param {String} arrow_icon 右侧箭头图标，指定图标文件路径
       * @param {String} show_arrow_icon 是否显示右侧箭头图标
       * @param {String} show_must 是否必填
       * @param {String} editable 是否可编辑
       * @param {String} show 是否显示：true显示，none隐藏
       * @param {String} title_icon 左侧图标
       * @param {String} title_icon_click 左侧图标点击事件
       * @param {String} disabled 是否可触发点击事件，包括title_icon_click和onclick
       * @param {String} value_ellipsis 是否省略显示过长的值
       * @param {String} border_bottom 是否显示下划线，默认显示
       * @param {String} app_type 文本框type
       * @param {String} validate 验证输入
       * @param {String} style 样式
       * @param {String} onclick 点击事件
       * 
       */
      "app-text" : {
        props : [ 'app_id', 'app_key', 'app_value', 'arrow_icon', 'show_arrow_icon', 'show_must', 'editable', 'show', 'title_icon', 'title_icon_click', 'disabled', 'value_ellipsis', 'border_bottom', 'app_type', 'validate', 'maxlength', 'placeholder', 'key_style', 'value_style', 'style', 'onclick' ],
        template : function( el ) {
          var html=[];
          var _index_ = 0;
          var new_el;

          var app_id = el.getAttribute( this.props[ _index_++ ] );
          var app_key = el.getAttribute( this.props[ _index_++ ] );
          var app_value = el.getAttribute( this.props[ _index_++ ] );
          var arrow_icon = el.getAttribute( this.props[ _index_++ ] );
          var show_arrow_icon = el.getAttribute( this.props[ _index_++ ] );
          var show_must = el.getAttribute( this.props[ _index_++ ] );
          var editable = el.getAttribute( this.props[ _index_++ ] );
          var show = el.getAttribute( this.props[ _index_++ ] );
          var title_icon = el.getAttribute( this.props[ _index_++ ] );
          var title_icon_click = el.getAttribute( this.props[ _index_++ ] );
          var disabled = el.getAttribute( this.props[ _index_++ ] );
          var value_ellipsis = el.getAttribute( this.props[ _index_++ ] );
          var border_bottom = el.getAttribute( this.props[ _index_++ ] );
          var app_type = el.getAttribute( this.props[ _index_++ ] );
          var validate = el.getAttribute( this.props[ _index_++ ] );
          var maxlength = el.getAttribute( this.props[ _index_++ ] );
          var placeholder= el.getAttribute( this.props[ _index_++ ] );
          var key_style = el.getAttribute( this.props[ _index_++ ] );
          var value_style = el.getAttribute( this.props[ _index_++ ] );
          var style = el.getAttribute( this.props[ _index_++ ] );
          var onclick = el.getAttribute( this.props[ _index_++ ] );

          var id = app_id;
          app_key = app_key == null ? "" : app_key;
          app_value = app_value == null ? "" : app_value;
          app_type = app_type == null ? "text" : app_type;

          html.push('<div app_id="' + app_id + '" class="jyb_text" _app_tag_="app-text" ');
          if( style && JSUtil.isNotEmpty(style)  ){
          html.push(' style="' + style + '" ');
          }
          if ( disabled && disabled == "true" ) {
          html.push(' disabled="' + disabled + '" ');
          }
          html.push('>');
            if ( border_bottom && ( border_bottom == "false" || border_bottom == "none") ) {
            html.push('<div class="jyb_text_div" >');
            } else {
            html.push('<div class="jyb_text_div jyb_text_border_bottom" >');
            }
          if( title_icon && JSUtil.isNotEmpty(title_icon) ){
              html.push('<img class="jyb_text_title_icon" src="' + title_icon + '"></img>');
              if( show_must ){
                html.push('<div class="jyb_text_key jyb_detail text_key_color" style="margin-left:0.4rem;' + key_style + '" ><span style="color: red;">* </span>' + app_key + '</div>');
              }else{
                html.push('<div class="jyb_text_key jyb_detail text_key_color" style="margin-left:0.4rem;' + key_style + '" >' + app_key + '</div>');

              }
          }else{
              if( show_must ){
                html.push('<div class="jyb_text_key jyb_detail text_key_color" style="' + key_style + '" ><span style="color: red;">* </span>' + app_key + '</div>');
              }else{
                html.push('<div class="jyb_text_key jyb_detail text_key_color" style="' + key_style + '" >' + app_key + '</div>');
              }
          }
          
          if( editable && editable == "true" ){
              html.push('<input id="' + id + '"class="jyb_text_input jyb_detail text_value_color" type="' + app_type + '" style="text-align:right;' + value_style + '" value="' + app_value + '" maxlength="' + maxlength + '" ');
              if ( placeholder ) {
                  html.push( ' placeholder = "' );
                  html.push( placeholder );
                  html.push( '" ' );
              }
              html.push( ' />' );
          }else{
              if ( value_ellipsis && value_ellipsis == "true" ) {
                  html.push('<div id="' + id + '"class="jyb_text_value jyb_detail text_value_color css_ellipsis" style="' + value_style + '" >' + app_value + '</div>');
              } else {
                  html.push('<div id="' + id + '"class="jyb_text_value jyb_detail text_value_color" style="' + value_style + '" >' + app_value + '</div>');
              }
          }

          if(show_arrow_icon){
            if(arrow_icon){
                html.push('<img class="jyb_text_arrow" src="' + arrow_icon + '"></img>');
            }else{
                html.push('<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>');
            }
          }

            html.push('</div>');
          html.push('</div>');

          // 生成新dom
          new_el = JSUtil.parseDom(html.join(''))[0];

          // 继承属性
          JSUtil.extendsAttributes( el, new_el, this.props );

          if( show && show == "none" ){
            new_el.style.display = "none";
          }
          el.parentNode.replaceChild(new_el, el);

          // 绑定点击事件
          if ( onclick ) {
              // 绑定点击事件
              var fn = function () {
                  var fun = eval( onclick.split( "(" )[ 0 ] );
                  var _params_ = JSUtil._getFunctionParams_( onclick );
                  var disabled = this.getAttribute( "disabled" );
                  if( typeof disabled == "undefined" || JSUtil.isEmpty( disabled ) ){
                      fun.apply( this, _params_ );
                  }
              }
              fn.bind( new_el );
              TagConfig.eventArray.push( new Array( new_el, "click", fn ) );
          }

          // 绑定验证事件
          if ( editable && editable == "true" ) {
              var _validate_ = function ( e ) {
                  // var flag_type = true, flag = true, tip = null;
                  // // console.log( this );
                  var input_el = e.currentTarget;

                  // if ( app_type ) {
                  //     // flag_type = BaseEx.validateInput( input_el.value, app_type );
                  //     var re = BaseEx._validate_[ app_type ]( input_el.value );
                  //     flag_type = re[ 0 ];
                  //     tip = re[ 1 ];
                  // }

                  // if ( validate && JSUtil.isFunction( validate ) ) {
                  //     var fun = eval( validate.split("(")[0] );
                  //     var ret = fun( input_el.value );
                  //     flag = ret[0];
                  //     tip = ret[1];
                  // }

                  // // 验证结果：
                  // if ( !flag_type || !flag ) { // 未通过
                  //     if ( input_el.className.indexOf( "jyb_validate_input" ) < 0 ) {
                  //         input_el.className += " jyb_validate_input";

                  //         var tip_div = document.createElement( "div" );
                  //         var bind_target = document.querySelector("div[_app_tag_='app-body']") || document.body;
                  //         tip_div.id = this.app_id + "_validate_";
                  //         tip_div.className = "_validate_tip_";
                  //         tip_div.innerHTML = tip ;
                  //         tip_div.style.top = ( JSUtil.top( input_el ) - JSUtil.remToPx( 0.4 ) - JSUtil.top( bind_target ) ) + "px";
                  //         tip_div.style.right = ( bind_target.offsetWidth - JSUtil.left( input_el ) - input_el.offsetWidth - JSUtil.left( bind_target ) ) + "px";

                  //         bind_target.appendChild( tip_div );
                          
                  //     }
                  // } else { // 通过
                  //     if ( input_el.className.indexOf( "jyb_validate_input" ) >= 0 ) {
                  //         input_el.className = input_el.className.replace( " jyb_validate_input", "" );
                  //         var tip_div = document.querySelector( "#" + this.app_id + "_validate_" );
                  //         if ( tip_div ) {
                  //             JSUtil.remove( tip_div );
                  //         }
                  //     }
                  // }
                  
                  BaseEx._app_validate_( input_el, app_type, validate );
              }
              _validate_.bind( new_el.querySelector(".jyb_text_input") );
              TagConfig.eventArray.push( new Array( new_el.querySelector(".jyb_text_input"), "input", _validate_ ) );
              TagConfig.eventArray.push( new Array( new_el.querySelector(".jyb_text_input"), "focus", _validate_ ) );


              var _input_ = function ( e ) {
                  var input_el = e.currentTarget;
                  if ( app_type ) {
                      var value = BaseEx._type_[ app_type ]( input_el.value );
                      input_el.value = value;
                      app_value = value;
                  }
              }
              _input_.bind( new_el.querySelector(".jyb_text_input") );
              TagConfig.eventArray.push( new Array( new_el.querySelector(".jyb_text_input"), "input", _input_ ) );

          }


          if( title_icon && title_icon_click ){
            // 绑定点击事件
              var fn = function ( e ) {
                  e.stopPropagation();
                  var obj = this.parentNode.parentNode;
                  var fun = eval( title_icon_click.split( "(" )[ 0 ] );
                  var _params_ = JSUtil._getFunctionParams_( title_icon_click );
                  var disabled = obj.getAttribute( "disabled" );
                  if( typeof disabled == "undefined" || JSUtil.isEmpty( disabled ) ){
                      fun.apply( obj.querySelector( ".jyb_text_title_icon" ), _params_ );
                  }
              }
              fn.bind( new_el );
              TagConfig.eventArray.push( new Array( new_el.querySelector( ".jyb_text_title_icon" ), "click", fn ) );
          }

          var _fn_ = function ( e ) {
              var el = e.currentTarget;
              var input = el.querySelector( "input" );
              if ( input ) {
                  input.focus();
              }
          }
          TagConfig.eventArray.push( new Array( new_el, "click", _fn_ ) );

          return new_el;

        }
      },


      /*
       * 页面标题：
       * @param {String} app_id id标识
       * @param {String} app_key 标题名称
       * @param {String} back_icon 返回图标
       * @param {String} top_button_img 右侧图标
       * @param {String} top_button_img_click 右侧图标点击事件
       * 
       */
      "app-title" : {
        props : [ 'app_id', 'app_key', 'back_icon', 'top_button_img', 'top_button_img_click' ],
        template : function(el) {
          var html=[];
          var _index_ = 0;
          var new_el;

          var innerText = el.innerText.trim();
          var app_id = el.getAttribute( this.props[ _index_++ ] );
          var app_key = el.getAttribute( this.props[ _index_++ ] );
          var back_icon = el.getAttribute( this.props[ _index_++ ] );
          var top_button_img = el.getAttribute( this.props[ _index_++ ] );
          var top_button_img_click = el.getAttribute( this.props[ _index_++ ] );

          var id = app_id;

          if( !( app_key && JSUtil.isNotEmpty( app_key ) ) ){
              app_key = innerText;
          }

          html.push('<div class="header"');
          if( app_id ){
              html.push( ' app_id="' + app_id + '" ' );
          }
          html.push( ' _app_tag_="app-title" >' );
          if( back_icon && ( back_icon == false  || back_icon == 'none' ) ){
              html.push('<div class="header_title css_ellipsis" style="margin-left:20%;">' + app_key + '</div>');
          }else{
              html.push('<div class="back">');
                html.push('<img class="back_img" src="../jybimage/icon_back.png" />');
              html.push('</div>');
              html.push('<div class="header_title css_ellipsis">' + app_key + '</div>');
          }
          if( top_button_img && JSUtil.isNotEmpty( top_button_img ) ){
              html.push('<div class="top_btn">');
                html.push('<img class="btn_img" src="../jybimage/' + top_button_img + '" />');
              html.push('</div>');
          }
          html.push('</div>');
          // html.push('<div style="height:0.8rem;width:100%;background:#f7f7f7;"></div>');

          // 生成新dom
          new_el = JSUtil.parseDom(html.join(''))[0];

          // 继承属性
          JSUtil.extendsAttributes( el, new_el, this.props );

          el.parentNode.replaceChild(new_el, el);

          if(top_button_img_click){
            // 绑定点击事件
            var fun = eval(top_button_img_click.split("(")[0]);
            if(typeof fun == "function"){
              TagConfig.eventArray.push( new Array( new_el.querySelector(".top_btn"), "click", fun ) );
            }
          }
          return new_el;
        }
      },


      /*
       * 按钮：
       * @param {String} app_id id标识
       * @param {String} app_key 标题名称
       * @param {String} onclick 点击事件
       * 
       */
      "app-button" : {
        props : [ 'app_id', 'app_key', 'show', 'onclick' ],
        template : function( el ) {
          var html=[];
          var _index_ = 0;
          var new_el;

          var app_id = el.getAttribute( this.props[ _index_++ ] );
          var app_key = el.getAttribute( this.props[ _index_++ ] );
          var show = el.getAttribute( this.props[ _index_++ ] );
          var onclick = el.getAttribute( this.props[ _index_++ ] );
          var innerHtmlString = el.innerText.trim();

          var id = app_id;

          if( JSUtil.isNotEmpty( innerHtmlString ) ){
            app_key = innerHtmlString;
          }

          html.push('<div class="app_button" ');
          if(id){
            html.push(' id="' + id + '" ');
            html.push(' app_id="' + app_id + '" ');
          }
          html.push(' _app_tag_="app-button" >');
          html.push(app_key);
          html.push('</div>');

          // 生成新dom
          new_el = JSUtil.parseDom(html.join(''))[0];

          // 继承属性
          JSUtil.extendsAttributes( el, new_el, this.props );

          if( show && show == "none" ){
            new_el.style.display = "none";
          }
          el.parentNode.replaceChild( new_el, el );

          if(onclick){
            // 绑定点击事件
            var fun = eval(onclick.split("(")[0]);
            if(typeof fun == "function"){
              TagConfig.eventArray.push( new Array( new_el, "click", fun ) );
            }
          }
          return new_el;
        }
      },

      /*
       * 就诊人：
       * @param {String} app_id id标识
       * @param {String} app_data 标题名称
       * @param {String} show_id 是否显示身份证号
       * @param {String} show_ssc 是否显示社保卡号
       * @param {String} on_select 选择回调
       * @param {String} page_name 所在页面名称
       * @param {String} action_name 要调用的action地址
       */
      "app-patient" : {
        props : [ 'app_id', 'app_data', 'show_id', 'show_ssc', 'on_select', 'page_name', 'action_name', 'show_isbindcard', 'style' ],
        template : function(el) {
          var html=[];
          var _index_ = 0;
          var new_el;

          var app_id = el.getAttribute( this.props[ _index_++ ] );
          var app_data = el.getAttribute( this.props[ _index_++ ] );
          var show_id = el.getAttribute( this.props[ _index_++ ] );
          var show_ssc = el.getAttribute( this.props[ _index_++ ] );
          var on_select = el.getAttribute( this.props[ _index_++ ] );
          var page_name = el.getAttribute( this.props[ _index_++ ] );
          var action_name = el.getAttribute( this.props[ _index_++ ] );
          var style = el.getAttribute( this.props[ _index_++ ] );
          var show_isbindcard = el.getAttribute( this.props[ _index_++ ] );

          var id = app_id;

          show_id = show_id ? show_id : "true";
          show_ssc = show_ssc ? show_ssc : "true";

          html.push('<div class="bindPeople" ');
          if ( app_id ) {
            html.push(' app_id="' + app_id + '" ');
            html.push(' id="' + app_id + '" ');
          }
          if ( show_isbindcard ) {
            html.push(' show_isbindcard="' + show_isbindcard + '" ');
          }
          if ( style && JSUtil.isNotEmpty( style ) ) {
            html.push(' style="' + style + '" ');
          }
          html.push(' _app_tag_="app-patient" >');
              html.push('<input id="buid" class="buid" style="display:none;" />');
              html.push(' <input id="real_buidcard" class="real_buidcard" style="display:none;" /> ');
              html.push(' <input id="bsex" class="bsex" style="display:none;" /> ');

              html.push('<img class="bindImg" />');
              html.push('<div class="bindInfo">');
                  html.push('<p id="buname" class="buname text_value_color" _app_attribute_="buname" ><span style="color:#E8E8E8;">请选择就诊人</span></p>');
                  html.push('<p class="buidcard" ');
          if(show_id && show_id == "true"){
                  html.push('style="display:block;"');
          }else{
                  html.push('style="display:none;"');
          }
                  html.push('>身份证号：<span id="buidcard" _app_attribute_="buidcard" ></span></p>');
                  html.push('<p class="bussc" ');
          if(show_ssc && show_ssc == "true"){
                  html.push('style="display:block;"');
          }else{
                  html.push('style="display:none;"');
          }
                  html.push('>社保卡号：<span id="bussc" _app_attribute_="bussc"></span></p>');
              html.push('</div>');
              html.push('<div class="chooseBtn">');
                  html.push('<p class="chooseText">切换</p>');
                  html.push('<img src="../../static/jybimage/right_blue.png">');
              html.push('</div>');
          html.push('</div>');

          new_el = JSUtil.parseDom(html.join(''))[0];

          // 继承属性
          JSUtil.extendsAttributes( el, new_el, [] );

          el.parentNode.replaceChild( new_el, el );

          if( app_data ){
            if( typeof app_data == "object" ){

            }else if( typeof JSON.parse( app_data ) == "object" ){
              app_data = JSON.parse( app_data );
            }else{
              app_data = null;
            }
            if( JSUtil.isNotEmpty( app_data ) ){
                BaseEx.setValueForPatient( new_el, app_data );
            }
          }

          var _id_ = "_app_patient_" + Math.random();
          new_el.setAttribute( "_id_", _id_ );
          var select_fun = function( e ){
              BaseEx._openUserSelect_( page_name, action_name, null, _id_ );
          };
          
          if ( on_select ) {
            // 绑定点击事件
            var fun = eval( on_select.split("(")[0] );
            if ( typeof fun == "function" ) {
              
              select_fun = function( e ){
                  BaseEx._openUserSelect_( page_name, action_name, on_select, _id_ );
              };

            }

          }

          select_fun.bind( new_el );

          TagConfig.eventArray.push( new Array( new_el, "click", select_fun ) );

          return new_el;

        }

      },

      /*
       * 选项卡：app-select：
       * @param {String} app_id id标识
       * @param {String} app_key 选项卡名称
       * @param {String} app_select_title 选项卡标题
       * @param {String} app_laber_name 作为选项显示的字段
       * @param {String} app_key_name 作为值的字段
       * @param {String} title_icon 选项卡左侧图标地址
       * @param {String} app_collection_data 选项卡数据（json格式）
       * @param {String} on_select 选择回调函数
       * @param {String} show 是否显示
       * @param {String} show_must 是否必填
       * @param {String} order 排序方式：asc升序，desc降序
       * @param {String} _original_html_ 标签html代码：用于刷新数据。不可以在页面标签中出现。
       */
      "app-select" : {
        props : [ 'app_id', 'app_key', 'app_value', 'app_select_title', 'app_laber_name', 'app_key_name', 'title_icon', 'app_collection_data', 'on_select', 'show', 'show_must', 'order', 'show_arrow_icon', 'need_clear', 'formatter', 'border_bottom', 'style' ],
        template : function(el) {
          var html=[];
          var _index_ = 0;
          var new_el;

          var app_id = el.getAttribute( this.props[ _index_++ ] );
          var app_key = el.getAttribute( this.props[ _index_++ ] );
          var app_value = el.getAttribute( this.props[ _index_++ ] );
          var app_select_title = el.getAttribute( this.props[ _index_++ ] );
          var app_laber_name = el.getAttribute( this.props[ _index_++ ] );
          var app_key_name = el.getAttribute( this.props[ _index_++ ] );
          var title_icon = el.getAttribute( this.props[ _index_++ ] );
          var app_collection_data = el.getAttribute( this.props[ _index_++ ] );
          var on_select = el.getAttribute( this.props[ _index_++ ] );
          var show = el.getAttribute( this.props[ _index_++ ] );
          var show_must = el.getAttribute( this.props[ _index_++ ] );
          var order = el.getAttribute( this.props[ _index_++ ] );
          var show_arrow_icon = el.getAttribute( this.props[ _index_++ ] );
          var need_clear = el.getAttribute( this.props[ _index_++ ] );
          var formatter = el.getAttribute( this.props[ _index_++ ] );
          var border_bottom = el.getAttribute( this.props[ _index_++ ] );
          var style = el.getAttribute( this.props[ _index_++ ] );

          if ( !app_id || JSUtil.isEmpty( app_id ) ) {
              app_id = "app" + ( Math.random() + "" ).replace( /\D/g, "" );
          }
          var id = app_id;

          app_collection_data = app_collection_data == null ? "" : app_collection_data;
          app_laber_name = app_laber_name == null ? "name" : app_laber_name;
          app_key_name = app_key_name == null ? "value" : app_key_name;


          html.push('<div class="jyb_text" ');
          if ( app_id ){
              html.push(' app_id="' + app_id + '" ');
          }
          if ( app_value ) {
              html.push(' app_value="' + app_value + '" ');
          }
          if ( style && JSUtil.isNotEmpty(style) ){
              html.push(' style="' + style + '" ');
          }
          html.push(' _app_tag_="app-select" >');
              if ( border_bottom && ( border_bottom == "false" || border_bottom == "none") ) {
                  html.push( '<div class="jyb_text_div ">' );
              } else {
                  html.push( '<div class="jyb_text_div jyb_text_border_bottom ">' );
              }

          if( title_icon && JSUtil.isNotEmpty(title_icon) ){
              html.push('<img class="jyb_text_title_icon" src="' + title_icon + '"></img>');
              if( show_must ){
                  html.push('<span class="jyb_text_key jyb_detail text_key_color" ><span style="color: red;">* </span>' + app_key + '</span>');
              }else{

                  html.push('<span class="jyb_text_key jyb_detail text_key_color" >' + app_key + '</span>');
              }
          }else{
              if( show_must ){
                  html.push('<span class="jyb_text_key jyb_detail text_key_color"><span style="color: red;">* </span>' + app_key + '</span>');
              }else{
                  html.push('<span class="jyb_text_key jyb_detail text_key_color">' + app_key + '</span>');
              }
          }
          
              html.push('<span id="' + id + '" class="jyb_text_value jyb_detail text_value_color css_ellipsis"></span>');

              if( !show_arrow_icon || show_arrow_icon != "none" ){
                  html.push('<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>');
              }

            html.push('</div>');
          html.push('</div>');

          new_el = JSUtil.parseDom(html.join(''))[0];
          new_el.setAttribute( 'app_key_name', app_key_name );
          new_el.setAttribute( '_original_html_', encodeURIComponent( JSUtil.domToString( el ) ) );

          // 继承属性
          JSUtil.extendsAttributes( el, new_el, [ "app_id" ] );

          // 是否隐藏
          if( show && show == "none" ){
            new_el.style.display = "none";
          }

          el.parentNode.replaceChild( new_el, el );

          var _clearFun_
          if ( need_clear && need_clear == "true" ) {
              _clearFun_ = function ( e ) {
                  BaseEx.setSelectValue( app_id, "" );
              }
          }

          var select_fun = function( e ){
              var obj = this;
              var app_select_title = obj.getAttribute( "app_select_title" );
              var app_collection_data = obj.getAttribute( "app_collection_data" );
              var app_laber_name = obj.getAttribute( "app_laber_name" );
              var app_key_name = obj.getAttribute( "app_key_name" );
              if ( app_collection_data ) {
                BaseEx.openPicker( app_select_title, app_collection_data, app_laber_name, function( params ){
                    BaseEx.setSelectValue( app_id, params[ app_key_name ] );
                }, null, order, _clearFun_, formatter );
              }
          };

          if ( on_select ) {
            // 绑定点击事件
            if ( JSUtil.isFunction( on_select ) ) {
              
              select_fun = function( e ){
                  var obj = this;
                  var app_select_title = obj.getAttribute( "app_select_title" );
                  var app_collection_data = obj.getAttribute( "app_collection_data" );
                  var app_laber_name = obj.getAttribute( "app_laber_name" );
                  var app_key_name = obj.getAttribute( "app_key_name" );
                  if ( app_collection_data ) {
                    BaseEx.openPicker( app_select_title, app_collection_data, app_laber_name, function( params ){
                        BaseEx.setSelectValue( app_id, params[ app_key_name ] );
                        var fun = eval( on_select.split("(")[0] );
                        fun( params );
                    }, null, order, _clearFun_, formatter );
                  }
              };

            }

          }

          select_fun.bind( new_el );

          TagConfig.eventArray.push( new Array( new_el, "click", select_fun ) );

          return new_el;
        },
        mounted : function ( new_el ) {
            var app_id = new_el.getAttribute( "app_id" );
            var app_value = new_el.getAttribute( "app_value" );
            BaseEx.setSelectValue( app_id, app_value );
        }

      },

      /*
       * 托盘：
       * @param {String} app_id id标识
       * @param {String} app_key 标题名称
       * @param {String} show 是否显示
       * @param {String} show_must 是否必填
       */
      "app-panel" : {
          props : [ 'app_id', 'app_key', 'show', 'show_must', 'height_diff', 'title_icon', 'style' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var show_must = el.getAttribute( this.props[ _index_++ ] );
              var height_diff = el.getAttribute( this.props[ _index_++ ] );
              var title_icon = el.getAttribute( this.props[ _index_++ ] );
              var style = el.getAttribute( this.props[ _index_++ ] );
              var innerHTML = el.innerHTML;

              html.push('<div class="app_panel_" ');
              if( app_id && JSUtil.isNotEmpty( app_id )  ){
              html.push(' app_id="' + app_id + '" ');
              }
              if( style && JSUtil.isNotEmpty( style )  ){
              html.push(' style="' + style + '" ');
              }
              html.push(' _app_tag_="app-panel" >');
                  html.push('<div class="app_panel_head_">');
                      html.push( '<div style="float:left;margin-left:0.15rem;width:0.2rem;height:0.8rem;" >' );
              if ( title_icon ) {
                          html.push( '<img class="jyb_text_title_icon" src="' + title_icon + '" ></img>' );
              } else {
                          html.push( '<img class="jyb_text_title_icon" src="../jybimage/icon_title.png" ></img>' );
              }
                      html.push( '</div>' );

                      if( show_must ){
                          html.push( '<div class="app_panel_title_ jyb_title "><span style="color: red;">* </span>' + app_key + '</div>' );
                      }else{
                          html.push( '<div class="app_panel_title_ jyb_title ">' + app_key + '</div>' );
                      }

                      
                  html.push('</div>');
              if( JSUtil.isNotEmpty( innerHTML ) ){
                  html.push('<div class="app_panel_body_">');
                      html.push( innerHTML );
                  html.push('</div>');
              }
              html.push('</div>');

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, this.props );
              new_el.setAttribute( "height_diff", height_diff );
              
              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              el.parentNode.replaceChild(new_el, el);

              // RenderTag.renderTag( new_el );

              return new_el;
          },
          mounted : function ( new_el ) {
              var height_diff = new_el.getAttribute( "height_diff" );
              if ( height_diff && JSUtil.isNotEmpty( height_diff ) ) {
                  var obj = new_el;
                  var h = document.body.clientHeight;  // 屏幕高度
                  var t = obj.offsetTop;  // 当前元素top
                  var title = document.querySelector( "div[_app_tag_='app-title']" );
                  var title_height = title.offsetHeight;  // 标题高度
                  var body_height = h - title_height;  // app-body高度
                  var app_panel_height = body_height - t - height_diff;  // panel高度
                  obj.style.height = app_panel_height + "px";
                  var app_panel_head_ = obj.querySelector( ".app_panel_head_" );
                  var app_panel_body_ = obj.querySelector( ".app_panel_body_" );
                  if ( app_panel_body_ ) {
                      app_panel_body_.style.height = ( app_panel_height - app_panel_head_.offsetHeight ) + "px";
                  }
              }

          }
      },

      /*
       * 医院列表其一：
       * @param {String} app_id id标识
       * @param {String} show 是否显示
       * @param {String} hospital_name 医院名称字段
       * @param {String} hospital_address 医院地址字段
       * @param {String} hospital_level 医院等级字段
       * @param {String} hospital_level_name 医院等级名称字段
       * @param {String} hospital_tel 医院电话字段
       * @param {String} hospital_coordinate 医院坐标字段
       * @param {String} hospital_data json数据
       * @param {String} on_row_click 行点击
       */
      "app-hospital-list" : {
          props : [ 'app_id', 'show', 'hospital_id', 'hospital_name', 'hospital_address', 'hospital_level', 'hospital_level_name', 'hospital_tel', 'hospital_coordinate', 'hospital_data', 'show_arrow_icon', 'on_row_click' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var hospital_id = el.getAttribute( this.props[ _index_++ ] );
              var hospital_name = el.getAttribute( this.props[ _index_++ ] );
              var hospital_address = el.getAttribute( this.props[ _index_++ ] );
              var hospital_level = el.getAttribute( this.props[ _index_++ ] );
              var hospital_level_name = el.getAttribute( this.props[ _index_++ ] );
              var hospital_tel = el.getAttribute( this.props[ _index_++ ] );
              var hospital_coordinate = el.getAttribute( this.props[ _index_++ ] );
              var hospital_data = el.getAttribute( this.props[ _index_++ ] );
              var show_arrow_icon = el.getAttribute( this.props[ _index_++ ] );
              var on_row_click = el.getAttribute( this.props[ _index_++ ] );

              if ( JSUtil.isNotEmpty( hospital_data ) ) {
                  hospital_data = JSON.parse( hospital_data );
              } else {
                  hospital_data = {};
              }

              html.push( '<div app_id="' + app_id + '" class="_hospitals_list_" _app_tag_="app-hospital-list" >' );
              html.push( '</div>' );
              new_el = JSUtil.parseDom(html.join(''))[0];
              html=[];
              var row,row_el,fun,_fn_row_click_,_hospital_id, _hospital_name, _hospital_level, _hospital_level_name, _hospital_address, _hospital_coordinate, _hospital_tel;
              for (var i = 0; i < hospital_data.length; i++) {
                  row = hospital_data[i];

                  _hospital_id = BaseEx.filterUndefinedOrNull( row[ hospital_id ] );
                  _hospital_name = BaseEx.filterUndefinedOrNull( row[ hospital_name ] );
                  _hospital_level = BaseEx.filterUndefinedOrNull( row[ hospital_level ] );
                  _hospital_level_name = BaseEx.filterUndefinedOrNull( row[ hospital_level_name ] );
                  _hospital_address = BaseEx.filterUndefinedOrNull( row[ hospital_address ] );
                  _hospital_coordinate = BaseEx.filterUndefinedOrNull( row[ hospital_coordinate ] );
                  _hospital_tel = BaseEx.filterUndefinedOrNull( row[ hospital_tel ] );


                  html=[];
                  html.push( '<div class="_main_list_div_" hospital_id="' + _hospital_id + '" hospital_name="' + _hospital_name + '" hospital_level="' + _hospital_level + '" >' );
                    html.push( '<div class="_main_list_content_">' );
                      html.push( '<div class="_hospital_name_ css_ellipsis">' + _hospital_name + '</div>' );
                      html.push( '<div style="float: left;margin-top: 0.1rem;width: 95%;">' );
                        html.push( '<img src="../jybimage/hospital_icon.png" style="float:left;height:0.4rem;"/>' );
                        html.push( '<input class="_hospital_level_" style="display:none;" value="' + _hospital_level + '"></input>' );
                        html.push( '<div class="_hospital_level_name_" >' + _hospital_level_name + '</div>' );
                  if( JSUtil.isNotEmpty( _hospital_tel ) ){
                        html.push( '<img src="../jybimage/icon_call.png" style="float:left;height:0.4rem;margin-left:15%;"/>' );
                        html.push( '<a class="_hospital_tel_" href="tel:' + _hospital_tel + '" >' + _hospital_tel + '</a>' );
                        html.push( '<div class="_hospital_map_" hospital_address="' + _hospital_address + '" hospital_coordinate="' + _hospital_coordinate + '">查看地图</div>' );
                  }
                      html.push( '</div>' );
                  if( JSUtil.isNotEmpty( _hospital_address ) ){
                      html.push( '<div style="width:95%;float: left;margin-top: 0.1rem;">' );
                        html.push( '<img src="../jybimage/icon_area_b.png" style="float:left;height:0.4rem;"/>' );
                        html.push( '<div class="_hospital_add_" hospital_address="' + _hospital_address + '" hospital_coordinate="' + _hospital_coordinate + '">' + _hospital_address + '</div>' );
                      html.push( '</div>' );
                  }
                  if ( show_arrow_icon == "none" ) {
                      html.push( '<div class="_hospital_arrow_" style="display:none;" >' );
                  } else {
                      html.push( '<div class="_hospital_arrow_">' );
                  }
                        html.push( '<img style="height: 0.35rem;" src="../jybimage/arrow_right.png"></img>' );
                      html.push( '</div>' );
                    html.push( '</div>' );
                    html.push( '<div style="clear:both;"></div>' );
                  html.push( '</div>' );
                  row_el = JSUtil.parseDom( html.join('') )[0];
                  row_el = new_el.appendChild( row_el );
                  if( JSUtil.isNotEmpty( row[ hospital_tel ] ) ){
                      TagConfig.eventArray.push( new Array( row_el.querySelector("._hospital_tel_"), "click", this.methods._fnCall_ ) );
                  }
                  if( JSUtil.isNotEmpty( row[ hospital_address ] ) ){
                      TagConfig.eventArray.push( new Array( row_el.querySelector("._hospital_map_"), "click", this.methods._fnGoMap_ ) );
                  }

                  if ( on_row_click ) {
                      fun = eval( on_row_click.split("(")[0] );
                      if ( typeof fun == "function" ) {
                          _fn_row_click_ = function ( e ) {
                              e.stopPropagation();
                              var el = e.currentTarget;
                              var hospital_id = el.getAttribute("hospital_id");
                              var hospital_name = el.getAttribute("hospital_name");
                              var hospital_level = $(el).attr("hospital_level");
                              fun ( hospital_id, hospital_name, hospital_level );
                          }

                          TagConfig.eventArray.push( new Array( row_el, "click", _fn_row_click_ ) );
                      }
                  }

              }
              
              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              el.parentNode.replaceChild( new_el, el );
              return new_el;
          },
          methods : {
              _fnCall_ : function ( e ){
                e.stopPropagation();
                var tel = this.getAttribute("href").split("tel:")[1];
                MDLifeEx.call( tel );
              },

              _fnGoMap_ : function ( e ){
                e.stopPropagation();
                var hospital_address = $(this).attr("hospital_address");
                var hospital_coordinate = $(this).attr("hospital_coordinate");
                md.openWin({
                    name: 'gomap',
                    url: 'wgt://threeTreat/service/gomap.html',
                    reload: true,
                    pageParam: {
                        aae006 : hospital_address,
                        aab299 : hospital_coordinate
                    }
                });
              }
          }
      },

      /*
       * 提示：
       * @param {String} app_id id标识
       * @param {String} app_key 标题名称
       * @param {String} show 是否显示
       * @param {String} prompt_style 提示信息样式
       */
      "app-prompts" : {
          props : [ 'app_id', 'app_key', 'show', 'prompt_style' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var prompt_style = el.getAttribute( this.props[ _index_++ ] );
              var innerHTML = el.innerHTML;

              if ( JSUtil.isEmpty( app_key ) ) {
                  app_key = "提示信息";
              }

              html.push('<div app_id="' + app_id + '" class="app_prompts_"  _app_tag_="app-prompts" >');
                  html.push('<div class="app_prompts_head_">');
                      html.push('<p class="app_prompts_title_ jyb_title css_ellipsis ">' + app_key + '</p>');
                  html.push('</div>');
              if( JSUtil.isNotEmpty( innerHTML ) ){
                  html.push('<div style=' + prompt_style + ' class="app_prompts_body_ jyb_detail">');
                      html.push( innerHTML );
                  html.push('</div>');
              }
              html.push('</div>');

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, this.props );
              
              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              el.parentNode.replaceChild(new_el, el);

              return new_el;
          }

      },

      /*
       * 单选项：
       * @param {String} app_id id标识
       * @param {String} app_key 选项名称
       * @param {String} app_value 默认值
       * @param {String} app_laber_name 标签字段
       * @param {String} app_value_name 值字段
       * @param {String} app_collection_data json数据
       * @param {String} on_select 选择回调
       * @param {String} show 是否显示
       * @param {String} _original_html_ html代码
       */
      "app-radio" : {
          props : [ 'app_id', 'app_key', 'app_value', 'app_laber_name', 'app_value_name','app_collection_data', 'on_select', 'show', '_original_html_' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_value = el.getAttribute( this.props[ _index_++ ] );
              var app_laber_name = el.getAttribute( this.props[ _index_++ ] );
              var app_value_name = el.getAttribute( this.props[ _index_++ ] );
              var app_collection_data = el.getAttribute( this.props[ _index_++ ] );
              var on_select = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var _original_html_ = el.getAttribute( this.props[ _index_++ ] );

              var id = app_id;
              // app_collection_data = app_collection_data == null ? "" : app_collection_data;
              var _app_collection_data_;
              if ( JSUtil.isNotEmpty( app_collection_data ) ) {
                  _app_collection_data_ = eval( app_collection_data );
              } else {
                  _app_collection_data_ = [];
              }

              app_laber_name = app_laber_name == null ? "name" : app_laber_name;

              html.push('<div class="_app_radio_" ');
              if(app_id){
                html.push(' app_id="' + app_id + '" ');
              }
              html.push(' _app_tag_="app-radio" >');
              html.push('</div>');
              new_el = JSUtil.parseDom(html.join(''))[0];

              var _radio_,i,radio_el,select_fun,fun;
              for ( i = 0; _app_collection_data_ && i < _app_collection_data_.length; i++) {
                  _radio_ = _app_collection_data_[i];
                  radio_el;
                  html=[];

                  html.push('<div class="_app_radio_option_">');
                      html.push('<div class="_app_radio_laber_" >' + _radio_[ app_laber_name ] + '</div>');
                      html.push('<div class="_app_radio_value_" >');
                  if ( _radio_[ app_value_name ] == app_value ) {
                          html.push('<div class="_app_radio_icon_ _app_radio_checked_" ></div>');
                  } else {
                          html.push('<div class="_app_radio_icon_ _app_radio_uncheck_" ></div>');
                  }
                      html.push('</div>');
                      html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

                  radio_el = JSUtil.parseDom( html.join('') )[0];
                  radio_el.setAttribute( "_app_laber_", _radio_[ app_laber_name ] );
                  radio_el.setAttribute( "_app_value_", _radio_[ app_value_name ] );
                  radio_el.setAttribute( "_radio_option_", JSON.stringify( _radio_ ) );
                  radio_el = new_el.appendChild( radio_el );

                  select_fun = function( e ){
                      var obj = this;
                      var radio_base = obj.parentNode;
                      var array = radio_base.querySelectorAll( "._app_radio_icon_" );
                      for (var i = 0; i < array.length; i++) {
                          array[i].className = "_app_radio_icon_ _app_radio_uncheck_";
                      }
                      obj.querySelector( "._app_radio_icon_" ).className = "_app_radio_icon_ _app_radio_checked_";
                  };

                  if ( on_select ) {
                    // 绑定点击事件
                    fun = eval( on_select.split("(")[0] );
                    if ( typeof fun == "function" ) {
                      
                      select_fun = function( e ){
                          var obj = this;
                          var radio_base = obj.parentNode;
                          var array = radio_base.querySelectorAll( "._app_radio_icon_" );
                          for (var i = 0; i < array.length; i++) {
                              array[i].className = "_app_radio_icon_ _app_radio_uncheck_";
                          }
                          obj.querySelector( "._app_radio_icon_" ).className = "_app_radio_icon_ _app_radio_checked_";
                          var _radio_option_ = obj.getAttribute( "_radio_option_" );
                          var _app_laber_ = obj.getAttribute( "_app_laber_" );
                          var _app_value_ = obj.getAttribute( "_app_value_" );
                          fun( _app_laber_, _app_value_, _radio_option_ );
                      };

                    }

                  }

                  select_fun.bind( radio_el );

                  TagConfig.eventArray.push( new Array( radio_el, "click", select_fun ) );

              }

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );
              new_el.setAttribute( "_original_html_", encodeURIComponent( JSUtil.domToString( el ) ) );

              // 是否隐藏
              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              el.parentNode.replaceChild( new_el, el );
              return new_el;
          }

      },

      /*
       * app-body：配合BaseEx.layout方法，解决留海屏幕兼容问题
       * @param {String} app_id id标识
       * @param {String} app_key 预留属性，暂时没有用
       * @param {String} show 是否显示
       */
      "app-body" : {
          props : [ 'app_id', 'app_key', 'show' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var innerHTML = el.innerHTML;

              html.push('<div class="_app_body_" ');
              if(app_id){
                html.push(' app_id="' + app_id + '" ');
              }
              html.push(' _app_tag_="app-body" >');
                  html.push( innerHTML );
              html.push('</div>');
              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              // 是否隐藏
              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              var clear_div = JSUtil.parseDom('<div style="clear:both;"></div>')[0];
              new_el.appendChild( clear_div );

              el.parentNode.replaceChild( new_el, el );

              // RenderTag.renderTag( new_el );

              return new_el;
          },
          mounted : function ( new_el ) {
              var obj = new_el;
              var title = document.querySelector( "div[_app_tag_='app-title']" );
              var title_height = title.offsetHeight;
              var window_height = document.body.clientHeight;

              obj.style.height = ( window_height - title_height ) + "px";
          }

      },

      /*
       * app-box：布局模块
       * @param {String} app_id id标识
       * @param {String} app_key 预留属性，暂时没有用
       * @param {String} cols 一行显示列数
       * @param {String} show 是否显示
       */
      "app-box" : {
          props : [ 'app_id', 'app_key', 'cols', 'cols_config', 'show' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var cols = parseInt( el.getAttribute( this.props[ _index_++ ] ) );
              var cols_config = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var innerHTML = el.innerHTML;

              html.push('<div class="_app_box_" ');
              if(app_id){
                  html.push(' app_id="' + app_id + '" ');
                  html.push(' id="' + app_id + '" ');
              }
              html.push(' _app_tag_="app-box" >');
                  html.push( innerHTML );
              html.push('</div>');
              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              // 是否隐藏
              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              if ( cols && cols > 1) {
                  var per_width = new Array( cols );
                  if ( cols_config && JSUtil.isNotEmpty( cols_config ) && cols_config.split( ":" ).length == cols ) {
                      var config = cols_config.split( ":" );
                      config.forEach( function( value, index, array ){
                          array[index] = parseFloat( array[index] );
                      } );;
                      var sum = JSUtil.array_sum( config );
                      for (var i = 0; i < per_width.length; i++) {
                          per_width[i] = 100 * config[i] / sum ;
                      }
                  } else {
                      per_width.forEach( function( value, index, array ){
                          array[index] = 100 / cols;
                      } );
                  }

                  var el_list = new_el.children;
                  var child_el,span,count = 0;
                  for (var i = 0; i < el_list.length; i++) {
                      child_el = el_list[i];
                      if ( child_el.style.display == "none" || child_el.getAttribute( "show" ) == "none" ) {
                          continue;
                      }

                      // var div = document.createElement( "div" );
                      // div.style.width = per_width[ count % cols ] + "%";
                      // div.style.float = "left";
                      // div.appendChild( child_el.cloneNode( true ) );
                      // new_el.replaceChild( div, child_el );
                      
                      span = child_el.getAttribute( "span" );
                      if ( span && JSUtil.isNumber( span ) ) {
                          if ( span <= cols ) {

                              count += Math.ceil( span );

                              child_el.style.width = ( 100 / cols * span ) + "%";
                              child_el.style.float = "left";
                              continue;
                          }
                      }

                      child_el.style.width = per_width[ count % cols ] + "%";
                      child_el.style.float = "left";

                      count++;
                  }
              }
              var clear_div = JSUtil.parseDom('<div style="clear:both;"></div>')[0];
              new_el.appendChild( clear_div );

              el.parentNode.replaceChild( new_el, el );

              // RenderTag.renderTag( new_el );

              return new_el;
          }

      },

      /*
       * app-list：列表
       * @param {String} app_id id标识
       * @param {String} app_key 预留属性，暂时没有用
       * @param {String} app_list_data json数据
       * @param {String} app_click 单击事件
       * @param {String} show 是否显示
       * @param {String} show_head 显示列表头
       * @param {String} _original_html_ html代码
       */
      "app-list" : {
          props : [ 'app_id', 'app_key', 'app_list_data', 'app_click', 'show', 'show_head', 'show_arrow_icon', '_original_html_' ],
          template : function( el ) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_list_data = el.getAttribute( this.props[ _index_++ ] );
              var app_click = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var show_head = el.getAttribute( this.props[ _index_++ ] );
              var show_arrow_icon = el.getAttribute( this.props[ _index_++ ] );
              var _original_html_ = el.getAttribute( this.props[ _index_++ ] );
              var innerHTML = el.innerHTML;

              app_key = BaseEx.filterUndefinedOrNull( app_key );
              if ( JSUtil.isEmpty( app_list_data ) ) {
                  app_list_data = [];
              } else {
                  app_list_data = eval( app_list_data );
              }

              html.push('<div class="_app_list_" _app_tag_="app-list" ');
              if(app_id){
                  html.push(' app_id="' + app_id + '" ');
              }
              html.push('>');

                  html.push('<div class="_app_list_title_" >');
                      html.push('<div class="jyb_text_div jyb_text_border_bottom">');
                          html.push('<img class="jyb_text_title_icon" src="../jybimage/icon_title.png"></img>');
                          html.push('<span class="jyb_text_key jyb_detail text_key_color css_ellipsis" >' + app_key + '</span>');
                      html.push('</div>');
                      html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

              if ( show_head && ( show_head == "none" || show_head == "false" ) ) {
                  html.push('<div class="_app_list_head_" style="display:none;" >');
              } else {
                  html.push('<div class="_app_list_head_" >');
              }
                      html.push( innerHTML );
                      html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

                  html.push('<div class="_app_list_body_" >');
              var row_data;
              for (var i = 0; i < app_list_data.length; i++) {
                  row_data = app_list_data[i];
                      html.push('<div class="_app_list_row_" _row_="' + i + '" _row_data_="' + encodeURIComponent( JSON.stringify( row_data ) ) + '" >');
                          html.push( innerHTML );
                          if ( !show_arrow_icon && show_arrow_icon != "true" ) {
                              html.push('<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>');
                          }
                          html.push('<div style="clear:both;"></div>');
                      html.push('</div>');
              }
                      html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

              html.push('</div>');

              new_el = JSUtil.parseDom(html.join(''))[0];
              // alert( JSUtil.domToString( el ) );
              
              new_el.setAttribute( "_original_html_", encodeURIComponent( JSUtil.domToString( el ) ) );

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              el.parentNode.replaceChild( new_el, el );

              // RenderTag.renderTag( new_el );

              if ( app_click ) {
                  var fun = eval( app_click.split( "(" )[0] );
                  if ( typeof fun == "function" ) {
                      var _row_,_fn_;
                      for (var i = 0; i < app_list_data.length; i++) {
                          _row_ = new_el.querySelector( "div[_row_='" + i + "']" );
                          _fn_ = function ( e ) {
                              var obj = this;
                              var _row_data_ = obj.getAttribute( "_row_data_" );
                              var params = JSON.parse( decodeURIComponent( _row_data_ ) );
                              fun( params );
                          };
                          TagConfig.eventArray.push( new Array( _row_, "click", _fn_ ) );
                      }
                  }
              }

              var _data_config_ = BaseEx.vueCommon.appList._getDataConfig_( JSUtil.parseDom( innerHTML ) );
              new_el.setAttribute( "data_config",  JSON.stringify( _data_config_ ) );

              return new_el;
          },
          mounted : function ( new_el ) {
              var obj = new_el.querySelector( "._app_list_body_" );
              if ( obj && obj.children && obj.children.length > 0 ) {
                  var list = obj.children;
                  var row,cell,row_height,clist,i,j,cell_height,cell_top;
                  for ( i = 0; i < list.length; i++ ) {
                      row = list[i];
                      row_height = row.offsetHeight;
                      clist = row.children;
                      for ( j = 0; j < clist.length; j++ ) {
                          cell = clist[ j ];
                          cell_height = cell.offsetHeight;
                          // console.log( row_height + "::" + cell_height );
                          cell_top = ( row_height - cell_height ) / 2;
                          cell.style.top = cell_top + "px";
                      }
                  }
              }
          }
      },

      /*
       * app-list-item：配合列表标签app-list使用
       * @param {String} app_id id标识
       * @param {String} app_key 列字段
       * @param {String} app_width 列宽度
       * @param {String} formatter 格式化值方法
       */
      "app-list-item" : {
          props : [ 'app_id', 'app_key', 'app_width', 'formatter', 'align' ],
          template : function( el ) {
              var html=[];
              var _index_ = 0;
              var new_el = document.createElement( "div" );

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_width = el.getAttribute( this.props[ _index_++ ] );
              var formatter = el.getAttribute( this.props[ _index_++ ] );
              var align = el.getAttribute( this.props[ _index_++ ] );

              var prev_el_array = JSUtil.prevAll( el );
              var next_el_array = JSUtil.nextAll( el );
              var el_count = prev_el_array.length + next_el_array.length; // 加上el本身，减去图标img元素，相当于互相抵消。如果图标元素不显示，还需要将百分比从90改为100。
              

              var _row_data_;
              var className = el.parentNode.className;

              if ( className.indexOf( "_app_list_head_" ) >= 0 ) {
                  new_el = JSUtil.parseDom( '<div class="_app_list_head_cell_ jyb_detail" >' + app_key + '</div>' )[0];
                  if ( JSUtil.isEmpty( app_width ) ) {
                      app_width = 90 / el_count + "%";
                  }
                  new_el.style.width = app_width;
              }

              if ( className.indexOf( "_app_list_row_" ) >= 0 ) {
                  _row_data_ = decodeURIComponent( el.parentNode.getAttribute( "_row_data_" ) );
                  _row_data_ = JSON.parse( _row_data_ );

                  var _row_ = el.parentNode.getAttribute( "_row_" );
                  var _value_ = _row_data_[ app_id ];
                  _value_ = _value_ || "";
                  if ( JSUtil.isFunction( formatter ) ) {
                      var fun = JSUtil.getFunction( formatter );
                      _value_ = fun( _row_, prev_el_array.length, _value_, _row_data_ );
                  }

                  new_el = JSUtil.parseDom( '<div class="_app_list_row_cell_ jyb_detail text_key_color" style="font-size:0.25rem;overflow:hidden;" _col_="' + prev_el_array.length + '" " >' + _value_ + '</div>' )[0];
                  el_count -= 1;
                  if ( JSUtil.isEmpty( app_width ) ) {
                      app_width = 90 / el_count + "%";
                  }
                  new_el.style.width = app_width;

                  if ( align ) {
                      new_el.style.textAlign = align;
                  }
              }

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, this.props );

              el.parentNode.replaceChild( new_el, el );

              return new_el;
          }
      },

      "app-list-ca" : {
          props : [ 'app_id', 'app_key', 'app_list_data', 'app_click', 'show', 'show_head', 'show_arrow_icon', 'data_config' ],
          template : function ( el ) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_list_data = el.getAttribute( this.props[ _index_++ ] );
              var app_click = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var show_head = el.getAttribute( this.props[ _index_++ ] );
              var show_arrow_icon = el.getAttribute( this.props[ _index_++ ] );
              var data_config = el.getAttribute( this.props[ _index_++ ] );
              var innerHTML = el.innerHTML;



              html.push('<div class="_app_list_" _app_tag_="app-list-ca" ');
              if(app_id){
                  html.push(' app_id="' + app_id + '" ');
              }
              html.push('>');

                  html.push('<div class="_app_list_title_" >');
                      html.push('<div class="jyb_text_div jyb_text_border_bottom">');
                          html.push('<img class="jyb_text_title_icon" src="../jybimage/icon_title.png"></img>');
                          html.push('<span class="jyb_text_key jyb_detail text_key_color css_ellipsis" >' + app_key + '</span>');
                      html.push('</div>');
                      html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

              if ( show_head && ( show_head == "none" || show_head == "false" ) ) {
                  html.push('<div class="_app_list_head_" style="display:none;" >');
              } else {
                  html.push('<div class="_app_list_head_" >');
              }
                      html.push( innerHTML );
                      html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

                  html.push('<div class="_app_list_body_" >');
                      html.push('<div class="_app_list_content_" ></div>');
              // var row_data;
              // for (var i = 0; i < app_list_data.length; i++) {
              //     row_data = app_list_data[i];
              //         html.push('<div class="_app_list_row_" _row_="' + i + '" _row_data_="' + encodeURIComponent( JSON.stringify( row_data ) ) + '" >');
              //             html.push( innerHTML );
              //             if ( !show_arrow_icon && show_arrow_icon != "true" ) {
              //                 html.push('<img class="jyb_text_arrow" src="../jybimage/arrow_right.png"></img>');
              //             }
              //             html.push('<div style="clear:both;"></div>');
              //         html.push('</div>');
              // }
              //         html.push('<div style="clear:both;"></div>');
                  html.push('</div>');

              html.push('</div>');

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              el.parentNode.replaceChild( new_el, el );

              var _data_config_ = BaseEx.vueCommon.appList._getDataConfig_( JSUtil.parseDom( innerHTML ) );

              // 缓存列表配置
              BaseEx.vueCommon.appList2.cacheConfig( new_el, _data_config_ );

              BaseEx.setListData( new_el, app_list_data, false );

              // 添加滚动事件
              var _app_list_body_ = new_el.querySelector( "._app_list_body_" );
              var _roll_= function ( e ) {
                  // var st = setTimeout( function ( e ) {
                      BaseEx.vueCommon.appList2.scrollList( app_id );
                  // }, 300 );
              };
              TagConfig.eventArray.push( new Array( _app_list_body_, "scroll", _roll_ ) );

              return new_el;
          },
          mounted : function ( new_el ) {
              var _app_list_body_ = new_el.querySelector( "._app_list_body_" );
              // var win_length = 0;

              // 调整列表体高度和滚动样式
              var top = JSUtil.top( _app_list_body_ );
              var win_height = _app_list_body_.ownerDocument.documentElement.clientHeight || _app_list_body_.ownerDocument.body.clientHeight;
              _app_list_body_.style.height = ( win_height - top ) + "px";
              _app_list_body_.style.overflowY = "auto";
              BaseEx.vueCommon.appList2.initList( new_el );
          }
      },

      /*"app-date" : {
          props : [ 'app_id', 'app_key', 'app_value', 'show_left_icon', 'show_right_icon', 'right_icon', 'show' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_value = el.getAttribute( this.props[ _index_++ ] );
              var show_left_icon = el.getAttribute( this.props[ _index_++ ] );
              var show_right_icon = el.getAttribute( this.props[ _index_++ ] );
              var right_icon = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );

              app_value = BaseEx.filterUndefinedOrNull( app_value );

              html.push('<div app_id="' + app_id + '" class="_app_date_" _app_tag_="app-date" >');
                  html.push('<div class="_app_date_head_">');
              if ( show_left_icon && show_left_icon == "none" ) {

              } else {
                      html.push('<div class="app_panel_blue_line_"></div>');
              }
                      html.push('<p class="app_panel_title_ jyb_title css_ellipsis ">' + app_key + '</p>');
                      html.push('<div id="' + app_id + '" class="_app_date_value_">' + app_value + '</div>');
                  html.push('</div>');
                  html.push('<div class="_app_date_icon_">');
              if ( show_right_icon && show_right_icon == "none" ) {
                      
              } else {
                  if ( right_icon ) {
                      html.push( '<img src="' + right_icon + '" style="float:left;height:0.4rem;"/>' );
                  } else {
                      html.push( '<img src="../jybimage/taizhangrili.png" style="float:left;height:0.4rem;"/>' );
                  }
              }
                  html.push('</div>');
              html.push('</div>');

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, this.props );
              
              if( show && show == "none" ){
                new_el.style.display = "none";
              }

              el.parentNode.replaceChild(new_el, el);

              var select_fun = function( e ){
                  var obj = this;
                  
              };

              if ( on_select ) {
                // 绑定点击事件
                var fun = eval( on_select.split("(")[0] );
                if ( typeof fun == "function" ) {
                  
                  select_fun = function( e ){
                    var obj = this;
                    

                  };

                }

              }

              select_fun.bind( new_el );

              TagConfig.eventArray.push( new Array( new_el, "click", select_fun ) );

              return new_el;
          }
      }*/

      /*
       * app-list-c：列表c，服务包信息列表。有单选和滑动功能
       * @param {String} app_id id标识
       * @param {String} show 列字段
       * @param {String} doctorname 医师名称
       * @param {String} districtname 行政区名称
       * @param {String} hospname 医院名称
       * @param {String} list_data 列表json数据
       * @param {String} on_select 单选事件
       * @param {String} on_click_info 显示服务包信息事件
       * @param {String} on_click_confuse 拒绝邀请事件
       */
      "app-list-c" : {
          props : [ 'app_id', 'show', 'doctorname', 'districtname', 'hospname', 'list_data', 'on_select', 'on_click_info', 'on_click_confuse' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var doctorname = el.getAttribute( this.props[ _index_++ ] );
              var districtname = el.getAttribute( this.props[ _index_++ ] );
              var hospname = el.getAttribute( this.props[ _index_++ ] );
              var list_data = el.getAttribute( this.props[ _index_++ ] );
              var on_select = el.getAttribute( this.props[ _index_++ ] );
              var on_click_info = el.getAttribute( this.props[ _index_++ ] );
              var on_click_confuse = el.getAttribute( this.props[ _index_++ ] );

              if ( JSUtil.isNotEmpty( list_data ) ) {
                  list_data = eval( list_data );
              } else {
                  list_data = {};
              }

              var __fn_touchmove__ = function ( e ) {
          　　　　 e.preventDefault();

                  var startX = this.getAttribute( "startX" );
                  var startFlag = this.getAttribute( "startFlag" );

                  // var left = $(this).css( "left" ).replace( "px", "" );
                  var left = JSUtil.css( this, "left" ).replace( "px", "" );
                  // var width = $(this.parentNode).width();
                  var width = this.parentNode.offsetWidth;
                  
          　　　　 var moveEndX = e.changedTouches[0].pageX,
          　　　　 X = moveEndX - startX;

                  // console.log( "moveEndX:" + moveEndX );
                  // console.log("startFlag：" + startFlag);
                  // console.log("X：" + X);
                  // console.log("left：" + left);
                  // console.log("width：" + width);
                  // console.log("left/width：" + left/width);

                  if ( startFlag < 0 && X > 0 ) {  // 右滑
                      if ( X/width >= -0.25 && X <= width*0.25 ) {
                          // $(this).css( "left", X + "px" );
                          JSUtil.css( this, "left", X + "px" );
                      } else {
                          // $(this).css( "left", "" );
                          JSUtil.css( this, "left", "" );
                      }
                  }

                  if( startFlag == 0 && X < 0 ){  // 左滑
                      if ( X/width <= -0.25 ) {
                          // $(this).css( "left", ( width * -0.25 ) + "px");
                          JSUtil.css( this, "left", ( width * -0.25 ) + "px");
                      } else {
                          // $(this).css( "left", X + "px" );
                          JSUtil.css( this, "left", X + "px" );
                      }
                  }
              };

              var __fn_touchend__ = function ( e ) {
          　　　　 // e.preventDefault();
                  var startX = this.getAttribute( "startX" );
                  var startFlag = this.getAttribute( "startFlag" );
                  // var left = $(this).css( "left" ).replace( "px", "" );
                  var left = JSUtil.css( this, "left" ).replace( "px", "" );
                  // var width = $(this.parentNode).width();
                  var width = this.parentNode.offsetWidth;

                  // console.log( "end---------------------------------------" );
                  // console.log( "startX_end:" + startX );
                  // console.log( "startFlag_end:" + startFlag );
                  // console.log( "left_end:" + left );
                  // console.log( "width_end:" + width );

          　　　　 if ( startFlag == 0 && left/width <= -0.07 ) {
                      // $(this).css( "left", width * -0.25 );
                      JSUtil.css( this, "left", width * -0.25 + "px" );
                      return;
          　　　　 }
                  if ( startFlag < 0 && left/width >= -0.15 ) {
                      // $(this).css( "left", "" );
                      JSUtil.css( this, "left", "" );
                      return;
                  }
                  if( left/width != -0.25 ){
                      // $(this).css( "left", "" );
                      JSUtil.css( this, "left", "" );
                  }
                  
                  // $(this).unbind( "touchmove" );
                  // $(this).unbind( "touchend" );
                  JSUtil.removeHandle( this, "touchmove", __fn_touchmove__ );
                  JSUtil.removeHandle( this, "touchend", __fn_touchend__ );
              };

              var _select_fun_ = function ( e ) {
                  e.stopPropagation();

                  var obj = e.currentTarget;
                  var radio_base = obj.parentNode.parentNode;
                  var array = radio_base.querySelectorAll( "._list_icon_c_" );
                  for (var i = 0; i < array.length; i++) {
                      array[i].className = "_list_icon_c_ _app_radio_uncheck_";
                  }
                  obj.querySelector( "._list_icon_c_" ).className = "_list_icon_c_ _app_radio_checked_";

                  if ( on_select ) {
                    var fun = eval( on_select.split("(")[0] );
                    if ( typeof fun == "function" ) {
                        fun( JSON.parse( obj.parentNode.getAttribute( "_row_data_" ) ) );
                    }
                  }
              };

              var _fn_confuse_ = function ( e ) {
                  e.stopPropagation();
                  
                  var obj = e.currentTarget;
                  if ( on_click_confuse ) {
                    var fun = eval( on_click_confuse.split("(")[0] );
                    if ( typeof fun == "function" ) {
                        fun( JSON.parse( obj.parentNode.getAttribute( "_row_data_" ) ) );
                    }
                  }
              };

              var _fn_show_info_ = function ( e ) {
                  e.stopPropagation();
                  
                  var obj = e.currentTarget;
                  if ( on_click_info ) {
                    var fun = eval( on_click_info.split("(")[0] );
                    if ( typeof fun == "function" ) {
                        fun( JSON.parse( obj.parentNode.parentNode.getAttribute( "_row_data_" ) ) );
                    }
                  }
              };

              html.push( '<div class="_list_c_" app_id="' + app_id + '" id="' + app_id + '" _app_tag_="app-list-c" >' );
              html.push( '</div>' );
              new_el = JSUtil.parseDom(html.join(''))[0];
              html=[];
              var i,row,row_el;
              for ( i = 0; i < list_data.length; i++) {
                  row = list_data[i];
                  row_el;
                  html=[];
                  html.push( '<div class="_list_row_c_" >' );
                      html.push( '<div class="_list_left_c_" >' );
                          html.push( '<div class="_list_font_c_" style="width:40%;" >' + row[ doctorname ] + '</div>' );
                          html.push( '<div class="_list_font_c_ _fn_show_info_" style="width:40%;text-align: right;float: right;text-decoration:underline;color:#3d97ea;" >服务包信息></div>' );
                          html.push( '<div class="_list_font_c_" style="height:1rem;line-height:0.5rem;overflow:hidden;text-overflow: ellipsis;text-overflow: -o-ellipsis-lastline;" >' + row[ districtname ] + '-' + row[ hospname ] + '</div>' );
                      html.push( '</div>' );
                      html.push( '<div class="_list_center_c_ _select_fun_" >' );
                          html.push( '<div class="_list_icon_c_ _app_radio_uncheck_" ></div>' );
                      html.push( '</div>' );
                      html.push( '<div class="_list_right_c_ _fn_confuse_" >' );
                          html.push( '<div style="height:25%;color:white;" >拒 绝</div>' );
                          html.push( '<div style="height:25%;color:white;" >邀 请</div>' );
                      html.push( '</div>' );
                  html.push( '</div>' );
                  row_el = JSUtil.parseDom( html.join('') )[0];
                  row_el = new_el.appendChild( row_el );
                  row_el.setAttribute( "_row_data_", JSON.stringify( row ) );

                  JSUtil.addHandle( row_el, "touchstart", function(e) {
              　　　　 // e.preventDefault();
                      // console.log( "start---------------------------------------" );

                      var startX = e.changedTouches[0].pageX;
                      // var startFlag = $(this).css( "left" ).replace( "px", "" );
                      var startFlag = JSUtil.css( this, "left" ).replace( "px", "" );

                      this.setAttribute( "startX", startX );
                      this.setAttribute( "startFlag", startFlag );

                      // console.log( "startX:" + startX );

                      // $(this).unbind( "touchmove" );
                      // $(this).unbind( "touchend" );
                      JSUtil.removeHandle( this, "touchmove", __fn_touchmove__ );
                      JSUtil.removeHandle( this, "touchend", __fn_touchend__ );

                      JSUtil.addHandle( this, "touchmove", __fn_touchmove__ );
                      JSUtil.addHandle( this, "touchend", __fn_touchend__ );

              　　});

                  JSUtil.addHandle( row_el.querySelector("._fn_show_info_"), "click", _fn_show_info_ );
                  JSUtil.addHandle( row_el.querySelector("._select_fun_"), "click", _select_fun_ );
                  JSUtil.addHandle( row_el.querySelector("._fn_confuse_"), "click", _fn_confuse_ );

              }

              new_el.appendChild( JSUtil.parseDom( '<div style="clear:both;"></div>' )[0] );
              
              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              if( show && show == "none" ){
                  new_el.style.display = "none";
              }

              el.parentNode.replaceChild( new_el, el );
              return new_el;
          }
      },

      "app-patient-select" : {
          "props" : [ 'app_id', 'app_data', 'on_select', 'style' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_data = el.getAttribute( this.props[ _index_++ ] );
              var on_select = el.getAttribute( this.props[ _index_++ ] );
              var style = el.getAttribute( this.props[ _index_++ ] );

              html.push( '<div app_id="app_id" _app_tag_="app-patient-select" class="_patient_select_" >' );
                  html.push( '<input id="buid" class="buid" style="display:none;" />' );
                  html.push( '<img src="../jybimage/bindPeopleImg.png" class="_patient_select_head_" />' );
                  html.push( '<div class="bindInfo">' );
                      html.push( '<p id="buname" class="buname text_value_color" style="margin-top:0.2rem;" _app_attribute_="buname" ></p>' );
                      html.push( '<p class="text_key_color _patient_select_ssc_" >社保账户：<span id="bussc"  _app_attribute_="bussc"></span></p>' );
                  html.push( '</div>' );
                  html.push( '<div style="float:right;margin-right: 0.5rem;height: 100%;">' );
                      html.push( '<div class="change_button _patient_select_button_" align="center" >更换</div>' );
                  html.push( '</div>' );
              html.push( '</div>' );

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              el.parentNode.replaceChild( new_el, el );

              if( app_data ){
                if( typeof app_data == "object" ){

                }else if( typeof JSON.parse( app_data ) == "object" ){
                    app_data = JSON.parse( app_data );
                }else{
                    app_data = null;
                }
                if( JSUtil.isNotEmpty( app_data ) ){
                    new_el.querySelector( "#buid" ).value = app_data[ 'buid' ];
                    new_el.querySelector( "#buname" ).innerText = app_data[ 'buname' ];
                    new_el.querySelector( "#bussc" ).innerText = app_data[ 'bussc' ];
                }
              }

              if ( on_select ) {
                // 绑定点击事件
                var fun = eval( on_select.split("(")[0] );
                if ( typeof fun == "function" ) {
                  
                  var change_fun = function( e ){
                      var obj = e.currentTarget;
                      var buname = obj.parentNode.parentNode.querySelector( "#buname" ).innerText;
                      var buid = obj.parentNode.parentNode.querySelector( "#buid" ).value;
                      var bussc = obj.parentNode.parentNode.querySelector( "#bussc" ).value;
                      var data = JSON.stringify( obj.parentNode.parentNode.getAttribute( "app_data" ) );
                      fun( buname, buid, data );
                  };

                  TagConfig.eventArray.push( new Array( new_el.querySelector(".change_button"), "click", change_fun ) );

                }

              }

              return new_el;

          }
      },

      "app-textarea" : {
          "props" : [ 'app_id', 'app_key', 'app_value', 'show', 'disabled', 'border_bottom', 'maxlength' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_value = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var disabled = el.getAttribute( this.props[ _index_++ ] );
              var border_bottom = el.getAttribute( this.props[ _index_++ ] );
              var maxlength = el.getAttribute( this.props[ _index_++ ] );

              html.push( '<div app_id="' + app_id + '" class="_app_textarea_" _app_tag_="app-textarea" >' );

              if ( border_bottom && ( border_bottom == "false" || border_bottom == "none") ) {
                  html.push( '<div class="_app_textarea_div_" >' );
              } else {
                  html.push( '<div class="_app_textarea_div_ jyb_text_border_bottom" >' );
              }
                      html.push( '<div class="jyb_text_key jyb_detail text_key_color">' + app_key + '</div>' );
                      html.push( '<textarea id="' + app_id + '" style="height:1.2rem;" class="_app_textarea_input_ jyb_detail text_value_color" maxlength="' + maxlength + '" >' );
                          html.push( app_value );
                      html.push( '</textarea>' );
                  html.push( '</div>' );

                  html.push( '<div style="clear:both;"></div>' );
              html.push( '</div>' );

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              if( show && show == "none" ){
                  new_el.style.display = "none";
              }

              el.parentNode.replaceChild( new_el, el );

              return new_el;

          }
      },

      "app-input" : {
          "props" : [ 'app_id', 'app_key', 'app_value', 'show', 'value_ellipsis', 'border_bottom', 'app_type', 'validate', 'maxlength' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_value = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var value_ellipsis = el.getAttribute( this.props[ _index_++ ] );
              var border_bottom = el.getAttribute( this.props[ _index_++ ] );
              var app_type = el.getAttribute( this.props[ _index_++ ] );
              var validate = el.getAttribute( this.props[ _index_++ ] );
              var maxlength = el.getAttribute( this.props[ _index_++ ] );

              app_key = app_key ? app_key : "";
              app_value = app_value ? app_value : "";
              var _app_type = app_type || JSUtil.isNotEmpty( app_type) ? app_type : "text";

              html.push( '<div app_id="' + app_id + '" class="jyb_text"  _app_tag_="app-input" app_key="' + app_key + '" >' );

              if ( border_bottom && ( border_bottom == "false" || border_bottom == "none") ) {
                  html.push( '<div class="jyb_text_div" >' );
              } else {
                  html.push( '<div class="jyb_text_div jyb_text_border_bottom" >' );
              }
                      html.push( '<input id="' + app_id + '" type="' + _app_type + '" class="_app_input_input_ jyb_detail text_key_color" style="text-align:left;" value="' + ( JSUtil.isNotEmpty( app_value ) ? app_value : app_key ) + '" ' );
              if ( maxlength && JSUtil.isNumber( maxlength ) ) {
                      html.push( ' maxlength = "' + maxlength + '"' );
              }
                      html.push( ' />' );
                  
                  html.push( '</div>' );

                  html.push( '<div style="clear:both;"></div>' );
              html.push( '</div>' );

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              if( show && show == "none" ){
                  new_el.style.display = "none";
              }

              el.parentNode.replaceChild( new_el, el );

              // 绑定获取焦点事件
              var _focus_ = function ( e ) {
                  var el = e.currentTarget;
                  var value = el.value;
                  if ( value && value == app_key ) {
                      el.value = "";
                      el.className = el.className.replace( "text_key_color", "text_value_color" );
                  }
              };
              _focus_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "focus", _focus_ ) );

              // 绑定失去焦点事件
              var _blur_ = function ( e ) {
                  var el = e.currentTarget;
                  var value = el.value;
                  if ( !value || JSUtil.isEmpty( value ) ) {
                      el.value = app_key;
                      el.className = el.className.replace( "text_value_color", "text_key_color" );
                  }
              };
              _blur_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "blur", _blur_ ) );



              // 绑定验证事件
              var _validate_ = function ( e ) {
                  // var flag_type = true, flag = true, tip = null;
                  // // console.log( this );
                  var input_el = e.currentTarget;

                  // if ( app_type ) {
                  //     // flag_type = BaseEx.validateInput( input_el.value, app_type );
                  //     var re = BaseEx._validate_[ app_type ]( input_el.value );
                  //     flag_type = re[ 0 ];
                  //     tip = re[ 1 ];
                  // }

                  // if ( validate && JSUtil.isFunction( validate ) ) {
                  //     var fun = eval( validate.split("(")[0] );
                  //     var ret = fun( input_el.value );
                  //     flag = ret[0];
                  //     tip = ret[1];
                  // }

                  // // 验证结果：
                  // if ( !flag_type || !flag ) { // 未通过
                  //     if ( input_el.className.indexOf( "jyb_validate_input" ) < 0 ) {
                  //         input_el.className += " jyb_validate_input";

                  //         var tip_div = document.createElement( "div" );
                  //         var bind_target = document.querySelector("div[_app_tag_='app-body']") || document.body;
                  //         tip_div.id = this.app_id + "_validate_";
                  //         tip_div.className = "_validate_tip_";
                  //         tip_div.innerHTML = tip ;
                  //         tip_div.style.top = ( JSUtil.top( input_el ) - JSUtil.remToPx( 0.4 ) - JSUtil.top( bind_target ) ) + "px";
                  //         tip_div.style.right = ( bind_target.offsetWidth - JSUtil.left( input_el ) - input_el.offsetWidth - JSUtil.left( bind_target ) ) + "px";

                  //         bind_target.appendChild( tip_div );
                          
                  //     }
                  // } else { // 通过
                  //     if ( input_el.className.indexOf( "jyb_validate_input" ) >= 0 ) {
                  //         input_el.className = input_el.className.replace( " jyb_validate_input", "" );
                  //         var tip_div = document.querySelector( "#" + this.app_id + "_validate_" );
                  //         if ( tip_div ) {
                  //             JSUtil.remove( tip_div );
                  //         }
                  //     }
                  // }

                  BaseEx._app_validate_( input_el, app_type, validate );
              }
              _validate_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "input", _validate_ ) );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "focus", _validate_ ) );

              var _input_ = function ( e ) {
                  var input_el = e.currentTarget;
                  if ( app_type ) {
                      var value = BaseEx._type_[ app_type ]( input_el.value );
                      input_el.value = value;
                      app_value = value;
                  }
              }
              _input_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "input", _input_ ) );

              return new_el;

          }
      },

      "app-textarea-nl" : {
          "props" : [ 'app_id', 'app_key', 'app_value', 'show', 'value_ellipsis', 'border_bottom', 'app_type', 'validate', 'maxlength' ],
          template : function(el) {
              var html=[];
              var _index_ = 0;
              var new_el;

              var app_id = el.getAttribute( this.props[ _index_++ ] );
              var app_key = el.getAttribute( this.props[ _index_++ ] );
              var app_value = el.getAttribute( this.props[ _index_++ ] );
              var show = el.getAttribute( this.props[ _index_++ ] );
              var value_ellipsis = el.getAttribute( this.props[ _index_++ ] );
              var border_bottom = el.getAttribute( this.props[ _index_++ ] );
              var app_type = el.getAttribute( this.props[ _index_++ ] );
              var validate = el.getAttribute( this.props[ _index_++ ] );
              var maxlength = el.getAttribute( this.props[ _index_++ ] );

              app_key = app_key ? app_key : "";
              app_value = app_value ? app_value : "";
              var _app_type = app_type || JSUtil.isNotEmpty( app_type) ? app_type : "text";

              html.push( '<div app_id="' + app_id + '" class="jyb_text"  _app_tag_="app-textarea-nl" app_key="' + app_key + '" >' );

              if ( border_bottom && ( border_bottom == "false" || border_bottom == "none") ) {
                  html.push( '<div class="jyb_text_div" >' );
              } else {
                  html.push( '<div class="jyb_text_div jyb_text_border_bottom" >' );
              }
                      html.push( '<textarea id="' + app_id + '" type="' + _app_type + '" class="_app_input_input_ jyb_detail text_key_color" style="text-align:left;border:0px;margin-bottom:0.2rem;height:0.4rem;" ' );
              if ( maxlength && JSUtil.isNumber( maxlength ) ) {
                      html.push( ' maxlength = "' + maxlength + '"' );
              }
                      html.push( ' >' + ( JSUtil.isNotEmpty( app_value ) ? app_value : app_key ) + '</textarea>' );
                  
                  html.push( '</div>' );

                  html.push( '<div style="clear:both;"></div>' );
              html.push( '</div>' );

              new_el = JSUtil.parseDom(html.join(''))[0];

              // 继承属性
              JSUtil.extendsAttributes( el, new_el, [] );

              if( show && show == "none" ){
                  new_el.style.display = "none";
              }

              el.parentNode.replaceChild( new_el, el );

              // 动态调整高度
              var _changeHeight_ = function ( e ) {
                  var elm = e.currentTarget;
                  BaseEx.vueCommon.appTextareaNl._changeHeight_( elm );
              }

              // 绑定获取焦点事件
              var _focus_ = function ( e ) {
                  var el = e.currentTarget;
                  var value = el.value;
                  if ( value && value == app_key ) {
                      el.value = "";
                      el.className = el.className.replace( "text_key_color", "text_value_color" );
                  }
                  _changeHeight_( e );
              };
              _focus_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "focus", _focus_ ) );

              // 绑定失去焦点事件
              var _blur_ = function ( e ) {
                  var el = e.currentTarget;
                  var value = el.value;
                  if ( !value || JSUtil.isEmpty( value ) ) {
                      el.value = app_key;
                      el.className = el.className.replace( "text_value_color", "text_key_color" );
                  }
                  _changeHeight_( e );
              };
              _blur_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "blur", _blur_ ) );


              var _propertychange_ = function ( e ) {
                  _changeHeight_( e );
              };
              _blur_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "propertychange", _propertychange_ ) );


              // 绑定验证事件
              var _validate_ = function ( e ) {
                  // var flag_type = true, flag = true, tip = null;
                  // // console.log( this );
                  var input_el = e.currentTarget;

                  // if ( app_type ) {
                  //     // flag_type = BaseEx.validateInput( input_el.value, app_type );
                  //     var re = BaseEx._validate_[ app_type ]( input_el.value );
                  //     flag_type = re[ 0 ];
                  //     tip = re[ 1 ];
                  // }

                  // if ( validate && JSUtil.isFunction( validate ) ) {
                  //     var fun = eval( validate.split("(")[0] );
                  //     var ret = fun( input_el.value );
                  //     flag = ret[0];
                  //     tip = ret[1];
                  // }

                  // // 验证结果：
                  // if ( !flag_type || !flag ) { // 未通过
                  //     if ( input_el.className.indexOf( "jyb_validate_input" ) < 0 ) {
                  //         input_el.className += " jyb_validate_input";

                  //         var tip_div = document.createElement( "div" );
                  //         var bind_target = document.querySelector("div[_app_tag_='app-body']") || document.body;
                  //         tip_div.id = this.app_id + "_validate_";
                  //         tip_div.className = "_validate_tip_";
                  //         tip_div.innerHTML = tip ;
                  //         tip_div.style.top = ( JSUtil.top( input_el ) - JSUtil.remToPx( 0.4 ) - JSUtil.top( bind_target ) ) + "px";
                  //         tip_div.style.right = ( bind_target.offsetWidth - JSUtil.left( input_el ) - input_el.offsetWidth - JSUtil.left( bind_target ) ) + "px";

                  //         bind_target.appendChild( tip_div );
                          
                  //     }
                  // } else { // 通过
                  //     if ( input_el.className.indexOf( "jyb_validate_input" ) >= 0 ) {
                  //         input_el.className = input_el.className.replace( " jyb_validate_input", "" );
                  //         var tip_div = document.querySelector( "#" + this.app_id + "_validate_" );
                  //         if ( tip_div ) {
                  //             JSUtil.remove( tip_div );
                  //         }
                  //     }
                  // }

                  BaseEx._app_validate_( input_el, app_type, validate );
              }
              _validate_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "input", _validate_ ) );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "focus", _validate_ ) );

              var _input_ = function ( e ) {
                  var input_el = e.currentTarget;
                  if ( app_type ) {
                      var value = BaseEx._type_[ app_type ]( input_el.value );
                      input_el.value = value;
                      app_value = value;
                  }
                  _changeHeight_( e );
              }
              _input_.bind( new_el.querySelector("._app_input_input_") );
              TagConfig.eventArray.push( new Array( new_el.querySelector("._app_input_input_"), "input", _input_ ) );

              return new_el;

          },
          mounted : function ( new_el ) {
              var textarea = new_el.querySelector( "textarea" );
              textarea.setAttribute( "_original_height_", textarea.offsetHeight );
          }
      }

    }
  }


  /**
    * 渲染标签，重排页面
    */
  RenderTag.renderTag = function ( id ) {
    console.log( "RenderTag start" );

    var originalNode;
    if ( typeof id == "string" ) {
        originalNode = document.getElementById( id );
    } else if ( typeof id == "object" ) {
        originalNode = id;
    } else {
        throw "请传入id或者元素！";
    }

    if ( originalNode && originalNode.nodeName.toLowerCase == "body" ) {
        throw "元素不能是body";
    }

    var cloneNode = originalNode.cloneNode( true );
    /*var nodeName = cloneNode.nodeName.toLowerCase();
    if( TagConfig.components[ nodeName ] ){
        cloneNode = TagConfig.components[ nodeName ].template( cloneNode );
        cloneNode.setAttribute( "rendertag", "rendertag" );
    }*/
    RenderTag._renderChildren_( cloneNode );

    originalNode.parentNode.replaceChild( cloneNode, originalNode );
    var i,map;
    for ( i = 0; i < TagConfig.eventArray.length; i++ ) {
      map = TagConfig.eventArray[i];
      JSUtil.addHandle( map[0], map[1], map[2] );
      // TagConfig.eventArray.remove( map );
    }
    TagConfig.eventArray = [];

    RenderTag._mounted_( cloneNode );

    console.log( "RenderTag end" );

    return cloneNode;
  }

  // 渲染子节点
  RenderTag._renderChildren_ = function( el ) {
      var nodeList = el.children,i,node,nodeName;
      // try {
          for ( i = 0; i < nodeList.length; i++) {
              node = nodeList[i];
              nodeName = node.nodeName.toLowerCase();
              if( TagConfig.components[ nodeName ] ){
                  node = TagConfig.components[ nodeName ].template( node );
                  node.setAttribute( "rendertag", "rendertag" );
              }
              RenderTag._renderChildren_( node );
          }
      // } catch( e ) {
      //     debugger;
      // }
  }

  RenderTag._mounted_ = function ( el ) {
      var list = el.children;
      var i,node,_tag_,tag;
      for ( i = 0; i < list.length; i++) {
          node = list[i];
          _tag_ = node.getAttribute( "_app_tag_" );
          tag = TagConfig.components[ _tag_ ];
          if ( tag && tag.mounted ) {
              tag.mounted( node );
          }
          RenderTag._mounted_( node );
      }
  }
  

})($, JSUtil, BaseEx);