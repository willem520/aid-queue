(function($) {

	if ( typeof Base == "undefined" ) {
		Base = {};
		window.Base = Base;
	}

	Base.safeArea = function () {
		
		var header = md.getPrefs({key: 'safeArea'}) || '0';
		var heardHeight = $(".header").height();
		header = parseInt( header );
		var main = header + heardHeight - 2; // 在heard定为0.8rem的时候求高会多出2，原因暂不明确。
		var checkmain = header + 88;
		var order = header + 154;
		var search = header + 70;

		$(".header,#hear,.tabmain,.screenTop,.main_list_detail,.doctor_title").css("padding-top",header+"px");
      	$(".main,.hospmain,.addresslist,.zhenli").css("padding-top",main+"px");
      	$(".ipx").css("top",main+"px");
      	$(".checkmain").css("padding-top",checkmain+"px");
	  	$(".orderDetailList").css("padding-top",order+"px");
	  	$(".history_list").css("padding-top",search+"px");

	}

	Base.toShowTop = function () {
		try {
			Base.safeArea();
		} catch ( err ) {
			setTimeout(function() {
				Base.toShowTop();
			}, 100);
		}
	}

	Base.toShowTop();

	


}($));