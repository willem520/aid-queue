(function($) {
	if (typeof Base == "undefined") {
		Base = {};
		window.Base = Base;
	}
	// 接口地址   记得加逗号


	/*

		* 远程问诊功能
		
		* intelLogin:登录
		* setUserInfo:设置账户信息
		* chatTo:打开对话列表
		* addMsgListener:添加消息监听事件
		* addCustomNotifyListener:添加自定义通知消息监听事件
		* addOogeListener:添加应用消息监听事件
		* startUrl:会话窗口打开页面方法，参数同openWin
		* setSessionBottomMenu:设置会话菜单
		* sendMsg:发送自定义消息
		* sendNoticeMsg:发送系统通知
		* backToStart:返回下层页面
		* sendTextMsg:发送消息

	*/

	Base.intelLogin = function( uid , callback ){
		md.showProgress({
		    content: '加载中，请稍候...',
		    modal: true
		});
        UIMClient.login({
			"uid": uid,
			"token":'',
			"needInitData": false
		},function(ret,err){
			
			if( ret && ret.code == 0 ){
				md.hideProgress();
				console.log( "login+++++" + JSON.stringify( ret ) )
				var ret = 1;
				callback( ret );
			}
			// else{
			//   	console.log( "login+++++" + JSON.stringify( ret ) )
			//   	Base.intelLogin( uid );
			// }
		});
		
		

	}

	Base.setUserInfo = function( uid , sex , nickName , tel , callback ){
		UIMClient.setUserInfo({
            "uid":uid,
            "sex":sex,
            "nickName":nickName,
            "avatar":"../images/adult_man.png",
            "email":"",
            "tel":tel,
            "phone":tel,
        },function(ret,err){
            if( ret ){
                console.log("setUserInfo+++++" + JSON.stringify(ret));
                callback( "1" );
            }else{
                console.log("setUserInfo+++++" + JSON.stringify(ret))
                callback( "0" );
            }
        });
	}

	Base.chatTo = function( uid , callback ){
		
		UIMClient.setUIMClientParams({
			isShowUserDetailInfo: false
		});

		md.setPrefs({
		    key: 'intoRoom',
		    value: '0'
		});

		UIMClient.chatTo({
            "uid": uid,
        },function(ret,err){
            if( ret ){
                console.log( "chatTo+++++" + JSON.stringify( ret ) );
                if( ret.code == 1 ){
                	if( md.systemType == 'android' ){

                		UIMClient.clearCache(function(ret,err){});
                		
                	}
                }else{
                	var ret = "1";
                	callback( ret );
                }
                
            }else{
                console.log( "chatTo+++++" + JSON.stringify( ret ) );
            }
        });
	}

	Base.addMsgListener = function( callback ){


		UIMClient.addMsgListener(function(ret,err){
            if( ret.code ===0 ){
                console.log( "addMsgListener+++++" + JSON.stringify(ret));
                callback( "1" );
            }else{
                console.log( "addMsgListener+++++" + JSON.stringify(ret));
            }
        });
		
	}

	Base.addCustomNotifyListener = function( callback ){
		UIMClient.addCustomNotifyListener(function(ret,err){
			if( md.systemType == "ios" ){
                var result = ret.result;
            }else{
                var result = JSON.parse(ret.result);
            }
            if( ret.code == 0 ){
                console.log( "addCustomNotifyListener+++++" + JSON.stringify(ret));
                callback( "1" );
            }else{
                console.log( "addCustomNotifyListener+++++" + JSON.stringify(ret));
            }
        });
	}

	Base.addOogeListener = function( callback ){
		
		UIMClient.addOogeListener(function(ret,err){

			if( md.systemType == "ios" ){
                var result = ret.result;
            }else{
                var result = JSON.parse(ret.result);
            }
            if( ret.code == 0 ){
                var callMethod = JSON.parse(result.ooge.callMethod);
                callback( callMethod );
            }

        });
			
	}

	Base.startUrl = function( name , url , param ){
		UIMClient.startUrl({
            name: name,
            url: 'wgt://' + url,
            reload: true,
            pageParam: param
        },function(ret,err){
            if( ret ){
                console.log( "startUrl+++++" + JSON.stringify( ret ) );
            }else{
                console.log( "startUrl+++++" + JSON.stringify( ret ) );
            }
        });
	}

	Base.setSessionBottomMenu = function( callback ){
		UIMClient.clearListener({listenerType: 'bottomMenu'},function(ret,err){
			if( ret ){
				UIMClient.setSessionBottomMenu({"menus":[
		            {icon: "wgt://threeTreat/images/bottomMenu_jieshu.png",index: 2,menuName: "结束接诊",callMethod:""},
		            {icon: "wgt://threeTreat/images/bottomMenu_miaoshu.png",index: 3,menuName: "病情描述",callMethod:""},
		            {icon: "wgt://threeTreat/images/bottomMenu_menzhen.png",index: 4,menuName: "续方号",callMethod:""},
		            {icon: "wgt://threeTreat/images/bottomMenu_fujia.png",index: 5,menuName: "续方附加号",callMethod:""}
		        ]},function(ret,err){
		        	console.log(ret)
		        	if( md.systemType == "ios" ){
		                var result = ret.result;
		            }else{
		                var result = JSON.parse(ret.result);
		            }
		            if( ret.code == 0 ){
		                var menu = result.menu;
		                callback( menu.index );
		        	}
		        });
			}else{
				alert(JSON.stringify(ret))
			}
    	});

		
	}

	Base.backToStart = function(){
		UIMClient.backToStart(function(ret,err){
			if( ret ){
				console.log( JSON.stringify( ret ) );
			}else{
				console.log( err.msg );
			}
		});
	}
	
	Base.sendMsg = function( param ,  callback ){
		md.showProgress({
		    content: '加载中，请稍候...',
		    modal: false
		});

		if( md.systemType == "ios" ){
			param = JSON.stringify( param );
		}

		md.ajax({
			method : 'post',
			headers : {
				'Content-Type': 'application/json',
				'UIM-SECRET': 'QWERTY!@#$%ASD'
			},
			url : 'http://yqim.tjyinhai.cn:80/uim/uim/msg/sendMessage',
			data : {
				body: param
			}
		},function(ret, err){
			if (ret) {
				md.hideProgress();
				callback(1);
			} else {
				md.toast({
					msg: '网络异常',
					duration: 2000,
					location: 'middle'
				});
				md.hideProgress();
			}
		});

	}

	Base.sendNoticeMsg = function( param ,  callback ){
		md.showProgress({
		    content: '加载中，请稍候...',
		    modal: false
		});

		if( md.systemType == "ios" ){
			param = JSON.stringify( param );
		}

		md.ajax({
			method : 'post',
			headers : {
				'Content-Type': 'application/json',
				'UIM-SECRET': 'QWERTY!@#$%ASD'
			},
			url : 'http://yqim.tjyinhai.cn:80/uim/uim/msg/sendPushMessage',
			data : {
				body: param
			}
		},function(ret, err){
			if (ret) {
				md.hideProgress();
			} else {
				md.toast({
					msg: '网络异常',
					duration: 2000,
					location: 'middle'
				});
				md.hideProgress();
			}
		});

	}

	Base.sendTextMsg = function( param ,  callback , mask ){

		if (mask) {
			md.showProgress({
			    content: '加载中，请稍候...',
			    modal: true
			});
		}

		if( md.systemType == "ios" ){
			param = JSON.stringify( param );
		}
		
		md.ajax({
			method : 'post',
			headers : {
				'Content-Type': 'application/json',
				'UIM-SECRET': 'QWERTY!@#$%ASD'
			},
			url : 'http://yqim.tjyinhai.cn:80/uim/uim/msg/sendMessage',
			data : {
				body: param
			}
		},function(ret, err){
			if (ret) {
				md.hideProgress();
				callback('1');
			} else {
				md.toast({
					msg: '网络异常',
					duration: 2000,
					location: 'middle'
				});
				md.hideProgress();
			}
		});

	}


	/*

		* 远程问诊功能

	*/
}($));